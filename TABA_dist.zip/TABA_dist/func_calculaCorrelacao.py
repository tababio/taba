# coding=utf-8
import sys


def correlation_coefficient2(list1,list2): # lista1 = previsto lista2 = experimental
    """Calculates Spearman's rank correlation coeffcient between two lists"""
    #import scipy 
    from scipy.stats import spearmanr        
    from scipy.stats import pearsonr
    from scipy.stats import linregress
    #from sklearn.metrics import mean_squared_error
    from math import sqrt
    import numpy as np 
    len1 = len(list1) # previsto
    len2 = len(list2) # experimental
    slope = None 
    intercept = None
    r_value = None
    p_value = None
    std_err = None
    corr = None
    pearson_cc = None
    pearson_p = None 
    std_deviation = None   
    # Checks whether both lists have the same length
    if len1 != len2 :
        #print("\nError! Number of elements in list1 != number of elements in list2!")
        return None
    else:
        #rmse= str(sqrt(mean_squared_error(list1,list2)))---> tem problemas no sklearn de deprecation isto faz aparecer uma nova tela de inicio do taba
        # para calcular RMSE
        previsto = np.array(list1) 
        experimental = np.array(list2)
        rmse = np.sqrt(np.mean((previsto-experimental)**2))
        try:
            std_deviation = np.std(list1) # estava pegando list2
        except:
            std_deviation = 0
            
        if std_deviation != 0:  # Avoids error message for lists where all elements are the same (standard deviation = 0)
            try:
                corr,pvalue = spearmanr(list1,list2)
                corr = corr
                pvalue = pvalue
                
                try:
                    pearson_cc,pearson_p = pearsonr(list1,list2)
                    slope, intercept, r_value, p_value, std_err = linregress(list1,list2)
                    
                except:
                    pearson_cc = 10.0
                    pearson_p = None
            except:
                corr = 10.0
                pvalue = None
                pearson_cc = 10.0
                pearson_p = None
        else:
            corr = 10.0
            pvalue = None
            pearson_cc = 10.0
            pearson_p = None
 
        r2 = r_value**2
        ''' se for para calcular RMSE
        rms = sqrt(mean_squared_error(list1,list2)) 
        print("rmse:",rms)
        from sklearn.metrics import mean_squared_error
        from math import sqrt
        '''
        return corr,pvalue,pearson_cc,pearson_p,r_value,r2, rmse, std_deviation

