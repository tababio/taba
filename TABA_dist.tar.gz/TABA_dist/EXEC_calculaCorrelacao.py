import sys
from func_calculaCorrelacao import correlation_coefficient2
def main():
    diretorio = "./arquivosSaida/"
    arq = diretorio+"resultadoTeste.csv"
    lista1 = []
    lista2 = []
    try:
        fo = open(arq, 'r')
    except IOError:
        sys.exit ("\n O arquivo "+arq+" nao foi encontrado")

    try:
        fo.readline() # para pular primeira linha
        for line in fo: # percorre arquivo de teste
         
            linha = line.split(",")
            print(linha[0])
            lista1.append(float(linha[1]))
            lista2.append(float(linha[2].replace("\n",'')))
    except:
        pass

    print(lista1)
    print(lista2)
    
    correlacaoSperman,pValueSperman,coeficienteCorrelacaoPerson,pValuePerson = correlation_coefficient2(lista1,lista2)
    print("-------------------------------------------------")
    print("correlacaoSperman",correlacaoSperman)
    print("pValueSperman",pValueSperman)
    print("coeficienteCorrelacaoPerson",coeficienteCorrelacaoPerson)
    print("pValuePerson",pValuePerson)
    print("Considerar boa equacao se pv<5% e CC>50%")
main()