#!/bin/bash
#fazendo backup do trabalho
echo `date`" Iniciando Taba"
cd /home/amauri/Documents/LiClipse\ Workspace/TABA
./taba.py

echo `date`" Terminando Taba"
read	
