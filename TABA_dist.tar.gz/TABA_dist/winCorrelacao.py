#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys

from PyQt4 import QtGui  # Import the PyQt4 module we'll need
from PyQt4.QtGui import QApplication, QDialog,QFont
import interfaceCorrelacao
from func_Gerais import get_arquivosSf, get_listaColunasDistancia, leCsv, limpaArquivosOutlier,limpaPastasSaidaOutlier
from func_manipulaArquivos import apagaArquivo
from func_calculaCorrelacao import correlation_coefficient2 
from func_TestaEquacao import geraCalculoPelaFormula
from func_MelhorEquacao import melhor
from func_Gerais import grava, pegaConfig, gravaConfig
import numpy as np
import matplotlib.pyplot as plt
import csv
import this
from func_manipulaArquivos import apagaArquivos
from sklearn.linear_model.tests.test_ransac import outliers
class fazCorrelacao(QtGui.QMainWindow, interfaceCorrelacao.Ui_MainWindow_correlacao):
    def __init__(self, parent = None):
        diret = "./outputFiles/"
        QtGui.QWidget.__init__(self, parent)
        self.setupUi(self)
        self.setFixedSize(900,680)
        self.window1 = None
        
        self.label_bestEquation.clear()
        self.label_bestFile.clear()
        self.label_bestCoeficiente.clear()
        self.label_coeficientCorrelationTeste.clear()
        self.label_pValuePerson.clear()
        self.label_bestSpearmanTest.clear()
        self.label_pValueSpearman.clear()
        self.label_R2Teste.clear()
        #desabilita setas]
        self.label_setaBS.setPixmap(QtGui.QPixmap("img/setaNula.png")) 
        self.label_setaSC.setPixmap(QtGui.QPixmap("img/setaNula.png")) 
        self.label_setaPC.setPixmap(QtGui.QPixmap("img/setaNula.png")) 
        self.label_setaPVS.setPixmap(QtGui.QPixmap("img/setaNula.png")) 
        self.label_setaPVP.setPixmap(QtGui.QPixmap("img/setaNula.png")) 

     
        self.comboBox_dataBase.clear()
        self.toolButton_graficoTeste.setEnabled(False)
        self.toolButton_graficoTreino.setEnabled(False)
        self.toolButton_media.setEnabled(False)
        self.toolButton_outlier.setEnabled(False)
        distancia = "" 
        list1 = get_arquivosSf(diret,distancia)# manda a distancia nula pois interessa todas
        self.listDist = []
        listDb = []     

        nome = pegaConfig("descricaoDataset").strip()
        quantia = pegaConfig("quantidadeProteinas").strip()
        if quantia !=None:
            quantia = quantia.strip()
        afinidade = pegaConfig("tipoAfinidade") .strip()
        self.label_experimento.setText(nome)
        self.label_afinidade.setText(afinidade)
        self.label_quantia.setText(quantia)
        self.label_tipoMedia.setText(pegaConfig("tipoMedia").strip())  
        self.label_outliers.setText(pegaConfig("outlier").strip())  
       
        for text in list1: #pega variaveis arquivos
            if text.find("SF_") > -1:
                tam = text.find("_TE_Tre")
                text = (text[:tam])
                text = text.replace("./outputFiles/","")
                text = text.replace ("saida","")
                text = text.replace ("_saidaBMOAD","")
                text = text.replace ("_saidaTodos","")
                text = text.replace ("_saidaPDBbind","")
                text = text.replace ("_saidaTodos","")
                text = text.replace ("SF_","")
                textDist = text[-3:]
                textDB = text.replace(textDist, "")
                textDB = textDB.replace("Todos","All") # para ficar em inglês
                if textDB not in listDb:
                    self.comboBox_dataBase.addItem(textDB) # pega dbmoad,pdbbind, tex
                   
                listDb.append(textDB)
                self.listDist.append(textDist)  
        list3 = get_listaColunasDistancia("./outputFiles/")
        for text in list3:
            self.comboBox_distCol.addItem(text)        
        self.comboBox_dataBase.model().sort(0)
        self.comboBox_distCol.model().sort(0)
        self.comboBox_distCol.setCurrentIndex(0)
        tam = self.comboBox_dataBase.count()
        self.comboBox_dataBase.setCurrentIndex(0) 
        self.setWindowTitle(self.windowTitle()+" to "+pegaConfig("descricaoDataset").strip())
    def iniciarCorrelacao(self):
        if self.listDist == []:
            reply = QtGui.QMessageBox.warning(self, 'Attention !!',"The files aren't prepared yet. Do the previous steps first!!!", QtGui.QMessageBox.Ok)
            pass
        else:
            self.iniciarCorrelacaoOK()
   
    def iniciarCorrelacaoOK(self): 
        reply = QtGui.QMessageBox.question(self, 'Message',"This operation may take several minutes. Do you want to proceed?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
        self.diretorio = "./outputFiles/"
        self.col = self.comboBox_distCol.currentText()[9:10].strip()
        self.dist = self.comboBox_distCol.currentText()[0:3].strip()
        self.num_col = int(self.col)+1 #  soma 1 para incluir constante
        base = str(self.comboBox_dataBase.currentText())
        base = base.replace("All", "Todos") # substitui para achar o nome certo do arquivo
        self.arquivo = "saida"+base+self.dist
        #self.arquivo = self.arquivo.replace(".csv", "_TE_Tre.csv") # corrige nome do arquivo escolhido
        self.metodos = ["LinearRegression","Ridge","RidgeCV","Lasso","LassoCV","ElasticNet","ElasticNetCV"]
        # verifica se existem os arquivos
        #SF_saidaTodos4.5_TE_Tre_ElasticNet_3cols
      
        existe = True
        listaArq = []
        '''
        ATENCAO: o codigo comentado verificava a necessidade de arquivos SF para todos os metodos
        agora basta haver o metodo linear regression
        for metodo in self.metodos:
            arq = self.diretorio+"SF_"+self.arquivo+"_TE_Tre_"+metodo+"_"+str(self.num_col)+"cols.csv"
            if not self.existeArquivo(arq):                
                existe = False
            else:
                listaArq.append(arq) # cria lista de arquivos SF para fazer a correlacao
        '''
        for metodo in self.metodos:
            arq = self.diretorio+"SF_"+self.arquivo+"_TE_Tre_"+metodo+"_"+str(self.num_col)+"cols.csv"
            if not self.existeArquivo(arq):                
                existe = False
            else:
                listaArq.append(arq) # cria lista de arquivos SF para fazer a correlacao
        if len(listaArq)>0: # deve existir pelo mneos um arquivo SF no caso o linear regression
            existe = True
        ###################################       
        if reply == QtGui.QMessageBox.Yes:
            if existe: # so executa se o arquvio existir
                self.fazCorrelacao(listaArq)
                self.toolButton_media.setEnabled(True)
            else:
                QtGui.QMessageBox.information(self,"Error", "File not found. Verify if you do linear regression with this variables")
                pass
        else:
            pass
 
    def sair(self):        
        self.close()
        
    def fazCorrelacao(self,listaArq):
       
        self.escondeBotoes()    

       
        if fazCorrelacao.melhorEquacao(self,listaArq) == True: # prestar atencao como chamear o mettodo
            self.testaEquacao()       
            self.calculaCorelacao()   
        else:
            pass
        self.mostraBotoes()
        if not (pegaConfig("outlier").strip() ==  "yes"):
            self.toolButton_outlier.setEnabled(True)
        else:
            self.toolButton_outlier.setEnabled(False)
    def testaEquacao(self):
        diretorio = "./outputFiles/"
        arquivo = diretorio+"melhorEquacao.csv"
   
        try:
            fo = open(arquivo, 'r')
        except IOError:
            sys.exit ("\n the file "+arquivo+" was not found!")
        for line in fo:
            linha = line.split(",")
            if "[melhor Equacao]" in linha:
                formula = linha[1]
        #arquivo = str(self.comboBox_arquivos.currentText()) 
        base = str(self.comboBox_dataBase.currentText())
        base = base.replace("All", "Todos") # substitui para achar o nome certo do arquivo
        arquivo = "saida"+base+str(self.dist)+"_TE_Tre.csv"
        #arquivo = arquivo.replace(".csv", "_TE_Tes.csv") # corrige nome do arquivo escolhido
        diretorio = "./outputFiles/"
        tipo = "Tre"
        geraCalculoPelaFormula(diretorio, arquivo, formula, tipo) # utilizando arquivo treino
        tipo = "Tes"
        geraCalculoPelaFormula(diretorio, arquivo, formula, tipo) # utilizando arquivo teste
        
    def calculaCorelacao(self):     # calcula correlacao para conjunto teste   

        diretorio = "./outputFiles/"
        arq = diretorio+"resultadoTeste.csv"
        lista1 = []
        lista2 = []
        try:
            fo = open(arq, 'r')
        except IOError:
            sys.exit ("\n the file "+arq+" was not found!!")

        try:
            fo.readline() # para pular primeira linha
            for line in fo: # percorre arquivo de teste
                
                linha = line.split(",")
                lista1.append(float(linha[1]))
                lista2.append(float(linha[2].replace("\n",'')))
        except:
            pass
       
        correlacaoSperman,pValueSperman,coeficienteCorrelacaoPerson,pValuePerson,r, r2 = correlation_coefficient2(lista1,lista2)
        self.label_bestSpearmanTest.setText(str(correlacaoSperman))
        self.label_coeficientCorrelationTeste.setText(str(coeficienteCorrelacaoPerson))
        self.label_pValueSpearman.setText(str(pValueSperman))
        self.label_pValuePerson.setText(str(pValuePerson))
        self.label_R2Teste.setText(str(r2))
        # coloca setas
        if (abs(correlacaoSperman)>0.5):
            self.label_setaSC.setPixmap(QtGui.QPixmap("img/setaCima.png"))
            self.label_setaSC.setToolTip("Good result!")
        else:
            self.label_setaSC.setPixmap(QtGui.QPixmap("img/setaBaixo.png"))
            self.label_setaSC.setToolTip( "Bad result!")
        
        if (abs(coeficienteCorrelacaoPerson)>0.5):
            self.label_setaPC.setPixmap(QtGui.QPixmap("img/setaCima.png"))
            self.label_setaPC.setToolTip("Good result!")
        else:
            self.label_setaPC.setPixmap(QtGui.QPixmap("img/setaBaixo.png"))
            self.label_setaPC.setToolTip( "Bad result!")
            
        if (abs(pValueSperman)<0.05):
            self.label_setaPVS.setPixmap(QtGui.QPixmap("img/setaCima.png"))
            self.label_setaPVS.setToolTip("Good result!")
        else:
            self.label_setaPVS.setPixmap(QtGui.QPixmap("img/setaBaixo.png"))
            self.label_setaPVS.setToolTip( "Bad result!")
            
        if (abs(pValuePerson)<0.05):
            self.label_setaPVP.setPixmap(QtGui.QPixmap("img/setaCima.png"))
            self.label_setaPVP.setToolTip("Good result!")
        else:
            self.label_setaPVP.setPixmap(QtGui.QPixmap("img/setaBaixo.png"))
            self.label_setaPVP.setToolTip("Bad result!")            
            
    def melhorEquacao(self,listaArq):
   
        diretorio = "./outputFiles/"
        self.escondeBotoes()      
        maior = 0
        # define coeficiente para comparar a melhor equação 
        if self.radioButton_r1.isChecked():
            self.coeficiente = "r1"
        if self.radioButton_r2.isChecked():
            self.coeficiente = "r2"
        if self.radioButton_sp.isChecked():
            self.coeficiente = "sp"                        

        for arq in listaArq:
            QtGui.QApplication.processEvents() # para não travar
            coef, pv1, melhorEq = melhor(arq, self.coeficiente)
            if coef > float(maior):
                maior = coef
                self.melhorEquacao = melhorEq
                melhorArquivo = arq
                pv1Melhor = pv1
        if maior == 0:
            reply = QtGui.QMessageBox.question(self, 'Message',"There is no information for your selection",QtGui.QMessageBox.Ok, QtGui.QMessageBox.Ok)
            return False
        else:
            if self.coeficiente == "sp":
                self.coefStr = "Spearman"
            elif self.coeficiente == "r1":
                self.coefStr = "R"
            elif self.coeficiente == "r2":
                self.coefStr = "R2"

            
            self.label_bestEquation.setText(self.melhorEquacao)
            self.label_bestFile.setText(melhorArquivo.replace("./outputFiles/",""))
            self.label_coef.setText("Best "+self.coefStr)
            self.label_bestCoeficiente.setText(str(maior))
            # coloca seta
            if (abs(maior)>0.6):
                self.label_setaBS.setPixmap(QtGui.QPixmap("img/setaCima.png"))
                self.label_setaBS.setToolTip("Good result!")
            else:
                self.label_setaBS.setPixmap(QtGui.QPixmap("img/setaBaixo.png"))
                self.label_setaBS.setToolTip("Bad result!") 

            self.label_bestPv1.setText(str(pv1Melhor))
            
            texto = "[melhor Coeficiente("+self.coefStr+")]"+","+str(maior)+"\n"+"[melhor Equacao]"+","+self.melhorEquacao+"\n"+"[melhor Arquivo]"+","+melhorArquivo
            grava(texto, diretorio+"melhorEquacao.csv")
        self.mostraBotoes()
        self.salvaConfig()
        
        return True
                     
    def escondeBotoes(self):
        self.toolButton_iniciar.setEnabled(False)
        self.toolButton_exit.setEnabled(False)
        self.toolButton_graficoTeste.setEnabled(False)
        self.toolButton_graficoTreino.setEnabled(False)
    def mostraBotoes(self):
        self.toolButton_iniciar.setEnabled(True)
        self.toolButton_exit.setEnabled(True)
        self.toolButton_graficoTeste.setEnabled(True)
        self.toolButton_graficoTreino.setEnabled(True)          
    def existeArquivo(self,arq): 
        # Try to open file

        try:
            my_fo = open(arq,"r")   
            return  True
            my_fo.close()
        except:            
            return False     

    def geraGraficoTeste(self):
        diretorio = "./outputFiles/"
        arq = diretorio+"resultadoTeste.csv"

        with open(arq, "r") as f:
            next(f) # pula cabecalho
            data = [row for row in csv.reader(f)]
            xd = [float(row[2]) for row in data]
            yd = [float(row[1]) for row in data]
    
        # sort the data
        reorder = sorted(range(len(xd)), key = lambda ii: xd[ii])
        xd = [xd[ii] for ii in reorder]
        yd = [yd[ii] for ii in reorder]
        
        # make the scatter plot
        plt.rcParams['axes.facecolor'] = '#c0e2ef'
        plt.scatter(xd, yd, s=50, alpha=0.5, marker='o',color='black')
        
        # determine best fit line
        par = np.polyfit(xd, yd, 1, full=True)

        slope=par[0][0]
        intercept=par[0][1]
        xl = [min(xd), max(xd)]
        yl = [slope*xx + intercept  for xx in xl]
    
        # coefficient of determination, plot text
        variance = np.var(yd)
        residuals = np.var([(slope*xx + intercept - yy)  for xx,yy in zip(xd,yd)])
        Rsqr = np.round(1-residuals/variance, decimals=2)
        #plt.text(0.22*max(xd)+0.22*min(xd),0.001*max(yd)+0.001*min(yd),'R2 = %0.2f'% Rsqr, fontsize=12)
        plt.title("Test Set Plot",fontsize=20)
        
        plt.xlabel("Experimental Affinity                 ("+'R2 = %0.2f'% Rsqr+")")
        plt.ylabel("Predicted Affinity")
        # error bounds
        yerr = [abs(slope*xx + intercept - yy)  for xx,yy in zip(xd,yd)]
        par = np.polyfit(xd, yerr, 2, full=True)
      
        #yerrUpper = [(xx*slope+intercept)+(par[0][0]*xx**2 + par[0][1]*xx + par[0][2]) for xx,yy in zip(xd,yd)]
        #yerrLower = [(xx*slope+intercept)-(par[0][0]*xx**2 + par[0][1]*xx + par[0][2]) for xx,yy in zip(xd,yd)]
        
        plt.plot(xl, yl, '-r', color='green',linewidth = 1.5)
        #plt.plot(xd, yerrLower, '--r')
        #plt.plot(xd, yerrUpper, '--r')
        plt.grid(linestyle='-', linewidth = 0.5, color='grey')
        
        plt.show(block = True)
        
    def geraGraficoTreino(self):

        diretorio = "./outputFiles/"
        arq = diretorio+"resultadoTreino.csv"

        with open(arq, "r") as f:
            next(f) # pula cabecalho
            data = [row for row in csv.reader(f)]
            xd = [float(row[2]) for row in data]
            yd = [float(row[1]) for row in data]
        # sort the data
        reorder = sorted(range(len(xd)), key = lambda ii: xd[ii])
        xd = [xd[ii] for ii in reorder]
        yd = [yd[ii] for ii in reorder]
        
        # make the scatter plot
        plt.rcParams['axes.facecolor'] = '#c0e2ef'
        plt.scatter(xd, yd, s=50, alpha=0.5, marker='o',color='black')
    
        # determine best fit line
        par = np.polyfit(xd, yd, 1, full=True)

        slope=par[0][0]
        intercept=par[0][1]
        xl = [min(xd), max(xd)]
        yl = [slope*xx + intercept  for xx in xl]
    
        # coefficient of determination, plot text
        variance = np.var(yd)
        residuals = np.var([(slope*xx + intercept - yy)  for xx,yy in zip(xd,yd)])
        Rsqr = np.round(1-residuals/variance, decimals=2)
        #plt.text(0.32*max(xd)+0.32*min(xd),0.001*max(yd)+0.001*min(yd),'R2 = %0.2f'% Rsqr, fontsize=12)
        plt.title("Training Set Plot",fontsize=20)
        
        plt.xlabel("Experimental Affinity                 ("+'R2 = %0.2f'% Rsqr+")")
        plt.ylabel("Predicted Affinity")
 
        # error bounds
        yerr = [abs(slope*xx + intercept - yy)  for xx,yy in zip(xd,yd)]
        par = np.polyfit(xd, yerr, 2, full=True)
        
        #yerrUpper = [(xx*slope+intercept)+(par[0][0]*xx**2 + par[0][1]*xx + par[0][2]) for xx,yy in zip(xd,yd)]
        #yerrLower = [(xx*slope+intercept)-(par[0][0]*xx**2 + par[0][1]*xx + par[0][2]) for xx,yy in zip(xd,yd)]
        
        plt.plot(xl, yl, '-r', color='green',linewidth = 1.5)
        #plt.plot(xd, yerrLower, '--r')
        #plt.plot(xd, yerrUpper, '--r')
        plt.grid(linestyle='-', linewidth = 0.5, color='grey')
      
        plt.show(block = True)    
    def salvaConfig(self):
        gravaConfig("sperman", str(self.label_bestCoeficiente.text()) )     
        gravaConfig("melhorEquacao", str(self.label_bestEquation.text()))
    def mostraMedias(self):
        diret = "./outputFiles/"
        fileName = "medDist_"+str(self.dist)+"_"+"TRE"+".csv"
        file = diret+fileName
        texto = leCsv(file)
        with open(file) as f:
            data=[tuple(line) for line in csv.reader(f)]
        linha1 = data[0]
        linha2 = data[1]
        texto = "Atoms pair | Average distance ("+u'\u212b'+")"+'\n'+'\n'
        tam = len(linha1)
        for i in range(tam):
            
            cont = i-1
            if float(linha2[cont])>0:
                lin = '{:10s}'.format(str(linha1[cont]).strip())+' = '
                texto = texto+lin+linha2[cont]+"\n"
        texto = texto+"\n"+"----------------------------------------------------"+"\n"+"Showing only averages > 0"

        reply = QtGui.QMessageBox.information(self, 'Average distance of training set  ',texto, QtGui.QMessageBox.Ok)
    def retiraOutliers(self):  
        fator = 0.01
        self.concatenaArquivos()
        diret = "./outputFiles/"
        arq = open(diret+"juntos.csv", 'r')
        reader = csv.reader(arq)
        allRows = [row for row in reader]
        arrEstru = []
        arrVal = []
        for x in allRows:
            if not x[0] == "PDB": # elimina linhas de cabecalho
                arrVal.append(float(x[1])) # cria lista com valores preditos
                arrEstru.append(x[0]) # cria lista com estruturas
        elements = np.array(arrVal)
        mean = np.mean(elements, axis=0)
        sd = np.std(elements, axis=0)
        listaOutliers = []
        ind = 0
        for x in arrVal:
            if not (x > (mean - (fator * sd))) or (x < (mean + (fator * sd))): # verifica se nao esta na faixa
                listaOutliers.append(arrEstru[ind].upper())
            ind = ind+1
        texto = str(listaOutliers)
        texto = texto.replace("]", '')
        texto = texto.replace("[", '')
        grava(texto.split("'"), diret+"outliers.txt")
        arq.close()
        apagaArquivo(diret+"juntos.csv")
        self.limpaArquivoProteinas()
    def concatenaArquivos(self):
        diret = "./outputFiles/"
        fileTreino = diret+"resultadoTreino.csv"
        fileTeste = diret+"resultadoTeste.csv"
        fileJuntos = diret+"juntos.csv"
        arq = open(fileJuntos, "w") 
        arq1 = open(fileTreino, "r")
        arq2 = open(fileTeste, "r")
        arq.write(arq1.read()+arq2.read())
        arq.close()
        arq1.close()
        arq2.close()
    def limpaArquivoProteinas(self):
        diret1 = "./outputFiles/"
        diret2 = "./inputFiles/"
        proteinas = leCsv(diret2+"pdbsProteina.txt")
        outliers = leCsv(diret1+"outliers.txt")
        listProt = []
        listOutliers = []
        listNovoProt = []
        for x in proteinas:
            listProt.append(x.strip())
        for x in outliers:
            listOutliers.append(x.strip())
            
        for x in listProt:
            if not(x in listOutliers):
                listNovoProt.append(x+",".strip())
       
        tam = len(listNovoProt)
        listNovoProt[tam-1] = listNovoProt[tam-1].replace(",","") # retira ultima virgula
        distancia = self.comboBox_distCol.currentText()[0:3].strip()
        if tam <20:
            QtGui.QMessageBox.information(self, "Message", "After this operation, the number of structures will be very small (only "+str(tam)+" structures)."+"\n"+"Is not possible exclude outliers!")
            pass
        else:
            txtOut = str(outliers).replace("'", "")
            txtOut = txtOut.replace("[", "")
            txtOut = txtOut.replace("]", "")
            txtOut = txtOut.lower()
            tracos = "-"*90
            texto = "This structures will be excluded:"+"\n" +tracos+"\n" + txtOut
            texto = texto+"\n"+tracos
            texto = texto+"\n" +"\n"+"These outliers are considering only experiments with distances < "+distancia+u'\u212b'
            texto = texto +"\n"+"\n" + "Do you want to proceed?"
            reply = QtGui.QMessageBox.question(self, "List of Outliers",texto,QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
            if reply == QtGui.QMessageBox.Yes:
                limpaArquivosOutlier()
                limpaPastasSaidaOutlier()
                grava(listNovoProt, diret2+"pdbsProteina.txt") 
                gravaConfig("outlier", "yes")
                gravaConfig ("quantidadeProteinas",str(tam) )
                self.toolButton_outlier.setEnabled(False)
                QtGui.QMessageBox.information(self, "Important !!!", "Operation completed"+"\n"+"\n"+'You must redo "Make File"  and "Regression" again!')
                QtGui.QMessageBox.information(self, "Message", "This windows will be closed.")
                self.close()
            else:
                pass

        