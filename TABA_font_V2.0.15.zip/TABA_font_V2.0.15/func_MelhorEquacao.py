import sys

def melhor(arq, coeficiente): # recebe o diretorio e o arquivo SF

    # posiçoes R [3] R2 [4] speraman = 7
    val = 0
    maior = 0
    melhorEquacao = ""
    pv1 = 0
    # define com qual coeficiente deve comparar
    if coeficiente == "r1": # coeficiente R
        coef = 4
    elif coeficiente == "r2": # coeficiente R
        coef = 3   
    else:
        coef = 7 # coeficiente spearman     
    try:
        fo = open(arq, 'r')
    except IOError:
        sys.exit ("\n O arquivo "+arq+" nao foi encontrado!!!")
        
    try:
        for line in fo:
            linhalimpa = line.replace(" ", "") #retira brancos
            linha = linhalimpa.split(",")
            lin = linha[coef]                     
            val = 0
            if (lin.replace(".","")).isdigit(): #substitui o ponto para vicar só digitos se houver
                val = float(lin)                
                if val > maior:
                    maior = val
                    melhorEquacao = linha[0]
                    pv1 = linha[5]  
           
    except:
        pass
    return maior,pv1,melhorEquacao

