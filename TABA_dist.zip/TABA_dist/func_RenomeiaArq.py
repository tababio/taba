# coding=utf-8
#--------------------------------------------------------------------
# renomeiaArq.py
#
# Script Python para modificar a extensao de aquivos em um diretorio
# e mudar o nome
#
# Uso:
# Defina o diretorio, a extensão que quer retirar e a nova extensao, que
# pode ser vazia (" ").
# Por exemplo:
# diretorio = "/home/gildo/imagens"
# extensao = ".*JPEG" (para retirar as extensoes ".dcm", nao esqueca o asterisco)
# novaExtensao = ".jpg" (nesse caso eh vazia, mas poderia ser ".raw", por ex.)
#--------------------------------------------------------------------

import os
import re
import string


# Coloque os seus parametros aqui...
diretorio = "/BACKUP/DICOM_FILES/AMNESIX"
extensao = ".*dcm"
novaExtensao = " "  # nesse caso eh vazia
parteQueSai = "IM-0001-"
parteQueSubstitui = "slice"

# Muda extensao
reg = re.compile(extensao)
if os.path.isdir(diretorio) and not os.path.islink(diretorio):
    arquivos = os.listdir(diretorio)
    for arquivo in arquivos:
        newExt = re.compile(extensao).match
        if newExt(arquivo):
            c = os.path.splitext(arquivo)
            b = c[0] + novaExtensao
            a = os.path.join(diretorio,arquivo)
            b = os.path.join(diretorio,b)
            os.rename(a,b)

# Modifica nome
if os.path.isdir(diretorio) and not os.path.islink(diretorio):
    arquivos = os.listdir(diretorio)
    for arquivo in arquivos:
        novoNome = string.replace(arquivo, parteQueSai, parteQueSubstitui)
        fullpathOld = os.path.join(diretorio,arquivo)
        fullpathNew = os.path.join(diretorio,novoNome)
        os.rename(fullpathOld, fullpathNew)