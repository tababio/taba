#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import glob
from time import sleep

from PyQt4 import QtGui  # Import the PyQt4 module we'll need
from PyQt4.QtGui import QApplication, QDialog
from func_Gerais import grava,  leCsv   , pegaConfig, gravaConfig, download_PDB_file, pre_download, get_Bind
import interfaceBaixaPdbs  # This file holds our MainWindow and all design related things
import func_manipulaArquivos as manip

class baixaPdbss(QtGui.QMainWindow, interfaceBaixaPdbs.Ui_MainWindowBaixaPdbs):
    def __init__(self, parent = None):
        QtGui.QWidget.__init__(self, parent)
        self.setupUi(self)
        self.carrega()
        self.window1 = None
        self.setFixedSize(800,650)
        self.label_cabecalho.setText("")
        self.label_textoProgresso.setText("")
        self.lineEdit_descricao.setText(pegaConfig("descricaoDataset"))
        self.plainTextEdit_Comentarios.setPlainText(pegaConfig("comentarios"))
        self.marcaAfinidade()
        quantia = pegaConfig("quantidadeProteinas")
        if quantia != None:
            self.label_quantia.setText(quantia.strip())
        self.desabilitaCampos()
        self.toolButton_saveText.setEnabled(False)
        self.toolButton_ClearText.setEnabled(False)
        self.toolButton_baixa.setEnabled(True)
        self.toolButton_cancela.setEnabled(False)
        self.toolButton_refina.setEnabled(False) 
        self.label_relogio.hide()
        self.textoInicalPdb = self.plainTextEdit_pdbs.toPlainText()
        self.textoInicialConfig = self.lineEdit_descricao.text()
        self.textoInicialComentarios = self.plainTextEdit_Comentarios.toPlainText()
    def marcaAfinidade(self):
        inib = pegaConfig("tipoAfinidade")
        inib = inib.replace(" ","")
        inib = inib.replace("\n","")
        if inib == "Kd":
            self.radioButton_Kd.setChecked(True)
        if inib == "Ki":
            self.radioButton_Ki.setChecked(True)
        if inib == "IC50":
            self.radioButton_IC50.setChecked(True)
        if inib == "EC50":
            self.radioButton_EC50.setChecked(True)
    
    def salva(self):
        diretorio ="./arquivosEntrada/"
        arquivo = "pdbsProteina.txt"
        arquivoSai = diretorio+arquivo
        texto = self.plainTextEdit_pdbs.toPlainText()
        texto = texto.replace(" ","")
        self.textoConfig = self.lineEdit_descricao.text()
        self.textoConfig = self.textoConfig.strip()
        if texto.endswith(','): # retira virgula se apos o texto
            texto = texto[:-1]
            self.plainTextEdit_pdbs.setPlainText(texto)
        grava(texto, arquivoSai)
        lista = leCsv(arquivoSai)
        self.quantidadeProteinas = len(lista)
        self.salvaConfig()
        self.label_quantia.setText(pegaConfig("quantidadeProteinas"))
        # define tipo inibidor
        if self.radioButton_Kd.isChecked():
            self.inibidor = "Kd"
        elif self.radioButton_Ki.isChecked():
            self.inibidor = "Ki"
        elif self.radioButton_IC50.isChecked():
            self.inibidor = "IC50"
        elif self.radioButton_EC50.isChecked():
            self.inibidor = "EC50"
        gravaConfig("tipoAfinidade", self.inibidor.strip())
        self.toolButton_baixa.setEnabled(True)
        self.desabilitaCampos()
        self.toolButton_saveText.setEnabled(False)
        self.toolButton_ClearText.setEnabled(False)
        self.toolButton_baixa.setEnabled(True)
        self.toolButton_cancela.setEnabled(False) 
        self.toolButton_edita.setEnabled(True)
        self.toolButton_refina.setEnabled(False)
        # para poder desfazer
        self.textoInicalPdb = self.plainTextEdit_pdbs.toPlainText()
        self.textoInicialConfig = self.lineEdit_descricao.text()
        self.textoInicialComentarios = self.plainTextEdit_Comentarios.toPlainText()
         
    def carrega(self):
        diretorio ="./arquivosEntrada/"
        arquivo = "pdbsProteina.txt"
        arq = diretorio+arquivo
        lista = leCsv(arq)
        texto = ', '.join(lista)
        self.plainTextEdit_pdbs.clear()
        self.plainTextEdit_pdbs.setPlainText(texto)
        
    def sair(self):        
        self.close()
        
    def limpaTexto(self):
        self.plainTextEdit_pdbs.clear()
        self.plainTextEdit_Comentarios.clear()
        self.lineEdit_descricao.clear()
    def escondeBotoes(self):
        self.toolButton_baixa.setEnabled(False)
        self.toolButton_ClearText.setEnabled(False)
        self.toolButton_saveText.setEnabled(False)
        self.toolButton_exit.setEnabled(False)
        self.plainTextEdit_pdbs.setEnabled(False)
        self.plainTextEdit_Comentarios.setEnabled(False)
        self.toolButton_edita.setEnabled(False)
        self.toolButton_cancela.setEnabled(False) 
        self.toolButton_refina.setEnabled(False) 
    def mostraBotoes(self):
        self.toolButton_baixa.setEnabled(True)
        self.toolButton_ClearText.setEnabled(True)
        self.toolButton_saveText.setEnabled(True)
        self.toolButton_exit.setEnabled(True)
        self.plainTextEdit_pdbs.setEnabled(True)
        self.plainTextEdit_Comentarios.setEnabled(True)
        self.toolButton_edita.setEnabled(True)
          
    def baixaPdb(self):
        reply = QtGui.QMessageBox.question(self, 'Message',"This operation may take several minutes. Do you want to proceed?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)

        if reply == QtGui.QMessageBox.Yes:
            self.label_relogio.show()
            self.baixaPdbOk(self)
        else:
            pass 
            
    def baixaPdbOk(self,event):
        ############ baixa PDBs ##############
        self.escondeBotoes()
        # Set up PDB url
        url_in = 'https://files.rcsb.org/download/'
        
        # Set up PDB access code
        nomePdbs=leCsv("./arquivosEntrada/pdbsProteina.txt")
        totalArquivos=nomePdbs.__len__()
        varia = 100/totalArquivos
        progresso = 0
        count=0
        contaPausa = 0
        mensagem = "Starting download PDB protein files from the site "+url_in
        self.label_cabecalho.setText(mensagem)
        self.progressBar.setValue(0)
        for linha in nomePdbs:
            QtGui.QApplication.processEvents() # para não travar
            pdb_access = linha.strip()
            mensagem = pdb_access
            self.label_textoProgresso.setText(mensagem)
            # Call download_PDB_file()
            count=count+1
            my_dir_in = "./pdbs/"
            flag_4_file_present = pre_download(my_dir_in,pdb_access+".pdb") #verifica se ja existe arquvio
            if not flag_4_file_present:                
                download_PDB_file(url_in,pdb_access+".pdb")
                progresso = progresso+varia
                self.progressBar.setValue(progresso)
                contaPausa = contaPausa+1
                if contaPausa > 100:
                    contaPausa = 0
                    mensagem = "---> pausa tecnica. Aguarde que o programa continuara a rodar automaticamente..."
                    self.label_textoProgresso.setText(mensagem)
                    sleep(30) # pausa para por exigencia do site se nao nao baixa todos               
    
        mensagem = str(count)+' files were correctly downloaded'
        self.label_textoProgresso.setText(mensagem)
        self.progressBar.setValue(100)
        ########## BAIXA ki ###################################
        # limpar diretorio
        self.progressBar.setValue(0)
        progresso = 0
        files = glob.glob('./ki/*')
        for f in files:
            os.remove(f)
     
        my_dir_in ="./ki/" # futuramente e melhor ajustar o nome do diretorio para abranger todos os inibidores
        # define tipo inibidor
        if self.radioButton_Kd.isChecked():
            self.inibidor = "Kd"
        elif self.radioButton_Ki.isChecked():
            self.inibidor = "Ki"
        elif self.radioButton_IC50.isChecked():
            self.inibidor = "IC50"
        elif self.radioButton_EC50.isChecked():
            self.inibidor = "EC50"
        binding_info = self.inibidor
        # Set up PDB url
        url_in = 'http://files.rcsb.org/download/'
    
        # Set up PDB access code
        nomePdbs=leCsv("./arquivosEntrada/pdbsProteina.txt")
        totalArquivos=nomePdbs.__len__()
        count=0
        mensagem = "Starting download PDB "+binding_info+" files (constant interation):"+url_in
        self.label_cabecalho.setText(mensagem)
        for linha in nomePdbs:
            pdb_access = linha.strip()
            mensagem = "File: "+pdb_access
            self.label_textoProgresso.setText(mensagem)
            QtGui.QApplication.processEvents() # para não travar
            structureId = linha.strip()
            # Call download_PDB_file()
            get_Bind(my_dir_in,structureId,binding_info)
            progresso = progresso+varia
            self.progressBar.setValue(progresso)
        ## muda cor caixa texto
        self.progressBar.setValue(100)
        self.label_relogio.hide()
        QtGui.QMessageBox.information(self, "Message", "Operation completed")
        self.mostraBotoes() 
        self.toolButton_ClearText.setEnabled(False)
        self.toolButton_saveText.setEnabled(False)
          
               
    def edita(self):
        self.habilitaCampos()
        self.toolButton_saveText.setEnabled(True)
        self.toolButton_ClearText.setEnabled(True)
        self.toolButton_baixa.setEnabled(False)
        self.toolButton_cancela.setEnabled(True)
        self.toolButton_edita.setEnabled(False)
        self.toolButton_refina.setEnabled(True)
         
    def cancela(self):
        self.plainTextEdit_pdbs.setPlainText(self.textoInicalPdb)
        self.plainTextEdit_Comentarios.setPlainText(self.textoInicialComentarios)
        self.lineEdit_descricao.setText(self.textoInicialConfig)
        self.toolButton_baixa.setEnabled(True)
        self.desabilitaCampos()
        self.toolButton_saveText.setEnabled(False)
        self.toolButton_ClearText.setEnabled(False)
        self.toolButton_baixa.setEnabled(True)  
        self.toolButton_cancela.setEnabled(False) 
        self.toolButton_edita.setEnabled(True)
        self.toolButton_refina.setEnabled(False)
    def desabilitaCampos(self):
        self.plainTextEdit_pdbs.setDisabled(True)
        self.plainTextEdit_Comentarios.setDisabled(True)
        self.groupBox.setDisabled(True)
        self.lineEdit_descricao.setDisabled(True)
    def habilitaCampos(self):
        self.plainTextEdit_pdbs.setDisabled(False)
        self.plainTextEdit_Comentarios.setDisabled(False)
        self.groupBox.setDisabled(False)
        self.lineEdit_descricao.setDisabled(False)   
    def salvaConfig(self):
        gravaConfig("quantidadeProteinas", str(self.quantidadeProteinas))        
        gravaConfig("descricaoDataset",self.textoConfig)
        textoComent = self.plainTextEdit_Comentarios.toPlainText()
        #textoComent = textoComent.replace("\n","")
        gravaConfig("comentarios", textoComent)
    def retira(self):     
        texto = self.plainTextEdit_pdbs.toPlainText() 
        lista = texto.split()
        listaNova = []
        remove = False
        for s in lista:
            if not s in listaNova:
                listaNova.append(s)
            else:
                remove = True
        texto = ','.join(listaNova)
        texto = texto.replace(",,",", ")
        self.plainTextEdit_pdbs.setPlainText(texto) 
        if remove: # houve exclusao de estrutura entao tem que apagar arquivos antigos de sf
            # remove pastas existentes
            pasta = "./arquivosSaida/"
            manip.removePasta(pasta)
            # cria novas pastas
            nomePasta = "./arquivosSaida/"
            manip.criaPasta(nomePasta)  
            QtGui.QMessageBox.information(self, "Message", "Operation completed. Remember to save this new set.")
        else:
            QtGui.QMessageBox.information(self, "Message", "There is no repeated structure.")  
        self.toolButton_refina.setEnabled(False) 