# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'interfaceDialogBaixaPdb.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui


try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog_baixaPdb(object):
    def setupUi(self, Dialog_baixaPdb):
        Dialog_baixaPdb.setObjectName(_fromUtf8("Dialog_baixaPdb"))
        Dialog_baixaPdb.resize(400, 195)
        self.buttonBox = QtGui.QDialogButtonBox(Dialog_baixaPdb)
        self.buttonBox.setGeometry(QtCore.QRect(30, 130, 341, 32))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.label = QtGui.QLabel(Dialog_baixaPdb)
        self.label.setGeometry(QtCore.QRect(90, 70, 221, 17))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))

        self.retranslateUi(Dialog_baixaPdb)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), Dialog_baixaPdb.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), Dialog_baixaPdb.reject)
        QtCore.QObject.connect(Dialog_baixaPdb, QtCore.SIGNAL(_fromUtf8("accepted()")), Dialog_baixaPdb.accept)
        QtCore.QObject.connect(Dialog_baixaPdb, QtCore.SIGNAL(_fromUtf8("rejected()")), Dialog_baixaPdb.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog_baixaPdb)

    def retranslateUi(self, Dialog_baixaPdb):
        Dialog_baixaPdb.setWindowTitle(_translate("Dialog_baixaPdb", "Download PDB", None))
        self.label.setText(_translate("Dialog_baixaPdb", "Start download PDBs now?", None))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    Dialog_baixaPdb = QtGui.QDialog()
    ui = Ui_Dialog_baixaPdb()
    ui.setupUi(Dialog_baixaPdb)
    Dialog_baixaPdb.show()
    sys.exit(app.exec_())

