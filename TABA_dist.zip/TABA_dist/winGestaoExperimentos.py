#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import func_manipulaArquivos as manip
from datetime import datetime
from PyQt4 import QtGui # Import the PyQt4 module we'll need
import interfaceGestaoExperimentos
import os
from func_manipulaArquivos import existeArquivo
from func_Gerais import pegaConfig, get_pastas, gravaConfig, completaArquivoConfig, existeArquivo, grava, get_platform, converteStringDeltaG, get_desktop_path

class gestaoExperimentos(QtGui.QMainWindow, interfaceGestaoExperimentos.Ui_MainWindow_manageFiles):
    def __init__(self, parent = None):
                   
        QtGui.QWidget.__init__(self, parent)
        self.setupUi(self)
        self.window1 = None
        self.setFixedSize(950,620)        
        nome = pegaConfig("nomeExperimento").strip()
        self.label_outliers.setText(pegaConfig("outlier").strip()) 
        self.label_estruturaInicial.setText(pegaConfig("quantidadeInicialProteinas").strip())  
        self.listaExperimentos = []
        now = str(datetime.now())
        now = now.replace(" ", "")
        now = now.replace("-", "")
        now = now.replace(":", "")
        d = "_"+now[0:14]
        self.atualizaNomes()
        self.atualizaNomesDeletar()
        self.lineEdit_experimento.setText(nome+d)
        self.recuperaInfos()
        
        self.label_relogio.hide()  
        self.movie = QtGui.QMovie("./img/gifTempo.gif")
        self.label_relogio.setMovie(self.movie)
        if pegaConfig('atalho').strip() == 'yes':
            self.checkBox_atalho.setChecked(True)
        else:
            self.checkBox_atalho.setChecked(False)
        if not ('LINUX' in get_platform().upper()): # ve se nao e linux e esconde botal de criacao de atalho
            self.checkBox_atalho.hide()
        else:
            if self.checkBox_atalho.isChecked():
                self.criaAtalho()
            
    def atualizaNomes(self):
        self.list1 = get_pastas("./setsExperiments/")
        self.comboBox_arquivos.clear()
        for text in self.list1:
            text = text.replace("./setsExperiments/","")
            self.listaExperimentos.append(text)
            self.comboBox_arquivos.addItem(text) # pega so arquivos de treino
            self.comboBox_arquivos.model().sort(0)
            self.comboBox_arquivos.setCurrentIndex(1)
    def atualizaNomesDeletar(self):
        self.list1 = get_pastas("./setsExperiments/")
        self.comboBox_deletaArquivos.clear()
        for text in self.list1:
            text = text.replace("./setsExperiments/","")
            self.listaExperimentos.append(text)
            self.comboBox_deletaArquivos.addItem(text) # pega so arquivos de treino
            self.comboBox_deletaArquivos.model().sort(0)
            self.comboBox_deletaArquivos.setCurrentIndex(1) 
    def salvarExperimentos(self): 
        self.listaExperimentos = []
        self.list1 = get_pastas("./setsExperiments/")
        for text in self.list1:
            text = text.replace("./setsExperiments/","")
            self.listaExperimentos.append(text)

        # cria pasta para novo conjunto
        self.nomeConjunto = self.lineEdit_experimento.text()
        if self.nomeConjunto in self.listaExperimentos:
            reply = QtGui.QMessageBox.question(self, 'Message',"This set of experiments already exists. Do you want to replace?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
            if reply == QtGui.QMessageBox.Yes:
                self.salva()
                
        else:
            self.label_relogio.show() 
            self.movie.start()
            self.salva()
            self.label_relogio.hide()  
            self.movie.stop()
        pass
    def salva(self):
        pastaParaSalvar = "TABA/setsExperiments/"+self.nomeConjunto
        reply = QtGui.QMessageBox.question(self, 'Message',"If you want, you can change the name of the experiment in the box next to it."+"\n"+"\n"+"All files from this experiment will be saved in: "+pastaParaSalvar+"\n"+"\n"+"Do you really want to save this experiment?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
        if reply == QtGui.QMessageBox.Yes:        
            
            nomePasta = "./setsExperiments/"+self.nomeConjunto
            gravaConfig("nomeExperimento", self.nomeConjunto)
            manip.criaPasta(nomePasta)
            # copia pastas para o novo conjunto
            origem = "./outputFiles/"
            destino = nomePasta+origem.replace(".", "")
            manip.copiaPasta(origem, destino)
            origem = "./pdbs/"
            destino = nomePasta+origem.replace(".", "")
            manip.copiaPasta(origem, destino)
            origem = "./ki/"
            destino = nomePasta+origem.replace(".", "")
            manip.copiaPasta(origem, destino)
            origem = "./inputFiles/"
            destino = nomePasta+origem.replace(".", "")
            manip.copiaPasta(origem, destino)
            origem = "./models/"
            destino = nomePasta+origem.replace(".", "")
            manip.copiaPasta(origem, destino)
            origem = "./results/"
            destino = nomePasta+origem.replace(".", "")
            manip.copiaPasta(origem, destino)
            self.atualizaNomes()
            self.atualizaNomesDeletar()
            experimento = pegaConfig("nomeExperimento").strip()
            self.label_experimento.setText(experimento)
            QtGui.QMessageBox.information(self, "Message", "Operation completed")
            data = datetime.now()
            data = str(data.strftime("%Y-%m-%d   %H:%M:%S"))
            print(data)
            gravaConfig("data", data)
            self.recuperaInfos()
        else:
            pass              

    def recuperarExperimentos(self):
        self.escondeBotoes()
        reply = QtGui.QMessageBox.question(self, 'Message',"Attention: It is important to save the current experiment before!!!"+"\n"+"\n"+"Do you really want to recover this experiment?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
        if reply == QtGui.QMessageBox.Yes:
            QtGui.QApplication.processEvents() # para não travar usar antes de loops   
            self.label_relogio.show()  
            self.movie.start()
            QtGui.QApplication.processEvents() # para não travar   
            self.nomeConjunto = self.comboBox_arquivos.currentText()
            # copia pastas para o novo conjunto
            origem = "./setsExperiments/"+self.nomeConjunto+"/outputFiles/"
            destino = "./outputFiles/"
            manip.copiaPasta(origem, destino)
            origem = "./setsExperiments/"+self.nomeConjunto+"/pdbs/"
            destino = "./pdbs/"
            manip.copiaPasta(origem, destino)
            origem =  "./setsExperiments/"+self.nomeConjunto+"/ki/"
            destino = "./ki/"
            manip.copiaPasta(origem, destino)
            origem =  "./setsExperiments/"+self.nomeConjunto+"/inputFiles/"
            destino = "./inputFiles/"
            manip.copiaPasta(origem, destino)
            origem =  "./setsExperiments/"+self.nomeConjunto+"/models/"
            destino = "./models/"
            manip.copiaPasta(origem, destino)
            self.recuperaInfos()
            now = str(datetime.now())
            now = now.replace(" ", "")
            now = now.replace("-", "")
            now = now.replace(":", "")
            d = "_"+now[0:14]
            self.lineEdit_experimento.setText(pegaConfig("nomeExperimento").strip()+d)
            self.label_comentarios.setText(pegaConfig("comentarios").replace("<vg>", ","))
            self.label_quantia.setText(pegaConfig("quantidadeProteinas").strip())
            self.label_estruturaInicial.setText(pegaConfig("quantidadeInicialProteinas").strip()) 
            QtGui.QMessageBox.information(self, "Message", "Operation completed")
            self.label_relogio.hide()  
            self.movie.stop
            self.mostraBotoes()
            self.label_outliers.setText(pegaConfig("outlier").strip())  
        else:
            self.mostraBotoes()
            pass            
        
                
    def sair(self):        
        self.close()
        
                
    def escondeBotoes(self):
        self.pushButton_salvar.setEnabled(False)
        self.pushButton_recuperar.setEnabled(False)
        self.toolButton_exit.setEnabled(False)
    def mostraBotoes(self):
        self.pushButton_salvar.setEnabled(True)
        self.pushButton_recuperar.setEnabled(True)
        self.toolButton_exit.setEnabled(True)
        

    def recuperaInfos(self):
        
        completaArquivoConfig()
        descricao = pegaConfig("descricaoDataset").strip()
        afinidade = pegaConfig("tipoAfinidade").strip()
        afinidade = converteStringDeltaG(afinidade)
        data = pegaConfig("data").strip()
        experimento = pegaConfig("nomeExperimento").strip()
        self.label_descricao.setText(descricao)
        self.label_afinidade.setText(afinidade)
        self.label_toExperiment.setText("To experiment: "+experimento)
        self.label_experimento.setText(experimento)
        self.label_experimento.setText(experimento)
        self.label_data.setText(data)
        excluiLigantes = pegaConfig("excluiLigantes").strip()
        if excluiLigantes != "yes":
            self.label_deleteLigand.setText("no")
        else:
            self.label_deleteLigand.setText("yes")
        if not(pegaConfig("spearman") is None):
            self.label_comentarios.setText(pegaConfig("comentarios").replace("<vg>", ","))
            self.label_spearman.setText(pegaConfig("spearman").strip())
            self.label_melhorEquacao.setText(pegaConfig("melhorEquacao").strip())
            self.label_quantia.setText(pegaConfig("quantidadeProteinas").strip())
        else:
            self.label_comentarios.setText("null")
            self.label_spearman.setText("null")
            self.label_melhorEquacao.setText("null")
            self.label_quantia.setText("null")
            
    def deletar(self): 
        self.escondeBotoes()
        reply = QtGui.QMessageBox.question(self, 'Message',"Do you really want to delete this experiment from 'setsExperiments' folder?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
        if reply == QtGui.QMessageBox.Yes: 
            self.label_relogio.show()    
            self.movie.start()
            self.nomeConjunto = self.comboBox_deletaArquivos.currentText()
            # copia pastas para o novo conjunto
            pasta = "./setsExperiments/"+self.nomeConjunto
            manip.removePasta(pasta)
            QtGui.QMessageBox.information(self, "Message", "Operation completed")
            self.mostraBotoes()
            self.atualizaNomes()
            self.atualizaNomesDeletar()
            self.label_relogio.hide() 
            self.movie.stop()
        else:
            self.mostraBotoes()
             
            pass
    
    def criaAtalho(self):  
        if self.checkBox_atalho.isChecked():
                gravaConfig("atalho", "yes")                
        else:
            gravaConfig("atalho", "no")
        if self.checkBox_atalho.isChecked():
            desktop = get_desktop_path()
            dirAtual = os.getcwd()+"/"
            dirBase = os.path.dirname(os.path.dirname(dirAtual)) # pega o diretorio acima do Taba
            programa = "./Taba"
            fonte = "python3 taba.py" 
            icone = "img/beagle3.png"
            arquivoAtalho = desktop+"/Taba.desktop"
            if existeArquivo(dirAtual+"taba.py"):
                textoScript = "#! /bin/bash"+"\n"+"cd "+dirAtual+"\n"+fonte              
            else:
                textoScript = "#! /bin/bash"+"\n"+"cd "+dirAtual+"\n"+programa   
            if existeArquivo(arquivoAtalho) == False:
                reply = QtGui.QMessageBox.question(self, "Create a desktop shortcut","Do you want to create a shortcut on the desktop?"+"\n"+"If you do not want to see this message again, uncheck 'Create a shortcut on the desktop' at the bottom of this window", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
                if reply == QtGui.QMessageBox.Yes:
                    if desktop.strip() == dirBase.strip(): # nao e possivel criar icone quando o taba esta no desktop
                        QtGui.QMessageBox.information(self, "Attention!", "It is not possible to create a shortcut when the Taba folder is on the Desktop."+"\n"+\
                        "Move the Taba folder to another location in the user's folder and check 'Create a shortcut on the desktop' at the bottom of the screen again.")
                        gravaConfig("atalho", "no")
                        self.checkBox_atalho.setChecked(False)                         
                        pass
                    else:
                        TextoLancador = "[Desktop Entry]"+"\n"+"Name=Taba"+"\n"+"Type=Application"+"\n"+"Exec=sh "+dirAtual+"taba.sh"+"\n"+"Icon="+dirAtual+icone
                        grava(textoScript, "./taba.sh")
                        grava(TextoLancador, arquivoAtalho)
                        os.chmod(arquivoAtalho, 0o777)# muda permissao
                        QtGui.QMessageBox.information(self, "Message", "The shortcut to Taba was created on the desktop!")
                else:
                    pass
            else:
                pass
        else:
            pass  
    def apagaArquivos(self):
        if (self.radioButton_1.isChecked()) or (self.radioButton_2.isChecked()) or (self.radioButton_3.isChecked()) or (self.radioButton_4.isChecked()):
            self.apagaArquivosOk()
        else:
            QtGui.QMessageBox.information(self, "Message", "You must select a option first!")
            pass
    def apagaArquivosOk(self):
        reply = QtGui.QMessageBox.question(self, 'Message',"Do you really want to delete selected files?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
        if reply == QtGui.QMessageBox.Yes:
            if self.radioButton_4.isChecked():            
                manip.apagaArquivos("./pdbs")
                manip.apagaArquivos("./ki")
                manip.apagaArquivos("./outputFiles")
                manip.apagaArquivos("./models")
                manip.apagaArquivos("./results")
   
            if self.radioButton_3.isChecked():
                manip.apagaArquivos("./outputFiles")
                manip.apagaArquivos("./models")
                manip.apagaArquivos("./results")
   
            if self.radioButton_2.isChecked():
                arqOutput = manip.arquivosNaPastaOutput()
                dir = "./outputFiles/"
                for i in arqOutput:
                    if "SF_saida" in i:
                        manip.apagaArquivo(dir+i)
                manip.apagaArquivos("./models")
                manip.apagaArquivos("./results")
                
            if self.radioButton_1.isChecked():
                manip.apagaArquivos("./models")
                manip.apagaArquivos("./results")
                
            QtGui.QMessageBox.information(self, "Message", "The selected files have been deleted!")
            self.limpaRadioButtons()
        else:
            pass
    def limpaRadioButtons(self):
        self.radioButton_1.setAutoExclusive(False)
        self.radioButton_1.setChecked(False)
        self.radioButton_1.setAutoExclusive(True)
        self.radioButton_2.setAutoExclusive(False)
        self.radioButton_2.setChecked(False)
        self.radioButton_2.setAutoExclusive(True)
        self.radioButton_3.setAutoExclusive(False)
        self.radioButton_3.setChecked(False)
        self.radioButton_3.setAutoExclusive(True)
        self.radioButton_4.setAutoExclusive(False)
        self.radioButton_4.setChecked(False)
        self.radioButton_4.setAutoExclusive(True)

        
    