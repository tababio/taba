from func_ContaInterMolLeArquivos import read_PDB_return_coord_and_lines
from func_Gerais import leCsv, grava, leCsvPulaLinha
import numpy as np
from scipy.constants.constants import atm

import csv



def inter_mol_term(proteina,ligante,distancia,conjunto,tipoMedia):
    """Funcao para calcular o termo de energia"""
    
    #tam=int(51) # incluido + 17 pontes de agua
    tam=int(34)
    termoDeEnergia = np.zeros(tam,dtype = float)
    # Call read_PDB_return_coor_and_lines()
    x1,y1,z1,l1 = read_PDB_return_coord_and_lines(proteina)
    x2,y2,z2,l2 = read_PDB_return_coord_and_lines(ligante)
   
    #print ("x1----------------------------->",x1,y1,z1,l1,x2,y2)
    # Get the length of the arrays
    n1 = len(x1)
    n2 = len(x2)

# CC CN  CO  CS  CP  CF  CBR CCL CI  CAT
    # NN  NO  NS  NP  NF  NBR NCL NI  NAT
        # OO  OS  OP  OF  OBR OCL OI  OAT
            # SS  SP  SF  SBR SCL SI  SAT
# NHOHN  NHOHO  NHOHS  NHOHP  NHOHF  NHOHBR NHOHCL NHOHI  NHOHAT  ** para pontes de agua
# OHOHO  OHOHS  OHOHP  OHOHF  OHOHBR OHOHCL OHOHI  OHOHAT       ** para pontes de agua
    atomos = ['CC','CN','CO','CS','CP','CF','CBr','CCl','CI','CAt','NN','NO','NS','NP','NF','NBr','NCl','NI','NAt','OO','OS','OP','OF','OBr','OCl','OI','OAt','SS','SP','SF','SBr','SCl','SI','SAt']
    '''
    # teste
       cont = 0
        for i in range(0,n1): 
            print((l1[i][12:14]))
            if (l1[i][12:14]).strip() != (l1[i][12:14]).strip():
                cont = cont+1
        print(cont)
    # fim teste        
    '''        
    # Gera dados para calcular a média de distancia de cada interacao
    
    
     
    '''    
    Calcula termo de energia utilizando o vetor de medias calculadas acima
    O calculo eh feito da seguinte forma:
    somatorio(((d-m)*2) -> somatorio dos quadrados das diferencas
    d=distancia da iteracao de um atomo "X" com um atomo "Y"
    m=media da soma distancias de todas as interacoes de um atomo "X" com outros atomos
    '''
    if tipoMedia == "TRE": # vai considera somente o conjunto treino para calcular a media
        conj = "TRE"

    else:
        conj = conjunto.upper()

    diret = "./outputFiles/"
    fileName = "medDist_"+str(distancia)+"_"+conj+".csv"
    file = diret+fileName
    texto = leCsvPulaLinha(file)

    media = []
    for item in texto: # gera vetor de medias
        media.append(float(item))
           
    for i in range(n1):
        for j in range(n2):
            d =  np.sqrt( (x1[i] - x2[j] )**2 + (y1[i] - y2[j])**2 + (z1[i] - z2[j])**2 )  
            if d <= distancia:
#---------- CC CN  CO  CS  CP  CF  CBR CCL CI  CAT  
                
                if (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "C":
                    termoDeEnergia[0] = termoDeEnergia[0]+(((d-media[0]))**2)
                elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "N":
                    termoDeEnergia[1] = termoDeEnergia[1]+(((d-media[1]))**2)                    
                elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "O":
                    termoDeEnergia[2] = termoDeEnergia[2]+(((d-media[2]))**2)                         
                elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "S":
                    termoDeEnergia[3] = termoDeEnergia[3]+(((d-media[3]))**2)    
                elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "P":
                    termoDeEnergia[4] = termoDeEnergia[4]+(((d-media[4]))**2)                        
                elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "F": 
                    termoDeEnergia[5] = termoDeEnergia[5]+(((d-media[5]))**2)     
                elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "Br":
                    termoDeEnergia[6] = termoDeEnergia[6]+(((d-media[6]))**2)     
                elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "Cl":
                    termoDeEnergia[7] = termoDeEnergia[7]+(((d-media[7]))**2)                           
                elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "I":
                    termoDeEnergia[8] = termoDeEnergia[8]+(((d-media[8]))**2)  
                elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "At":
                    termoDeEnergia[9] = termoDeEnergia[9]+(((d-media[9]))**2)                      
                #---------- NN  NO  NS  NP  NF  NBR NCL NI  NAT
                elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "N":  
                    termoDeEnergia[10] = termoDeEnergia[10]+(((d-media[10]))**2)     
                elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "O":
                    termoDeEnergia[11] = termoDeEnergia[11]+(((d-media[11]))**2) 
                elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "S":
                    termoDeEnergia[12] = termoDeEnergia[12]+(((d-media[12]))**2) 
                elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "P":
                    termoDeEnergia[13] = termoDeEnergia[13]+(((d-media[13]))**2)                 
                elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "F":
                    termoDeEnergia[14] = termoDeEnergia[14]+(((d-media[14]))**2)  
                elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "Br":
                    termoDeEnergia[15] = termoDeEnergia[15]+(((d-media[15]))**2) 
                elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "Cl":
                    termoDeEnergia[16] = termoDeEnergia[16]+(((d-media[16]))**2) 
                elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "I":
                    termoDeEnergia[17] = termoDeEnergia[17]+(((d-media[17]))**2) 
                elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "At":
                    termoDeEnergia[18] = termoDeEnergia[18]+(((d-media[18]))**2)  
                #-------- OO  OS  OP  OF  OBR OCL OI  OAT 
                elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "O":  
                    termoDeEnergia[19] = termoDeEnergia[19]+(((d-media[19]))**2) 
                elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "S":
                    termoDeEnergia[20] = termoDeEnergia[20]+(((d-media[20]))**2)  
                elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "P":
                    termoDeEnergia[21] = termoDeEnergia[21]+(((d-media[21]))**2)                    
                elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "F":
                    termoDeEnergia[22] = termoDeEnergia[22]+(((d-media[22]))**2)               
                elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "Br":
                    termoDeEnergia[23] = termoDeEnergia[23]+(((d-media[23]))**2) 
                elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "Cl":
                    termoDeEnergia[24] = termoDeEnergia[24]+(((d-media[24]))**2)                                                
                elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "I":
                    termoDeEnergia[25] = termoDeEnergia[25]+(((d-media[25]))**2)  
                elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "At":
                    termoDeEnergia[26] = termoDeEnergia[26]+(((d-media[26]))**2)                                                
                #-------- SS  SP  SF  SBR SCL SI  SAT
                elif (l1[i][12:14]).strip() == "S" and (l2[j][12:14]).strip() == "S":  
                    termoDeEnergia[27] = termoDeEnergia[27]+(((d-media[27]))**2)  
                elif (l1[i][12:14]).strip() == "S" and (l2[j][12:14]).strip() == "P" :
                    termoDeEnergia[28] = termoDeEnergia[28]+(((d-media[28]))**2)                    
                elif (l1[i][12:14]).strip() == "S" and (l2[j][12:14]).strip() == "F" :
                    termoDeEnergia[29] = termoDeEnergia[29]+(((d-media[29]))**2)  
                elif (l1[i][12:14]).strip() == "S" and (l2[j][12:14]).strip() == "Br":
                    termoDeEnergia[30] = termoDeEnergia[30]+(((d-media[30]))**2)  
                elif (l1[i][12:14]).strip() == "S" and (l2[j][12:14]).strip() == "Cl":
                    termoDeEnergia[31] = termoDeEnergia[31]+(((d-media[31]))**2)     
                elif (l1[i][12:14]).strip() == "S" and (l2[j][12:14]).strip() == "I":
                    termoDeEnergia[32] = termoDeEnergia[32]+(((d-media[32]))**2)    
                elif (l1[i][12:14]).strip() == "S" and (l2[j][12:14]).strip() == "At":
                    termoDeEnergia[33] = termoDeEnergia[33]+(((d-media[33]))**2)
    '''              
    print ("------->> cc :",termoDeEnergia[0])
    print ("------->> NN :",termoDeEnergia[10])
    print ("------->> CBr :",termoDeEnergia[6])
    print ("------->> CO :",termoDeEnergia[2])
    print ("------->> OO :",termoDeEnergia[19])
    print ("------->> NO :",termoDeEnergia[11])
    '''
    '''
    print(proteina,ligante,distancia)
    print ("------->> NO :",media[11])
    '''
    return termoDeEnergia,atomos
def calc_average_distance(arquivosParaLer,distancia,conjunto):
    # conjunto -> qual o conjunto que e para fazer a distancia media
    """
    calcula a media da distancia entre os atomos que satisfazem uma distancia.
    o paramentro dataSet diz qual dataset sera utilizado para calcular a distancia:
    podera usar somente o arquivo treino ou podera calcular individualmente nos arquivos de treino testese e experimento do usuario
    """
    tam=int(34)
    conta = np.zeros(tam,dtype = int)
    soma = np.zeros(tam,dtype = float)
    for prot in arquivosParaLer:

        diretorio = "./pdbs/"
        arquivo = prot.strip() # nome do arquivo pdb que est'em pdbsProteinas
        arquivo = arquivo.lower()
        protArq=diretorio+arquivo+"_soAtom.pdb" # coloca a terminacao para ler o arquivo so de proteinas que foram separados
        ligArq=diretorio+arquivo+"_soHetatm.pdb" # coloca a terminacao para ler o arquivo so de ligantes que foram separados
        #parAtm = ['CC','CN','CO','CS','CP','CF','CBr','CCl','CI','CAt','NN','NO','NS','NP','NF','NBr','NCl','NI','NAt','OO','OS','OP','OF','OBr','OCl','OI','OAt','SS','SP','SF','SBr','SCl','SI','SAt'] 
        # Call read_PDB_return_coor_and_lines()
        x1,y1,z1,l1 = read_PDB_return_coord_and_lines(protArq)
        x2,y2,z2,l2 = read_PDB_return_coord_and_lines(ligArq)
   
        #print ("x1----------------------------->",x1,y1,z1,l1,x2,y2)
        # Get the length of the arrays
        n1 = len(x1)
        n2 = len(x2)
        for i in range(n1): # proteinas
            for j in range(n2): # ligantes
                d =  np.sqrt( (x1[i] - x2[j] )**2 + (y1[i] - y2[j])**2 + (z1[i] - z2[j])**2)
                if d <= distancia:

#---------- CC CN  CO  CS  CP  CF  CBR CCL CI  CAT  

                    if (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip()  == "C":
                        conta[0] += 1
                        soma[0] = soma[0]+d                   
                    elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "N":
                        conta[1] += 1
                        soma[1] = soma[1]+d                                 
                    elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "O":
                        conta[2] += 1
                        soma[2] = soma[2]+d                     
                    elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "S":
                        conta[3] += 1
                        soma[3] = soma[3]+d 
                    elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "P":
                        conta[4] += 1
                        soma[4] = soma[4]+d
                    elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "F": 
                        conta[5] += 1
                        soma[5] = soma[5]+d 
                    elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "Br":
                        conta[6] += 1
                        soma[6] = soma[6]+d  
                    elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "Cl":
                        conta[7] += 1
                        soma[7] = soma[7]+d                      
                    elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "I":                    
                        conta[8] += 1
                        soma[8] = soma[8]+d  
                    elif (l1[i][12:14]).strip() == "C" and (l2[j][12:14]).strip() == "At":
                        conta[9] += 1
                        soma[9] = soma[9]+d                  
                    #---------- NN  NO  NS  NP  NF  NBR NCL NI  NAT
                    elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "N":  
                        conta[10] += 1
                        soma[10] = soma[10]+d 
                    elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "O":
                        conta[11] += 1
                        soma[11] = soma[11]+d
                    elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "S":
                        conta[12] += 1
                        soma[12] = soma[12]+d
                    elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "P":
                        conta[13] += 1
                        soma[13] = soma[13]+d            
                    elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "F":
                        conta[14] += 1
                        soma[14] = soma[14]+d 
                    elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "Br":
                        conta[15] += 1
                        soma[15] = soma[15]+d 
                    elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "Cl":
                        conta[16] += 1
                        soma[16] = soma[16]+d
                    elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "I":
                        conta[17] += 1
                        soma[17] = soma[17]+d 
                    elif (l1[i][12:14]).strip() == "N" and (l2[j][12:14]).strip() == "At":
                        conta[18] += 1
                        soma[181] = soma[18]+d 
                    #-------- OO  OS  OP  OF  OBR OCL OI  OAT 
                    elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "O":  
                        conta[19] += 1
                        soma[19] = soma[19]+d 
                    elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "S":
                        conta[20] += 1
                        soma[20] = soma[20]+d 
                    elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "P":
                        conta[21] += 1
                        soma[21] = soma[21]+d            
                    elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "F":
                        conta[22] += 1
                        soma[22] = soma[22]+d        
                    elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "Br":
                        conta[23] += 1
                        soma[23] = soma[23]+d 
                    elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "Cl":
                        conta[24] += 1
                        soma[24] = soma[24]+d                                         
                    elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "I":
                        conta[25] += 1
                        soma[25] = soma[25]+d 
                    elif (l1[i][12:14]).strip() == "O" and (l2[j][12:14]).strip() == "At":
                        conta[26] += 1
                        soma[26] = soma[26]+d                                          
                    #-------- SS  SP  SF  SBR SCL SI  SAT
                    elif (l1[i][12:14]).strip() == "S" and (l2[j][12:14]).strip() == "S":  
                        conta[27] += 1
                        soma[27] = soma[27]+d 
                    elif (l1[i][12:14]).strip() == "S" and (l2[j][12:14]).strip() == "P" :
                        conta[28] += 1
                        soma[28] = soma[28]+d               
                    elif (l1[i][12:14]).strip() == "S" and (l2[j][12:14]).strip() == "F" :
                        conta[29] += 1
                        soma[29] = soma[29]+d 
                    elif (l1[i][12:14]).strip() == "S" and (l2[j][12:14]).strip() == "Br":
                        conta[30] += 1
                        soma[30] = soma[30]+d 
                    elif (l1[i][12:14]).strip() == "S" and (l2[j][12:14]).strip() == "Cl":
                        conta[31] += 1
                        soma[31] = soma[31]+d     
                    elif (l1[i][12:14]).strip() == "S" and (l2[j][12:14]).strip() == "I":
                        conta[32] += 1
                        soma[32] = soma[32]+d 
                    elif (l1[i][12:14]).strip() == "S" and (l2[j][12:14]).strip() == "At":
                        conta[33] += 1
                        soma[33] = soma[33]+d                                                                                                               
           
    #calcula media de cada interacao com os dados gerados acima
    texto = ''
    for a in range(33):  
        if conta[a]>0:    # verifica se existe media 
            med = soma[a]/conta[a] #vetor com as medias 
        else:
            med = 0
        texto =  texto+str(med)+","
    texto = texto[:-1]
    diret = "./outputFiles/"
    strDist = str(distancia)   
    conj = conjunto.upper()
    arquivoSai = diret+'medDist_'+strDist+'_'+conj+'.csv'
    atm =  "CC,CN,CO,CS,CP,CF,CBr,CCl,CI,CAt,NN,NO,NS,NP,NF,NBr,NCl,NI,NAt,OO,OS,OP,OF,OBr,OCl,OI,OAt,SS,SP,SF,SBr,SCl,SI,SAt"
    
    texto = atm+"\n"+texto
    grava(texto, arquivoSai)


    ##############################
'''
def main():
    inter_mol_term("./pdbs/4fev_soAtom.pdb","./pdbs/4fev_soHetatm.pdb" ,4.5)
main()
'''
