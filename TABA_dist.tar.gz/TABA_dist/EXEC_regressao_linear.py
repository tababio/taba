# Program to generate a regression model based on scikit-learn methods
# The input file is a CSV file where the first columns are for explanatory variables and
# the last column is for the response variable for activity information.
#
# Prof. Walter F. de Azevedo Jr.
# azevedolab.net
#
from func_RenomeiaArq import diretorio
from func_Sf import *
from func_Calcula import *
import sys

def main():
    diretorio = "./arquivosSaida/"
    #parametros para alterar    
    num_col = 5 #numero de colunas a serem incluídas na equacao + coluna logKi
    #--------------------------------------------------------------
    #--------metodos-----------
    #metodo = "LinearRegression"
    #metodo = "Ridge"
    #metodo = "RidgeCV"
    #metodo = "Lasso"
    #metodo = "LassoCV"
    #metodo = "ElasticNet"
    #metodo = "ElasticNetCV"
    
    # Set up csv file name
    #---------Arquivos pela quantidade de ocorrẽncias <= distancia
    #arquivo = "saidaKiBDB3.5.csv"
    #arquivo = "saidaKiPDBbind3.5.csv"
    #arquivo = "saidaKiBMOAD3.5.csv"
    #arquivo = "saidaKiTodos3.5.csv"    
   
    #arquivo = "saidaKiBDB4.5.csv"
    #arquivo = "saidaKiPDBbind4.5.csv"
    #arquivo = "saidaKiBMOAD4.5.csv"
    #arquivo = "saidaKiTodos4.5.csv"
    
    #arquivo = "saidaKiBDB6.0.csv"
    #arquivo = "saidaKiPDBbind6.0.csv"
    #arquivo = "saidaKiBMOAD6.0.csv"
    #arquivo = "saidaKiTodos6.0.csv"
    
    #arquivo = "saidaKiBDB7.5.csv"
    #arquivo = "saidaKiPDBbind7.5.csv"
    #arquivo = "saidaKiBMOAD7.5.csv"
    #arquivo = "saidaKiTodos7.5.csv"
    
    #arquivo = "saidaKiBDB9.0.csv"
    #arquivo = "saidaKiPDBbind9.0.csv"
    #arquivo = "saidaKiBMOAD9.0.csv"
    #arquivo = "saidaKiTodos9.0.csv"
    
    #---------Arquivos com termo de energia
    
    #arquivo = "saidaKiBDB3.5_TE_Tre.csv"
    #arquivo = "saidaKiPDBbind3.5_TE_Tre.csv"
    #arquivo = "saidaKiBMOAD3.5_TE_Tre.csv"
    #arquivo = "saidaKiTodos3.5_TE_Tre.csv"
       
    #arquivo = "saidaKiBDB4.5_TE_Tre.csv"
    #arquivo = "saidaKiPDBbind4.5_TE_Tre.csv"
    #arquivo = "saidaKiBMOAD4.5_TE_Tre.csv"
    arquivo = "saidaKiTodos4.5_TE_Tre.csv"
    
    #arquivo = "saidaKiBDB6.0_TE_Tre.csv"
    #arquivo = "saidaKiPDBbind6.0_TE_Tre.csv"
    #arquivo = "saidaKiBMOAD6.0_TE_Tre.csv"
    #arquivo = "saidaKiTodos6.0_TE_Tre.csv"
    
    #arquivo = "saidaKiBDB7.5_TE_Tre.csv"
    #arquivo = "saidaKiPDBbind7.5_TE_Tre.csv"
    #arquivo = "saidaKiBMOAD7.5_TE_Tre.csv"
    #arquivo = "saidaKiTodos7.5_TE_Tre.csv"
    
    #arquivo = "saidaKiBDB9.0_TE_Tre.csv"
    #arquivo = "saidaKiPDBbind9.0_TE_Tre.csv"
    #arquivo = "saidaKiBMOAD9.0_TE_Tre.csv"
    #arquivo = "saidaKiTodos9.0_TE_Tre.csv"
   
    csv_file1 = diretorio+arquivo    # Not a scaled file
    
    v1 = "Pred. Log(Ki)" 
    v2 = "N"
    v3 = "Standard deviation" 
    v4 = "R"
    v5 = "R-squared"
    v6 = "p-value1" # os p-value devem ter nomes diferentes
    v7 = "Adjusted R-square"
    v8 = "Spearman correlation"
    v9 = "p-value2"  # os p-value devem ter nomes diferentes
    v10 = "Quality factor (Q)"
    v11 = "q-squared for LOO"
    v12 = "F-stat"
    v13 = "Chi-squared"
    v14 = "RMSE"
    cabecalho = v1+","+v2+","+v3+","+v4+","+v5+","+v6+","+v7+","+v8+","+v9+","+v10+","+v11+","+v12+","+v13+","+v14+"\n"
    metodos = ["LinearRegression","Ridge","RidgeCV","Lasso","LassoCV","ElasticNet","ElasticNetCV"]
    #metodos = ["RidgeCV"]
    for metodo in metodos:   
        try:
            fo1 = open(csv_file1,"r") # so para verificar se existe arquivo
            fo1.close()
            chama_calcula(csv_file1,metodo,num_col,cabecalho,diretorio)
        except IOError:
            sys.exit("O arquivo "+csv_file1+" nao existe no diretorio. Gere-o com o programa principal!!")
    # verifica a melhor equação gerada
       
     

main()