#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import interfaceCaixaTexto, interfaceCorrelacao

from PyQt4 import QtGui  # Import the PyQt4 module we'll need
from func_Gerais import pegaModelo, completaArquivoModelo
from func_manipulaArquivos import arquivosNaPastaModels



class textos(QtGui.QMainWindow, interfaceCaixaTexto.Ui_Dialog):
    def __init__(self, parent = None):
        QtGui.QWidget.__init__(self, parent)
        self.setupUi(self)
        self.setFixedSize(800,650)
        self.window11 = None

    
    