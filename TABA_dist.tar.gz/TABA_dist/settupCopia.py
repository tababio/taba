#setup.py
#18_03_2018 - falta incluir pastas, ver permissoes diretorio
# no terminal digitar 'python setup_taba.py bdist_msi'
#'packages': ["os","idna","sys","ctypes","win32con","encodings","asyncio"]
from cx_Freeze import setup, Executable
import os, numpy, scipy,sklearn,sys

os.environ['TCL_LIBRARY'] = r'C:\Users\amaur\Anaconda3\tcl\tcl8.6'
os.environ['TK_LIBRARY'] = r'C:\Users\amaur\Anaconda3\tcl\tk8.6'
additional_mods = ['numpy.core._methods', 'numpy.lib.format', 'scipy.sparse.csgraph._validation','scipy.sparse','matplotlib.backends.backend_qt4agg','csv','matplotlib','numpy','scipy','sklearn','scipy.stats','sklearn.svm','scipy.linalg', 'sklearn.linear_model','scipy.spatial.ckdtree']
#if 'bdist_msi' in sys.argv:
#    caminho = os.path.abspath(os.path.dirname(sys.argv[0]))
#    sys.argv += ['--initial-target-dir', caminho]
finder.IncludePackage("scipy._lib")  # Changed include from scipy.lib to scipy._lib
finder.IncludePackage("scipy.misc")
hooks.load_scipy = load_scipy_patched
setup(
    name = "taba",
    version = "1.0.0",
    options = {"build_exe": {
        'packages': ['encodings','asyncio','os','idna','sys','types','win32con','csv'],   
	'includes': additional_mods,   
	'excludes': ['tkinter'],
	'include_files': ['outputFiles/','inputFiles/','adjustmentFunctions/','ki/','logs/','pdbs/','setsExperiments/','img/'], 
        'include_msvcr': True,
    }},
    executables = [Executable("taba.py",base= None)]
    )
