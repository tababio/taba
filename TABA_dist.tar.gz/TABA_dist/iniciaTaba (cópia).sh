#!/bin/bash
#fazendo backup do trabalho
echo `date`" Iniciando Taba"
cd /home/amauri/Documents/LiClipse\ Workspace/TCC
./winPrincipal.py

echo `date`" Terminando Taba"
read	
