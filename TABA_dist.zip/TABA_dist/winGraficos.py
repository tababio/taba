#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import interfaceGraficos
import sys

from PyQt4 import QtGui  # Import the PyQt4 module we'll need
import interfaceCorrelacao
from func_Gerais import get_arquivosSf, get_listaColunasDistancia,converteStringDeltaG, grava
from func_calculaCorrelacao import correlation_coefficient2 
from func_TestaEquacao import geraCalculoPelaFormula
from func_MelhorEquacao import melhor
from func_Gerais import grava, pegaConfig, gravaConfig, extraiNumero, pegaModelo, leCsvPulaLinha
from func_manipulaArquivos import arquivosNaPastaModels, apagaArquivo
import numpy as np
import matplotlib.pyplot as plt
import csv


class graficos(QtGui.QMainWindow, interfaceGraficos.Ui_MainWindowGraficos):
    def __init__(self, parent = None):
        QtGui.QWidget.__init__(self, parent)
        self.setupUi(self)
        self.setFixedSize(800,520)
        self.window11 = None
        self.carregaCombos()
    def geraGraficoTeste(self): 
        diretorio = "./outputFiles/"
        arq = diretorio+"resultadoTeste.csv"       
        self.reduzTreino = False
        inicioX, fimX = self.reduzPontosTesteX()
        inicioY, fimY = self.reduzPontosTesteY()
        self.mostraGraficoTreino(arq, inicioX, fimX, inicioY, fimY)
    def mostraGraficoTeste(self,arq, inicioX, fimX, inicioY, fimY):
        with open(arq, "r") as f:
            next(f) # pula cabecalho
            data = [row for row in csv.reader(f)]
            xd = [float(row[2]) for row in data]
            yd = [float(row[1]) for row in data]
    
        # sort the data
        reorder = sorted(range(len(xd)), key = lambda ii: xd[ii])
        xd = [xd[ii] for ii in reorder]
        yd = [yd[ii] for ii in reorder]
        
        # make the scatter plot        
        plt.rcParams['axes.facecolor'] = '#ffffff'
        plt.scatter(xd, yd, s=50, alpha=0.5, marker='o',color='black')
        minimoX = float(inicioX)    
        maximoX = float(fimX)
        minimoY = float(inicioY)    
        maximoY = float(fimY)
        plt.xlim(minimoX,maximoX)
        plt.ylim(minimoY,maximoY)
        # determine best fit line
        par = np.polyfit(xd, yd, 1, full=True)
        slope=par[0][0]
        intercept=par[0][1]
        xl = [min(xd), max(xd)]
        yl = [slope*xx + intercept  for xx in xl]
    
        # coefficient of determination, plot text
        variance = np.var(yd)
        residuals = np.var([(slope*xx + intercept - yy)  for xx,yy in zip(xd,yd)])
        Rsqr = np.round(1-residuals/variance, decimals=2)
        #plt.text(0.22*max(xd)+0.22*min(xd),0.001*max(yd)+0.001*min(yd),'R2 = %0.2f'% Rsqr, fontsize=12)
        plt.title("Test Set Plot",fontsize=20)
        
        plt.xlabel("Experimental Affinity                 ("+'R2 = %0.2f'% Rsqr+")")
        plt.ylabel("Predicted Affinity")
        # error bounds
        yerr = [abs(slope*xx + intercept - yy)  for xx,yy in zip(xd,yd)]
        par = np.polyfit(xd, yerr, 2, full=True)
      
        #yerrUpper = [(xx*slope+intercept)+(par[0][0]*xx**2 + par[0][1]*xx + par[0][2]) for xx,yy in zip(xd,yd)]
        #yerrLower = [(xx*slope+intercept)-(par[0][0]*xx**2 + par[0][1]*xx + par[0][2]) for xx,yy in zip(xd,yd)]
        
        plt.plot(xl, yl, '-r', color='green',linewidth = 1.5)
        #plt.plot(xd, yerrLower, '--r')
        #plt.plot(xd, yerrUpper, '--r')
        plt.grid(linestyle='-', linewidth = 0.5, color='grey') 
        
        #plt.xlim(-9,-6)
        plt.show(block = True)
        
    def geraGraficoTreino(self):  
        diretorio = "./outputFiles/"
        arq = diretorio+"resultadoTreino.csv"
        self.reduzTreino = False
        inicioX, fimX = self.reduzPontosTreinoX()
        inicioY, fimY = self.reduzPontosTreinoY()
        self.mostraGraficoTreino(arq, inicioX, fimX, inicioY, fimY)
    def mostraGraficoTreino(self,arq, inicioX, fimX, inicioY, fimY):
        with open(arq, "r") as f:
            next(f) # pula cabecalho
            data = [row for row in csv.reader(f)]
            xd = [float(row[2]) for row in data]
            yd = [float(row[1]) for row in data]
        # sort the data
        reorder = sorted(range(len(xd)), key = lambda ii: xd[ii])
        xd = [xd[ii] for ii in reorder]
        yd = [yd[ii] for ii in reorder]
        
        # make the scatter plot
        plt.rcParams['axes.facecolor'] = '#ffffff'
        plt.scatter(xd, yd, s=50, alpha=0.5, marker='o',color='black')
        minimoX = float(inicioX)    
        maximoX = float(fimX)
        minimoY = float(inicioY)    
        maximoY = float(fimY)
        plt.xlim(minimoX,maximoX)
        plt.ylim(minimoY,maximoY)
        # determine best fit line
        par = np.polyfit(xd, yd, 1, full=True)

        slope=par[0][0]
        intercept=par[0][1]
        xl = [min(xd), max(xd)]
        yl = [slope*xx + intercept  for xx in xl]
    
        # coefficient of determination, plot text
        variance = np.var(yd)
        residuals = np.var([(slope*xx + intercept - yy)  for xx,yy in zip(xd,yd)])
        Rsqr = np.round(1-residuals/variance, decimals=2)
        #plt.text(0.32*max(xd)+0.32*min(xd),0.001*max(yd)+0.001*min(yd),'R2 = %0.2f'% Rsqr, fontsize=12)
        plt.title("Training Set Plot",fontsize=20)
        
        plt.xlabel("Experimental Affinity                 ("+'R2 = %0.2f'% Rsqr+")")
        plt.ylabel("Predicted Affinity")
 
        # error bounds
        yerr = [abs(slope*xx + intercept - yy)  for xx,yy in zip(xd,yd)]
        par = np.polyfit(xd, yerr, 2, full=True)
        #yerrUpper = [(xx*slope+intercept)+(par[0][0]*xx**2 + par[0][1]*xx + par[0][2]) for xx,yy in zip(xd,yd)]
        #yerrLower = [(xx*slope+intercept)-(par[0][0]*xx**2 + par[0][1]*xx + par[0][2]) for xx,yy in zip(xd,yd)]
        
        plt.plot(xl, yl, '-r', color='green',linewidth = 1.5)
        #plt.plot(xd, yerrLower, '--r')
        #plt.plot(xd, yerrUpper, '--r')
        plt.grid(linestyle='-', linewidth = 0.5, color='grey')
      
        plt.show(block = True)
    def reduzPontosTreinoX(self):
        inicio = str(self.comboBox_treinoXinicio.currentText())
        fim = str(self.comboBox_treinoXfim.currentText())
        return inicio, fim
    def reduzPontosTreinoY(self):
        inicio = str(self.comboBox_treinoYinicio.currentText())
        fim = str(self.comboBox_treinoYfim.currentText())
        return inicio, fim
    
    def reduzPontosTesteX(self):
        inicio = str(self.comboBox_testeXinicio.currentText())
        fim = str(self.comboBox_testeXfim.currentText())
        return inicio, fim
    def reduzPontosTesteY(self):
        inicio = str(self.comboBox_testeYinicio.currentText())
        fim = str(self.comboBox_testeYfim.currentText())
        return inicio, fim
    def carregaItemGráfico(self,arq, rev,xy):
        if rev:
            fator = 0.99
        else:
            fator = 1.01
        if xy == 'x':
            ind = 2
        elif xy == 'y':
            ind = 1
        arquivo = open(arq, 'r')
        reader = csv.reader(arquivo)
        list = [row for row in reader]
        listaRetorno = []
        lista = []
        for i in list[1:]:# pula cabecalho
            lista.append(float(i[ind])) # adiciona somente a coluna de x ou y

        lista.sort(key=lambda x: x, reverse=rev) 
        for i in lista:
            listaRetorno.append(str(round(i*fator,2)))
       
        s = []
        for i in listaRetorno:
            if i not in s:  # exclui valores repetidos
                s.append(i)
        return s
    def carregaCombos(self):
        diretorio = "./outputFiles/"
        arqTreino = diretorio+"resultadoTreino.csv"
        arqTeste = diretorio+"resultadoTeste.csv"
        self.comboBox_treinoXinicio.clear()
        self.comboBox_treinoXfim.clear()
        self.comboBox_treinoYinicio.clear()
        self.comboBox_treinoYfim.clear()
        self.comboBox_testeXinicio.clear()
        self.comboBox_testeXfim.clear()
        self.comboBox_testeYinicio.clear()
        self.comboBox_testeYfim.clear()
        
        itens = self.carregaItemGráfico(arqTreino, False, 'x')
        for i in itens:
            self.comboBox_treinoXinicio.addItem(i)   
        itens = self.carregaItemGráfico(arqTreino, False, 'y')        
        for i in itens:
            self.comboBox_treinoYinicio.addItem(i)            
        itens = self.carregaItemGráfico(arqTreino, True, 'x')
        for i in itens:
            self.comboBox_treinoXfim.addItem(i)            
        itens = self.carregaItemGráfico(arqTreino, True, 'y')
        for i in itens:
            self.comboBox_treinoYfim.addItem(i)
        
        itens = self.carregaItemGráfico(arqTeste, False, 'x')
        for i in itens:
            self.comboBox_testeXinicio.addItem(i)            
        itens = self.carregaItemGráfico(arqTeste, False, 'y')        
        for i in itens:
            self.comboBox_testeYinicio.addItem(i)            
        itens = self.carregaItemGráfico(arqTeste, True, 'x')
        for i in itens:
            self.comboBox_testeXfim.addItem(i)            
        itens = self.carregaItemGráfico(arqTeste, True, 'y')
        for i in itens:
            self.comboBox_testeYfim.addItem(i)
    