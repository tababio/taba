#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import func_manipulaArquivos as manip
from datetime import datetime
from PyQt4 import QtGui, QtCore  # Import the PyQt4 module we'll need
from PyQt4.QtGui import QApplication, QDialog
from func_RenomeiaArq import diretorio
import interfaceGestaoExperimentos
import os
from func_Gerais import pegaConfig, get_pastas, gravaConfig, completaArquivoConfig


class gestaoExperimentos(QtGui.QMainWindow, interfaceGestaoExperimentos.Ui_MainWindow_manageFiles):
    def __init__(self, parent = None):
                   
        QtGui.QWidget.__init__(self, parent)
        self.setupUi(self)
        self.window1 = None
        self.setFixedSize(800,680)
        
        nome = pegaConfig("nomeExperimento")
        nome = nome.strip()
        self.label_outliers.setText(pegaConfig("outlier").strip()) 
        self.label_estruturaInicial.setText(pegaConfig("quantidadeInicialProteinas").strip())  
        self.listaExperimentos = []
        now = str(datetime.now())
        now = now.replace(" ", "")
        now = now.replace("-", "")
        now = now.replace(":", "")
        d = "_"+now[0:14]
        self.atualizaNomes()
        self.atualizaNomesDeletar()
        self.lineEdit_experimento.setText(nome+d)
        self.recuperaInfos()
        self.label_relogio.hide()  

    def atualizaNomes(self):
        self.list1 = get_pastas("./setsExperiments/")
        self.comboBox_arquivos.clear()
        for text in self.list1:
            text = text.replace("./setsExperiments/","")
            self.listaExperimentos.append(text)
            self.comboBox_arquivos.addItem(text) # pega so arquivos de treino
            self.comboBox_arquivos.model().sort(0)
            self.comboBox_arquivos.setCurrentIndex(1)
    def atualizaNomesDeletar(self):
        self.list1 = get_pastas("./setsExperiments/")
        self.comboBox_deletaArquivos.clear()
        for text in self.list1:
            text = text.replace("./setsExperiments/","")
            self.listaExperimentos.append(text)
            self.comboBox_deletaArquivos.addItem(text) # pega so arquivos de treino
            self.comboBox_deletaArquivos.model().sort(0)
            self.comboBox_deletaArquivos.setCurrentIndex(1) 
    def salvarExperimentos(self): 
        self.listaExperimentos = []
        self.list1 = get_pastas("./setsExperiments/")
        for text in self.list1:
            text = text.replace("./setsExperiments/","")
            self.listaExperimentos.append(text)

        # cria pasta para novo conjunto
        self.nomeConjunto = self.lineEdit_experimento.text()
        if self.nomeConjunto in self.listaExperimentos:
            reply = QtGui.QMessageBox.question(self, 'Message',"This set of experiments already exists. Do you want to replace?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
            if reply == QtGui.QMessageBox.Yes:
                self.salva()
                
        else:
            self.label_relogio.show()  
            self.salva()
            self.label_relogio.hide()  
        pass
    def salva(self):
        pastaParaSalvar = "TABA/setsExperiments/"+self.nomeConjunto
        reply = QtGui.QMessageBox.question(self, 'Message',"If you want, you can change the name of the experiment in the box next to it."+"\n"+"\n"+"All files from this experiment will be saved in: "+pastaParaSalvar+"\n"+"\n"+"Do you really want to save this experiment?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
        if reply == QtGui.QMessageBox.Yes:        
            self.toolButton_salvar.setEnabled(False)
            nomePasta = "./setsExperiments/"+self.nomeConjunto
            gravaConfig("nomeExperimento", self.nomeConjunto)
            manip.criaPasta(nomePasta)
            # copia pastas para o novo conjunto
            origem = "./outputFiles/"
            destino = nomePasta+origem.replace(".", "")
            manip.copiaPasta(origem, destino)
            origem = "./pdbs/"
            destino = nomePasta+origem.replace(".", "")
            manip.copiaPasta(origem, destino)
            origem = "./ki/"
            destino = nomePasta+origem.replace(".", "")
            manip.copiaPasta(origem, destino)
            origem = "./inputFiles/"
            destino = nomePasta+origem.replace(".", "")
            manip.copiaPasta(origem, destino)
            self.atualizaNomes()
            self.atualizaNomesDeletar()
            QtGui.QMessageBox.information(self, "Message", "Operation completed")
        else:
            pass              

    def recuperarExperimentos(self):
        self.escondeBotoes()
        reply = QtGui.QMessageBox.question(self, 'Message',"Attention: It is important to save the current experiment before!!!"+"\n"+"\n"+"Do you really want to recover this experiment?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
        if reply == QtGui.QMessageBox.Yes:
            QtGui.QApplication.processEvents() # para não travar deve vir antes e depois   
            self.label_relogio.show()  
            QtGui.QApplication.processEvents() # para não travar   
            self.nomeConjunto = self.comboBox_arquivos.currentText()
            # copia pastas para o novo conjunto
            origem = "./setsExperiments/"+self.nomeConjunto+"/outputFiles/"
            destino = "./outputFiles/"
            manip.copiaPasta(origem, destino)
            origem = "./setsExperiments/"+self.nomeConjunto+"/pdbs/"
            destino = "./pdbs/"
            manip.copiaPasta(origem, destino)
            origem =  "./setsExperiments/"+self.nomeConjunto+"/ki/"
            destino = "./ki/"
            manip.copiaPasta(origem, destino)
            origem =  "./setsExperiments/"+self.nomeConjunto+"/inputFiles/"
            destino = "./inputFiles/"
            manip.copiaPasta(origem, destino)
            self.recuperaInfos()
            now = str(datetime.now())
            now = now.replace(" ", "")
            now = now.replace("-", "")
            now = now.replace(":", "")
            d = "_"+now[0:14]
            self.lineEdit_experimento.setText(pegaConfig("nomeExperimento").strip()+d)
            self.label_comentarios.setText(pegaConfig("comentarios"))
            self.label_quantia.setText(pegaConfig("quantidadeProteinas").strip())
            self.label_estruturaInicial.setText(pegaConfig("quantidadeInicialProteinas").strip()) 
            QtGui.QMessageBox.information(self, "Message", "Operation completed")
            self.label_relogio.hide()  
            self.mostraBotoes()
            self.label_outliers.setText(pegaConfig("outlier").strip())  
        else:
            self.mostraBotoes()
            pass            
        
                
    def sair(self):        
        self.close()
        
                
    def escondeBotoes(self):
        self.toolButton_salvar.setEnabled(False)
        self.toolButton_recuperar.setEnabled(False)
        self.toolButton_exit.setEnabled(False)
    def mostraBotoes(self):
        self.toolButton_salvar.setEnabled(True)
        self.toolButton_recuperar.setEnabled(True)
        self.toolButton_exit.setEnabled(True)
        

    def recuperaInfos(self):
        completaArquivoConfig()
        descricao = pegaConfig("descricaoDataset").strip()
        afinidade = pegaConfig("tipoAfinidade").strip()
        experimento = pegaConfig("nomeExperimento").strip()
        self.label_descricao.setText(descricao+" / "+afinidade)
        self.label_experimento.setText(experimento)
        if not(pegaConfig("sperman") is None):
            self.label_comentarios.setText(pegaConfig("comentarios"))
            self.label_spearman.setText(pegaConfig("sperman").strip())
            self.label_melhorEquacao.setText(pegaConfig("melhorEquacao").strip())
            self.label_quantia.setText(pegaConfig("quantidadeProteinas").strip())
        else:
            self.label_comentarios.setText("null")
            self.label_spearman.setText("null")
            self.label_melhorEquacao.setText("null")
            self.label_quantia.setText("null")
            
    def deletar(self): 
        self.escondeBotoes()
        reply = QtGui.QMessageBox.question(self, 'Message',"Do you really want to delete this experiment from 'setsExperiments' folder?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
        if reply == QtGui.QMessageBox.Yes: 
            self.label_relogio.show()    
            self.nomeConjunto = self.comboBox_deletaArquivos.currentText()
            # copia pastas para o novo conjunto
            pasta = "./setsExperiments/"+self.nomeConjunto
            manip.removePasta(pasta)
            QtGui.QMessageBox.information(self, "Message", "Operation completed")
            self.mostraBotoes()
            self.atualizaNomes()
            self.atualizaNomesDeletar()
            self.label_relogio.hide() 
        else:
            self.mostraBotoes()
             
            pass
    
