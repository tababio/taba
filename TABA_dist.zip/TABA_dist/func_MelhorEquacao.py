import sys

def melhor(arq, coeficiente): # recebe o diretorio e o arquivo SF
    # posiçoes R [3] R2 [4] speraman = 7
    val = 0
    maior = 0
    melhorEquacao = ""
    pv1 = 0
    # define com qual coeficiente deve comparar
    if coeficiente == "r1": # coeficiente R
        coef = 4
    elif coeficiente == "r2": # coeficiente R
        coef = 3      
    elif coeficiente == "pvs": # verificar se e spearman
        coef = 5 
    elif coeficiente == "pvp": # verificar se e person
        coef = 8  
    elif coeficiente == "sd": # coeficiente R
        coef = 2  
    elif coeficiente == "rmse": # coeficiente R
        coef = 13       
    elif coeficiente == "sp":
        coef = 7 # coeficiente spearman     
    try:
        fo = open(arq, 'r')
    except IOError:
        sys.exit ("\n O arquivo "+arq+" nao foi encontrado!!!")
        
    try:
        fo.readline()
        for line in fo:
            linhalimpa = line.replace(" ", "") #retira brancos
            linha = linhalimpa.split(",")
            lin = linha[coef]                      

            val = float(lin)
                              
            if val > maior:
                maior = val
                melhorEquacao = linha[0]
                pv1 = linha[5]                    
           
    except:
        pass
    return maior,pv1,melhorEquacao

