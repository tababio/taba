import compileall
compileall.compile_dir("/home/amauri/TABA", force=1)