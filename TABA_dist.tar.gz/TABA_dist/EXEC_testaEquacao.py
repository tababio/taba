from func_TestaEquacao import gera
import sys
def main():
    diretorio = "./arquivosSaida/"
    arquivo = diretorio+"melhorEquacao.csv"
   
    try:
        fo = open(arquivo, 'r')
    except IOError:
        sys.exit ("\n O arquivo "+arquivo+" nao foi encontrado")
    for line in fo:
        linha = line.split(",")
        if "[melhor Equacao]" in linha:
            formula = linha[1]
      
    #formula = "-7.387274-0.522892*(CC)+0.838812*(CN)-0.436136*(NN)+0.649802*(NS)" 
    arquivo = "saidaKiTodos4.5_TE_Tes.csv"
    diretorio = "./arquivosSaida/"
    gera(diretorio, arquivo, formula)


main()