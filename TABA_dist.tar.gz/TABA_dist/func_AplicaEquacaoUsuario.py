#Usa arquivos separados para teste e aplica melhor formula

import sys

from func_ContaInterMolCalcTermo import inter_mol_term
from func_CriaDicionario import cria_dicionario
from func_GeraArqProteinaComKi import geraArquivoProteinaFinal
from func_Gerais import grava, leCsv
from func_SeparaLiganteProteina import separaLiganteProteina
from PyQt4 import QtGui, QtCore# Import the PyQt4 module we'll need
from PyQt4.QtGui import QApplication, QDialog
from func_manipulaArquivos import existeArquivo
from datetime import datetime


def geraArquivoComTermoDeEnergiaExperimento(arquivosParaLer,distancia,tipo):

# CC CN  CO  CS  CP  CF  CBR CCL CI  CAT
    # NN  NO  NS  NP  NF  NBR NCL NI  NAT
        # OO  OS  OP  OF  OBR OCL OI  OAT
            # SS  SP  SF  SBR SCL SI  SAT

    #foram retiradas as colunas de HOH pois vieram poucos resultados
    #texto = "liganteAtivo"+","+"arquivo"+","+"CC"+","+"CN"+","+"CO"+","+"CS"+","+"CP"+","+"CF"+","+"CBr"+","+"CCl"+","+"CI"+","+"CAt"+","+"NN"+","+"NO"+","+"NS"+","+"NP"+","+"NF"+","+"NBr"+","+"NCl"+","+"NI"+","+"NAt"+","+"OO"+","+"OS"+","+"OP"+","+"OF"+","+"OBr"+","+"OCl"+","+"OI"+","+"OAt"+","+"SS"+","+"SP"+","+"SF"+","+"SBr"+","+"SCl"+","+"SI"+","+"SAt"+","+"NHOHN"+","+"NHOHO"+","+"NHOHS"+","+"NHOHP"+","+"NHOHF"+","+"NHOHBR"+","+"NHOHCL"+","+"NHOHI"+","+"NHOHAT"+","+"OHOHO"+","+"OHOHS"+","+"OHOHP"+","+"OHOHF"+","+"OHOHBR"+","+"OHOHCL"+","+"OHOHI"+","+"OHOHAT"+","+"Log(Ki)"+"\n"
    texto = "arquivo"+","+"CC"+","+"CN"+","+"CO"+","+"CS"+","+"CP"+","+"CF"+","+"CBr"+","+"CCl"+","+"CI"+","+"CAt"+","+"NN"+","+"NO"+","+"NS"+","+"NP"+","+"NF"+","+"NBr"+","+"NCl"+","+"NI"+","+"NAt"+","+"OO"+","+"OS"+","+"OP"+","+"OF"+","+"OBr"+","+"OCl"+","+"OI"+","+"OAt"+","+"SS"+","+"SP"+","+"SF"+","+"SBr"+","+"SCl"+","+"SI"+","+"SAt"+"\n"
    textoKiTodos = texto
    #foram retiradas as colunas de HOH pois vieram poucos resultados
    #my_list = ['CC','CN','CO','CS','CP','CF','CBr','CCl','CI','CAt','NN','NO','NS','NP','NF','NBr','NCl','NI','NAt','OO','OS','OP','OF','OBr','OCl','OI','OAt','SS','SP','SF','SBr','SCl','SI','SAt','NHOHN','NHOHO','NHOHS','NHOHP','NHOHF','NHOHBR','NHOHCL','NHOHI','NHOHAT','OHOHO','OHOHS','OHOHP','OHOHF','OHOHBR','OHOHCL','OHOHI','OHOHAT']
    my_list = ['CC','CN','CO','CS','CP','CF','CBr','CCl','CI','CAt','NN','NO','NS','NP','NF','NBr','NCl','NI','NAt','OO','OS','OP','OF','OBr','OCl','OI','OAt','SS','SP','SF','SBr','SCl','SI','SAt']
    cont = 0 # contador de arquivos processados

    for prot in arquivosParaLer:
        cont = cont +1 #quantidade arquivos processados
        
        diretorio = "./pdbs/"
        arquivo = prot.strip() # nome do arquivo pdb que est'em pdbsProteinas
        arquivo = arquivo.lower()
        protArq=diretorio+arquivo+"_soAtom.pdb" # coloca a terminacao para ler o arquivo so de proteinas que foram separados
        ligArq=diretorio+arquivo+"_soHetatm.pdb" # coloca a terminacao para ler o arquivo so de ligantes que foram separados
        countLigante = inter_mol_term(protArq,ligArq,distancia)
        #print("teste----------------------",countLigante)
        vetLigante1=countLigante[0]
        vetLigante2=countLigante[1]
        #print("v1 e v2",vetLigante1,vetLigante2)
        #listaDicionario= cria_dicionario(vet1,vet2)
        #prIt listaDicionario
        conteudoLigante = cria_dicionario(vetLigante1, vetLigante2) 
        lin = protArq.replace("_soAtom.pdb","")+',' # retira .pdb do arquivo
        lin = lin.replace(diretorio,"") # retira caminho do arquivo)
        for aa in my_list:
            lin= lin+str(conteudoLigante[aa])+','
        textoKiTodos= textoKiTodos+lin+"\n"
        textoKiTodos = textoKiTodos.strip()
        textoKiTodos = textoKiTodos[:-1] # retira ultima virgula
    diret = "./outputFiles/"
    strDist = str(distancia)
    #    ATENCAO NAO PODE GERAR LINHA ANTES E APOS O TEXTO 
    # so utulizaremos para o usuario o total
    arquivo = diret+'saidaKiTodos'+strDist+'_TE_'+tipo+'.csv'
    grava(textoKiTodos,arquivo)
    return diret, arquivo
    '''
    print("|--------------------------------------------|") 
    print("| Gerado arquivo:",diret+'saidaKiTodos'+strDist+'_TE_'+tipo+'.csv',"  |")
    print("|--------------------------------------------|") 
    '''
     
def chamaRotinasPreparacao(diretorio,ligante):
    # separa PDB em 2 arquivos: proteina(Atom), ligante(Hetatm)
    geraArquivoKiFake(ligante)
    geraArquivoProteinaFinal(diretorio,"pdbsProteinaUsu.txt","Usu") # gera arquivo so com proteinas que tem arquivo de ki correspondente
    separaLiganteProteina(diretorio,"pdbsProteinaUsu.txt","Usu",ligante)

def melhorEquacaoExperimento():
    diretorio = "./outputFiles/"
    arquivo = diretorio+"melhorEquacao.csv"
    try:
        fo = open(arquivo, 'r')
    except IOError:
        mensagem = "The"+arquivo+" file not found. Probably no previous step was generated"
        arquivoSai = "./logs/error"+str(datetime.now())
        grava(mensagem, arquivoSai)
        sys.exit("see error in TABA/logs folder")

    for line in fo:
        linha = line.split(",")
        if "[melhor Equacao]" in linha:
            formula = linha[1]
    return formula

def posicaoVariaveis(listaVariaveis,diretorio,arquivo): # recebe o diretorio e o arquivo SF
    arq = diretorio+arquivo
    posicao = []
    
    try:
        fo = open(arq, 'r')
    except IOError:
        sys.exit ("\n O arquivo "+arq+" nao foi encontrado")

    try:
        for line in fo:
            linha = line.split(",")
            for indice,x in enumerate(linha):
                if x in listaVariaveis:
                    posicao.append(indice)               
    except:
        pass
    fo.close()
    return posicao

def calculaExperimento(listaVariaveis,diretorio,arquivo,formula):
    arq = diretorio+arquivo
    pos = posicaoVariaveis(listaVariaveis, diretorio, arquivo) # pega posiccao dos valores das colunas das variaveis
    
    listaValores = []
    listaResultados = 'PDB, ValorTeste, KiReal'+"\n"
    try:
        fo = open(arq, 'r')
    except IOError:
        sys.exit ("\n O arquivo "+arq+" nao foi encontrado")

    try:
        fo.readline() # para pular primeira linha
        for line in fo: # percorre arquivo de teste
            #print("line:",line)
            linha = line.split(",")
            pdbNome = linha[0]
            for x in pos:  # percorre lista de posicao e pega valores no arquivo de teste               
                listaValores.append(linha[x])
            n = 0
            equacao = formula
            for lin2 in listaVariaveis:  #substitui valores na equacao          
                equacao = equacao.replace(listaVariaveis[n], listaValores[n]) #substitui variavel pelo valor
                n = n+1
            #print("--------------------------equacao:", equacao)
            logKi = resolveEquacaoExperimento(equacao)
            equacao = formula   
            listaValores = []                    
              
    except:
        pass
    fo.close()
    #print("resultados:",listaResultados)
    grava(listaResultados,diretorio+"resultadoTeste.csv")
    ki = (10**(logKi))+9 # para retornar o ki apartir do log10 de ki
    return pdbNome,logKi,ki
    
def resolveEquacaoExperimento(equacao):
    result = eval(equacao)
    return result

def criaListaVariaveis(formula):
    # cria lista de variaveis da formula
    listaVariaveis = []
    usa = False # define se faz parte da vairável 
    var = ""
    for x in formula:
        if x == "(":
            usa = True            
        if x == ")":
            usa = False 
            listaVariaveis.append(var)
            var = ""      
        if usa:
            if x !="(": #desconsidera o parentese
                var = var+x
    return listaVariaveis
def geraExperimento(diretorio,arquivo,formula):
    listaVariaveis = criaListaVariaveis(formula)
    return calculaExperimento(listaVariaveis,diretorio, arquivo, formula) #calcula usando os termoo de energia e gera arquivo com resultados para comparar

def geraArquivoKiFake(ligante): # caso a proteina não tenha arquivo Ki
    arquivo = "./inputFiles/pdbsProteinaUsu.txt"
    texto = leCsv(arquivo)
    estrutura = ''.join(texto).upper()
    arq = "./ki/"+estrutura.lower()+".csv"
    if not(existeArquivo(arq)):
        textoInibidor ='"'+estrutura+'","'+"A"+'","'+ligante+'","'"FAKE(BDB)"+'"'+"\n"
        open(arq, 'a').close() # cria arquivo Ki da estrutura
        try:
            my_PDB_fo = open(arq,"w")            
            my_PDB_fo.write(textoInibidor) # grava dados fake de ki para a estrutura
            my_PDB_fo.close()
        except IOError:
            sys.exit("\nI can't file "+arq+" file!")
    else:
        pass
