#funcoes genericas
import csv
from datetime import datetime
import sys  
import os
import func_manipulaArquivos as manip
import urllib.request as ur
from numpy.distutils.fcompiler import none
from pyasn1.compat.octets import null


# faz a média para andamento do programa
def andamento(vet):
    '''
    recebe um vetor com 7 posicoes onde as últimas posicoes não preenchidas sao preenchida regressivamente com 36,35,34,33
    
    '''
    # preenche posicoes faltanes o vetor tem no minimo 3 posicoes e estamos considerando um vetor so com 7 posicoes teremos preciao para 10 posicoes
    tam = len(vet) 
    if tam ==3:
        vet.append(33) # lembrar vetor comeca em 0
        vet.append(34)
        vet.append(35)
        vet.append(36)
    if tam ==4:
        vet.append(34)
        vet.append(35)
        vet.append(36)
    if tam ==5:
        vet.append(35)
        vet.append(36)
    if tam ==7:
        vet.append(36)       
    #########
    div = 1
    soma = 0
    for i in vet: # divide cada posicao do vetor por um multiplo de 10 e soma
        div = div*10 # vai acrescendo o divisor
        soma = soma+(i/div) 
    resultado = soma*10000000
    # o  valor de referencia e a soma do vetor [31,32,33,34,35,36] dividindo cada posicao por 10 na n+1 e depois multiplica por 10,000,000
    valRef = 33456786
    return valRef, resultado
# Program to download PDB file

def download_PDB_file(my_url,pdb_access_in):
    """Function to get data from an url"""    
    # url_in = 'http://files.rcsb.org/download/'
    # Set up file name
    #pdb_file = "./pdbs/"+pdb_access_in+".pdb" # inclui diretorio e sufixo
    pdb_file = pdb_access_in # inclui diretorio e sufixo # modificado pois nao aceita /pdbs
    # Set up URL
    #print(my_url+pdb_file)
    try:
        file_object = ur.urlopen(my_url+pdb_file)
        structure = file_object.read()
        file_object.close()
    except:
        print("Could not access server")
        mensagem = "Could not access server"
        return mensagem
    
    # Download file
    diretorioParaBaixar = "./pdbs/"
    with open(diretorioParaBaixar+pdb_file,"wb") as my_file_4_download:
        my_file_4_download.write(structure)
    mensagem = "\nFinishing downloading of "+pdb_file+" file!"
    return(mensagem)
def get_Bind(my_dir_in,structureId,binding_info):
    """Function to download CSV file with binding affinty"""
    import urllib.request, urllib.parse, urllib.error
    import time

    # String for local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Sets up initial values for variable and list
    check_if_code_in = False
    my_structureId_string = structureId.lower()
    my_binding_list = ["Ki","Kd","EC50","IC50","deltaG","deltaH","Ka"]
       
    # Looping through my_binding_list
    for bind_in in my_binding_list:
        if binding_info.upper().strip() == bind_in.upper().strip():
            binding_info1 = bind_in.strip()
            

    # Specify file
    file_2_download =my_structureId_string+".csv"
    
    # Check if file is already in the structure directory
    flag_4_file_present = pre_download(my_dir_in,file_2_download)
    if flag_4_file_present:
        check_if_code_in = True
        return check_if_code_in
    
    # Specify url
    #my_url = 'http://www.rcsb.org/pdb/rest/customReport?pdbids='+my_structureId_string+'&customReportColumns=structureId,chainId,ligandId,'+binding_info+',&service=wsfile&format=csv&ssa=n'
    my_url = 'http://www.rcsb.org/pdb/rest/customReport?pdbids='+my_structureId_string+'&customReportColumns=structureId,chainId,ligandId,'+binding_info1+'&service=wsfile&format=csv&ssa=n'

    # Try to download file    
    try: 
        file_object = urllib.request.urlopen(my_url)
        structure = file_object.read()
        file_object.close()
        #print("URL ---------------------->", my_url)
        file_object = urllib.request.urlopen(my_url)
        #structure_line = file_object.readline()
        file_object.close()
    except:
        check_if_code_in = False
        my_iteraction = 1
        #print("RCSB is complaining about 'High User Activity'.")
        #print("I will try to wait longer for each file...")
        my_time_to_wait = my_iteraction*20
        #print("Waiting for",my_time_to_wait," seconds...")
        time.sleep(my_time_to_wait)
        #print("\n "+file_2_download+" file downloaded from http://www.rcsb.org/")
        loop_flag = True
        
        # while loop to keep trying to download
        while loop_flag:
            try: 
                file_object = urllib.request.urlopen(my_url)
                structure = file_object.read()
                file_object.close()
        
                file_object = urllib.request.urlopen(my_url)
            #structure_line = file_object.readline()
                file_object.close()
                loop_flag = False
                check_if_code_in = True
            except:
                my_iteraction += 1
                loop_flag = True
                check_if_code_in = False
    
            if my_time_to_wait > 359:
                #print("It is taking too long!")
                #print("Try to split in different inputs getbind.in, with a smaller number of structures per input.\n")
                return check_if_code_in
                break
            
    time.sleep(1)
    
    with open(my_dir_in+file_2_download,"wb") as my_file_4_download:
        my_file_4_download.write(structure)
        my_file_4_download.close()
        check_if_code_in = True
def pre_download(my_dir_in,my_file_in):
    """Function to check if the file is already in the structure directory"""
    file_present = False
    
    # Try to open file
    try:
        my_fo = open(my_dir_in+my_file_in,"r")
        file_present  = True
        my_fo.close()
    except:
        file_present  = False
                
    # Return boolean variable
    return file_present
def grava(conteudo,arquivoSai):
    arquivo = open(arquivoSai, 'w')
    arquivo.writelines(conteudo)
    arquivo.close()

# Le um arquivo delimitado e mostra os campos na tela. """
  
def leCsv(arquivo):
    retorno = []
    try:
        fo = open(arquivo, 'r')
    except IOError:
        sys.exit ("\n O arquivo "+arquivo+" nao foi encontrado")
    with fo as ficheiro:
        reader = csv.reader(ficheiro)
        for linha in reader:
            retorno = retorno+linha
    return retorno  
def leCsvPulaLinha(arquivo): #pula a primeira linha do arquivo
    retorno = []
    try:
        fo = open(arquivo, 'r')
    except IOError:
        sys.exit ("\n O arquivo "+arquivo+" nao foi encontrado")
    with fo as ficheiro:
        reader = csv.reader(ficheiro)
        next(reader)
        for linha in reader:
            retorno = retorno+linha
    return retorno  
# verifica se uma string pode ser float
def isfloat(value):
        try:
            float(value)
            return True
        except:
            return False 
def tempoEstatistica(now,cont,quant): # mostra estimativas de duracao do processamento
        now2 = datetime.now()
        tempo = now2-now
        mediaAtual = tempo/cont
        total = tempo+(mediaAtual*(quant-cont))
        tempoRestante = total-tempo
        '''
        print ("|------------- tempo = hh:mm:ss --------------------|")
        print ("| tempo de processamento total:", tempo)
        print ("| estimativa de duracao:", total)
        print ("| tempo restante estimado:", tempoRestante)
        print ("|----------------------------------------------------|")
        ''' 
def contaCaracter(caracter,frase):  
    y = 0
    for x in frase:
        if x == caracter:
            y+=1
    return y    
def get_pastas(direct):
    return [os.path.join(direct, f) for f in os.listdir(direct)]
def get_arquivosTreino(directory):
    """
    This function will generate the file names in a directory 
    tree by walking the tree either top-down or bottom-up. For each 
    directory in the tree rooted at directory top (including top itself), 
    it yields a 3-tuple (dirpath, dirnames, filenames).
    """
    file_paths = []  # List which will store all of the full filepaths.

    # Walk the tree.
    for root, directories, files in os.walk(directory):
        for filename in files:
            # Join the two strings in order to form the full filepath.
            filepath = os.path.join(root, filename)
            if "saida" in filepath and not "SF" in filepath and "Tre" in filepath: # para usar somente os que contem saida
                file_paths.append(filepath)  # Add it to the list.

    return file_paths
def get_arquivosSf(directory,distancia):

    file_paths = []  # List which will store all of the full filepaths.

    # Walk the tree.
    for root, directories, files in os.walk(directory):
        for filename in files:
            # Join the two strings in order to form the full filepath.
            filepath = os.path.join(root, filename)
            if "SF_" in filepath and "Tre" in filepath and distancia in filepath: # para usar somente os que contem saida
                file_paths.append(filepath)  # Add it to the list.

    return file_paths
def limpa_arquivosSf(directory): #limpa arquivos SF nulos por interrupcao

    file_paths = []  # List which will store all of the full filepaths.

    # Walk the tree.
    for root, directories, files in os.walk(directory):
        for filename in files:
            # Join the two strings in order to form the full filepath.
            filepath = os.path.join(root, filename)
            if "SF_" in filepath and "Tre" in filepath: # para usar somente os que contem saida
                if os.path.getsize(filepath) == 0:
                    os.remove(filepath, dir_fd=None)


    return file_paths
def get_arquivosTeste(directory):
    """
    This function will generate the file names in a directory 
    tree by walking the tree either top-down or bottom-up. For each 
    directory in the tree rooted at directory top (including top itself), 
    it yields a 3-tuple (dirpath, dirnames, filenames).
    """
    file_paths = []  # List which will store all of the full filepaths.

    # Walk the tree.
    for root, directories, files in os.walk(directory):
        for filename in files:
            # Join the two strings in order to form the full filepath.
            filepath = os.path.join(root, filename)
            if "saida" in filepath and not "SF" in filepath and "Tes" in filepath: # para usar somente os que contem saida
                file_paths.append(filepath)  # Add it to the list.

    return file_paths

def get_listaDistancias(directory):
    listaDistancias = []
    # Walk the tree.
    for root, directories, files in os.walk(directory):
        for filename in files:
            # Join the two strings in order to form the full filepath.
            filepath = os.path.join(root, filename)
            if "3.5" in filepath and not "Usu" in filepath and not "3.5" in listaDistancias: # para usar somente os que contem saida
                listaDistancias.append("3.5")  # Add it to the list.
            if "4.5" in filepath and not "Usu" in filepath and not "4.5" in listaDistancias: # para usar somente os que contem saida
                listaDistancias.append("4.5")  # Add it to the list.
            if "6.0" in filepath and not "Usu" in filepath and not "6.0" in listaDistancias: # para usar somente os que contem saida
                listaDistancias.append("6.0")  # Add it to the list.
            if "7.5" in filepath and not "Usu" in filepath and not "7.5" in listaDistancias: # para usar somente os que contem saida
                listaDistancias.append("7.5")  # Add it to the list.
            if "9.0" in filepath and not "Usu" in filepath and not "9.0" in listaDistancias: # para usar somente os que contem saida
                listaDistancias.append("9.0")  # Add it to the list.
                

    return listaDistancias 
def get_listaColunas(directory):
    listaColunas = []
    for root, directories, files in os.walk(directory):
        for filename in files:
            # Join the two strings in order to form the full filepath.
            filepath = os.path.join(root, filename)
            if "3cols" in filepath and not "2" in listaColunas: # para usar somente os que contem saida
                listaColunas.append("2")  # desconta a contante            
            if "4cols" in filepath and not "3" in listaColunas: # para usar somente os que contem saida
                listaColunas.append("3")  # desconta a contante
            if "5cols" in filepath and not "4" in listaColunas: # para usar somente os que contem saida
                listaColunas.append("4")  # desconta a contante
            if "6cols" in filepath and not "5" in listaColunas: # para usar somente os que contem saida
                listaColunas.append("5")  # desconta a contante
            if "7cols" in filepath and not "6" in listaColunas: # para usar somente os que contem saida
                listaColunas.append("6")  # desconta a contante
            if "8cols" in filepath and not "7" in listaColunas: # para usar somente os que contem saida
                listaColunas.append("7")  # desconta a contante 
            if "9cols" in filepath and not "8" in listaColunas: # para usar somente os que contem saida
                listaColunas.append("8")  # desconta a contante
            if "10cols" in filepath and not "9" in listaColunas: # para usar somente os que contem saida
                listaColunas.append("9")  # desconta a contante
            if "11cols" in filepath and not "10" in listaColunas: # para usar somente os que contem saida
                listaColunas.append("10")  # desconta a contante                                                                                       
    return listaColunas
def get_listaColunasDistancia(directory): #verifica distancias e colunas nos arquivos de saida
    listaColDist = []
    for root, directories, files in os.walk(directory):
        for filename in files:
            if "SF_saida" in filename:
                posCol = filename.find("cols")
                posDis = filename.find("_TE_")
                col = filename[posCol-1:posCol]
                col = int(col)-1
                dist = filename[posDis-3:posDis]
                if filename[posCol-2].isdigit(): #se o numero de variaveis tiver 2 digitos
                    col = col+10
                
                texto = dist+str(chr(197))+" and "+str(col)+" Variables"
                if not texto in listaColDist:
                    listaColDist.append(texto)
    return listaColDist
            
def gravaConfig(tag,valor):
    valor = valor.strip() # retira espaços pois pode resultar em strings maiores que o campo definido para mostrar    
    tag = "<"+tag+">"# criar tags para descricao pdbs proteinas, ligante ou inibidor,
    arq = "./inputFiles/config.csv"
    textoNovo = ''
    try:
        fd = open(arq, 'r')   

    except:  
        print("file not found")
        #next(input_fd) para pular cabeçalho, mas nao precisa neste caso
    for line in fd:
        line = line.strip()
        if tag in line:
 
            strRemove = line
            newLine = line.replace(strRemove,tag+","+valor)
            textoNovo = textoNovo+newLine+"\n"
        else:

            textoNovo = textoNovo+line+"\n"
    if not tag in textoNovo:
            textoNovo = textoNovo+tag+","+valor+"\n"
    fd.close()
    fdw = open(arq, 'w')
    fdw.write(textoNovo)
    fdw.close()
def pegaConfig(tag):    
    tag = "<"+tag.strip()+">"# criar tags para descricao pdbs proteinas, ligante ou inibidor,
    arq = "./inputFiles/config.csv"
    try:
        my_fo = open(arq,"r")   
    except:            
        print("--->file not found")
    for lin in my_fo:
        texto = lin.split(",") 
        if texto[0] == tag:
            return texto[1]
        
def substituiSeedEmMLin(valor): 
    '''
    substitui as sementes no arquivo ml.in para que fiquem igual a semente da geracao dos arquivos para regresao
    caso esteja utilizando experimentos mais antigos sera considerada a semente para a distancia de 4.5
    '''
    valor = valor.replace('.','') # retirar o ponto para bucar a tag
    tag = "seed"+valor 
    
    tag1 = pegaConfig(tag) # pega valor da semente para uma distancia

    if (tag1 == None): # caso seja experimento antigo vai utilizar o valor padrao do ml.in
        tag1 = '1123581321'
    texto2 = ''
    arq = "./inputFiles/ml.in" 
    try:
        my_fo = open(arq,"r")   
    except:            
        print("file not found")

    for lin in my_fo:
        texto = lin.split(",") 
        if 'Lasso' in texto:  
            texto[11] = tag1
        if 'LassoCV' in texto:        
            texto[11] = tag1              
        if 'ElasticNet' in texto:        
            texto[11] = tag1
        if 'ElasticNetCV' in texto:      
            texto[13] = tag1
        str1 = ','.join(texto)
        str2 = str1.replace('\n', '')+'\n' # para deixar somente um \n
        texto2 = texto2+str2
        
    
    my_fo.close()
    # grava novo ml.in 
    fd = open(arq, 'w')
    fd.write(texto2)
    fd.close()
    return tag1 # retorna a semente para a winRegressao
   
def temLigante(diretorio, arquivo):
    arq = ''.join(arquivo)
    arq = diretorio+arq.lower()+"_soHetatm.pdb"
    if os.stat(arq).st_size==0:
        return False
    else:
        return True
'''
def limpaPastas():
    # remove pastas existentes
    pasta = "./outputFiles/"
    manip.removePasta(pasta)
    pasta = "./pdbs/"
    manip.removePasta(pasta)
    pasta = "./ki/"
    manip.removePasta(pasta)
    pasta = "./inputFiles/"
    manip.removePasta(pasta)
    # cria novas pastas
    nomePasta = "./outputFiles/"
    manip.criaPasta(nomePasta)
    nomePasta = "./pdbs/"
    manip.criaPasta(nomePasta)
    nomePasta = "./ki/"
    manip.criaPasta(nomePasta)
    nomePasta = "./inputFiles/"
    manip.criaPasta(nomePasta)
    criaArquivoBase()
'''
def limpaPastas():
    # remove parquivos nas pastas
    pasta = "./outputFiles/"
    manip.apagaArquivos(pasta)
    pasta = "./pdbs/"
    manip.apagaArquivos(pasta)
    pasta = "./ki/"
    manip.apagaArquivos(pasta)
    pasta = "./inputFiles/"
    manip.apagaArquivos(pasta)
    criaArquivoBase()
def limpaPastaSaida():
    # remove parquivos nas pastas
    pasta = "./outputFiles/"
    manip.apagaArquivos(pasta)
    criaArquivoBase()
def limpaArquivosOutlier():
    # remove parquivos nas pastas
    arq = "./inputFiles/pdbsProteinaFinalTes.txt"
    manip.apagaArquivo(arq)
    arq = "./inputFiles/pdbsProteinaFinalTre.txt"
    manip.apagaArquivo(arq)
    arq = "./inputFiles/pdbsProteinaTeste.txt"
    manip.apagaArquivo(arq)
    arq = "./inputFiles/pdbsProteinaTreino.txt"
    manip.apagaArquivo(arq)
def limpaPastasSaidaOutlier():
    # remove parquivos nas pastas
    pasta = "./outputFiles/"
    manip.apagaArquivos(pasta)
 
def criaArquivoBase():
    #regrava arquivo ml.in
    l1 = "LinearRegression,True,True,True"+"\n"
    l2 = "Lasso,0.1,True,True,False,True,1000,0.0001,True,False,random,1123581321"+"\n"
    l3 = "LassoCV,0.1,True,True,False,True,1000,0.0001,True,False,random,1123581321"+"\n"
    l4 = "Ridge,1.0,True,True,True,1000,0.001,auto"+"\n"
    l5 = "RidgeCV,0.05,2.0,0.001,True,True,True,1000,0.001,auto"+"\n"
    l6 = "ElasticNet,0.1,0.5,True,False,True,1000,True,0.0001,True,False,1123581321,random"+"\n"
    l7 = "ElasticNetCV,0.1,0.15,15,0.5,True,False,True,1000,True,0.0001,True,False,1123581321,random"
    texto1 = l1+l2+l3+l4+l5+l6+l7
    texto2 = "null"
    texto3 = "<descricaoDataset>,novaVersao"+"\n"+"<tipoAfinidade>,Ki"+"\n"+"<quantidadeProteinas>,null"+"\n"+"<sperman>,null"+"\n"+"<melhorEquacao>,null"+"\n"+"<comentarios>,novaVersao"+"\n"+"<nomeExperimento>,null"+"\n"+"<tipoMedia>,null"+"\n"+"<outlier>,no"
    arquivoSaida = "./inputFiles/ml.in"
    grava(texto1, arquivoSaida)
    arquivoSaida = "./inputFiles/pdbsProteina.txt"
    grava(texto2, arquivoSaida)
    arquivoSaida = "./inputFiles/config.csv"
    grava(texto3, arquivoSaida)
def pastaVazia(path): 
    if os.listdir(path) == []: 
        return True
    else: 
        return False 
def existeArquivo(arquivo):
    try:
        fo = open(arquivo, 'r')
    except IOError:
        return False
    return True

def numeroLinhas(arquivo):
    try:
        num_lines = sum(1 for line in open(arquivo))
    except:
        return 0
    return num_lines
def completaArquivoConfig(): #quando algum campo estiver vazio, vai complementar
    texto = leCsv("./inputFiles/config.csv")
    if not("<outlier>" in texto):
        gravaConfig("outlier", "no")
    if not("<nomeExperimento>" in texto):
        gravaConfig("nomeExperimento", "null")
        
    if not("<tipoMedia>" in texto):
        gravaConfig("tipoMedia", "training")        
        
    if not("<quantidadeInicialProteinas>" in texto):
        gravaConfig("quantidadeInicialProteinas", pegaConfig("quantidadeProteinas")) 
        