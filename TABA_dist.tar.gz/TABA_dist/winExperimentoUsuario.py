#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys

from PyQt4 import QtGui, QtCore# Import the PyQt4 module we'll need
from PyQt4.QtGui import QApplication, QDialog
import interfaceExperimentoUsuario
from func_Gerais import leCsv,grava, pegaConfig,get_arquivosSf, get_listaDistancias, download_PDB_file,get_Bind, temLigante, existeArquivo
from func_AplicaEquacaoUsuario import geraExperimento, chamaRotinasPreparacao, geraArquivoComTermoDeEnergiaExperimento, melhorEquacaoExperimento
from func_ContaInterMolCalcTermo import calc_average_distance
  
class experimentoUsuario(QtGui.QMainWindow, interfaceExperimentoUsuario.Ui_MainWindowExperimento):
    def __init__(self, parent = None):
        QtGui.QWidget.__init__(self, parent)
        self.setupUi(self)
        self.window1 = None
        self.setFixedSize(900,600)
        self.comboBox_distancias.clear()
        self.list1 = get_listaDistancias("./outputFiles/")
        nome = pegaConfig("descricaoDataset")
        quantia = pegaConfig("quantidadeProteinas")
        self.label_estruturaInicial.setText(pegaConfig("quantidadeInicialProteinas").strip())
        self.afinidade = pegaConfig("tipoAfinidade") 
        self.label_system.setText(nome)
        self.label_afinidade.setText(self.afinidade)
        self.label_quantia.setText(quantia)
        self.label_tipoMedia.setText(pegaConfig("tipoMedia"))    
        self.label_outliers.setText(pegaConfig("outlier").strip())  
        self.plainTextEdit_melhorEquacao.clear()
        self.label_bestFile.clear()
        self.label_bestCoeficiente.clear()
        self.label_logTeorico.clear()
        self.label_setaTL.setPixmap(QtGui.QPixmap("img/setaNula.png")) 
        self.label_relogio.hide()
        for text in self.list1:
            text = text.replace("./outputFiles/","")
            self.comboBox_distancias.addItem(text) # pega so arquivos de treino
        self.inibidor = pegaConfig("tipoAfinidade")
        if self.inibidor == "": # erro ao achar um inibidor
            reply = QtGui.QMessageBox.question(self, 'Message',"This PDB file was not downloaded yet. Please, do this first using 'Download' button in the main window.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.Ok)
            if reply == QtGui.QMessageBox.Ok:
                self.sair()
        self.comboBox_distancias.model().sort(0)
        self.comboBox_distancias.setCurrentIndex(0)
        self.setWindowTitle(self.windowTitle()+" to Experiment: "+pegaConfig("nomeExperimento"))
        self.movie = QtGui.QMovie("./img/gifTempo.gif")
        self.label_relogio.setMovie(self.movie)
        self.movie.stop()
    def experimentar(self):
        diretorio = "./outputFiles/"
        arq = "SF.csv"
        if not (existeArquivo(diretorio+arq)):
            reply = QtGui.QMessageBox.warning(self, 'Attention !!',"The files aren't prepared yet. Do the previous steps first!!!", QtGui.QMessageBox.Ok)
            pass
        else:
            self.experimentarOk()
    def experimentarOk(self): 
        self.progressBar.setValue(0)        
        if (self.validaPdb() == True) and (self.validaLigante() == True):       
            self.label_relogio.show()
            self.movie.start()
            self.gravaPdb()
            self.progressBar.setValue(10)
            self.melhorEquacao()
            self.progressBar.setValue(100)
            self.label_relogio.hide()
            self.movie.stop()
            QtGui.QMessageBox.information(self, "Message", "Operation completed")

        else:
            pass   
        
    def sair(self):        
        self.close()
        
    def melhorEquacao(self):
        from func_MelhorEquacao import melhor
        diretorio = "./outputFiles/"
        self.escondeBotoes()      
        maior = 0
        coef = 0
        # define coeficiente para comparar a melhor equação 
        if self.radioButton_r1.isChecked():
            self.coeficiente = "r1"
        if self.radioButton_r2.isChecked():
            self.coeficiente = "r2"
        if self.radioButton_sp.isChecked():
            self.coeficiente = "sp"  
        distancia = self.comboBox_distancias.currentText()
        lista = get_arquivosSf(diretorio,distancia) # pega arquivos SF com a distancia selecionada
        for arq in lista:
            QtGui.QApplication.processEvents() # para não travar
            coef,pv1, melhorEq = melhor(arq,self.coeficiente)
            if coef> float(maior):
                maior = coef
                melhorEquacao = melhorEq
                melhorArquivo = arq
                maior = str(maior)
        if self.coeficiente == "sp":
            coefStr = "Spearman"
        elif self.coeficiente == "r1":
            coefStr = "R"
        elif self.coeficiente == "r2":
            coefStr = "R2"
            
        if coef > 0:
            self.label_coef.setText("Best "+coefStr)
            self.label_bestCoeficiente.setText(str(maior))
            self.plainTextEdit_melhorEquacao.clear()
            self.plainTextEdit_melhorEquacao.appendPlainText(melhorEquacao)
            self.label_bestFile.setText(melhorArquivo.replace("./outputFiles/",""))

            texto = "[melhor Sperman]"+","+maior+"\n"+"[melhor Equacao]"+","+melhorEquacao+"\n"+"[melhor Arquivo]"+","+melhorArquivo
            grava(texto, diretorio+"melhorEquacao.csv")
        else:
            pass
        self.fazExperimento()  
        self.mostraBotoes()
        
    def fazExperimento(self):
        diretorio = "./inputFiles/" # define diretorio para salvar o download
        self.ligante = self.lineEdit_Ligante.text().upper()
        chamaRotinasPreparacao(diretorio, self.ligante) # chama runcoes para preparar arquivos para processamento
        arquivosParaLerUsu = leCsv(diretorio+"pdbsProteinaUsu.txt") # le arquivo com os pdbs a serem processados como proteinas. Este arquvivo so contem pdbs que tem arquivo de KI correspondente
        
        if temLigante("./pdbs/", arquivosParaLerUsu) == False:
            reply = QtGui.QMessageBox.question(self, 'Message',"The estructure to experiment don't have the ligand "+self.ligante,QtGui.QMessageBox.Ok, QtGui.QMessageBox.Ok)
            pass
        else:
            # entra o valor da distância
            distancia = float(self.comboBox_distancias.currentText())
            calc_average_distance(arquivosParaLerUsu,distancia,"USU",self.progressBar) # gera arquivo com medias do conjunto treino
            tipoMedia = pegaConfig("tipoMedia").strip()
            if tipoMedia == 'training':
                tipoMedia = 'TRE'
            else:
                tipoMedia = 'ALL'
            diretorio, arquivo = geraArquivoComTermoDeEnergiaExperimento(arquivosParaLerUsu,distancia,"Usu",tipoMedia) #gera arquivo de treino
            formula = melhorEquacaoExperimento()
            pdbNome, logKi, ki = geraExperimento("", arquivo, formula)
            logKiS = ("%.3f" % logKi)
            # vamos pegar só um valor calculado de ki pois a funcçao e utilizada tambem para conjunto teste
            logText = "The theoretical log "+ self.inibidor +" for "+pdbNome 
            self.label_log.setText(logText.replace("\n", ""))
            self.label_logTeorico.setText(str(logKiS))
            # coloca setas
            if (logKi<(-7.00001)):
                self.label_setaTL.setPixmap(QtGui.QPixmap("img/setaCima.png"))
                self.label_setaTL.setToolTip("Good result!")
            else:
                self.label_setaTL.setPixmap(QtGui.QPixmap("img/setaBaixo.png"))
                self.label_setaTL.setToolTip( "Bad result!")

            
    def gravaPdb(self):
        diretorio = "./inputFiles/"
        arq = "pdbsProteinaUsu.txt"
        arquivo = diretorio+arq
        texto = self.lineEdit_estrutura.text().upper()
        grava(texto, arquivo)
    def validaLigante(self):
        textoLigante = self.lineEdit_Ligante.text() 
        # valida ligante
        if len(textoLigante)<2 and len(textoLigante)>3 :
            reply = QtGui.QMessageBox.question(self, 'Message',"The value of Ligand is incorrect.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.Ok)
            return False
        else:
            return True      
    def validaPdb(self):
        valida = False
        textoPdb = self.lineEdit_estrutura.text()
        if len(textoPdb)!=4:
            reply = QtGui.QMessageBox.question(self, 'Message',"The value of PDB is incorrect.", QtGui.QMessageBox.Ok, QtGui.QMessageBox.Ok)
            return False
        else:
            # verifica se o arquivo exite
            my_dir_in = "./pdbs/"        
            if  not self.pre_download(my_dir_in,textoPdb):                
                valida = False
            else:
                valida = True   
        if valida:
            return True
        else:
            #opção para baixar direto o PDB, mas tem que gerar arquivos para regressão
            reply = QtGui.QMessageBox.question(self, 'Message',"This pdb code has not been downloaded yet. Do you want to do this now?", QtGui.QMessageBox.Yes|QtGui.QMessageBox.No, QtGui.QMessageBox.No)
            if reply == QtGui.QMessageBox.Yes: # vai baixar no saite
                self.label_relogio.show()
                self.movie.start()
                my_structureId_string = textoPdb.lower()
                #pdb
                myUrl = "http://files.rcsb.org/download/" 
                download_PDB_file(myUrl, my_structureId_string.upper()+".pdb")
                my_dir_in = "./ki/"        
                binding_info = self.inibidor
                #http://www.rcsb.org/pdb/rest/customReport?pdbids=1a4l&customReportColumns=structureId,chainId,ligandId,Ki&service=wsfile&format=csv&ssa=n                
                get_Bind(my_dir_in, my_structureId_string, binding_info)
                return True
            else:
                return False
            
            reply = QtGui.QMessageBox.question(self, 'Message',"This pdb code has not been downloaded yet. Please do this first.",QtGui.QMessageBox.Ok, QtGui.QMessageBox.Ok)
            return False
    def pre_download(self, my_dir_in,my_file_in):
        """Function to check if the file is already in the structure directory"""
       
        # Try to open file
        my_file_in = my_file_in.upper()+".pdb"

        try:
            my_fo = open(my_dir_in+my_file_in,"r")
            my_fo.close()
            return True 
        except:
            return False
                
    def escondeBotoes(self):
        self.toolButton_iniciar.setEnabled(False)
        self.toolButton_exit.setEnabled(False)
    def mostraBotoes(self):
        self.toolButton_iniciar.setEnabled(True)
        self.toolButton_exit.setEnabled(True)
