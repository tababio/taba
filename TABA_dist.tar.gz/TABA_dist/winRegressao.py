#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from PyQt4 import QtGui  # Import the PyQt4 module we'll need
from PyQt4.QtGui import QApplication, QDialog
from func_Gerais import pegaConfig
import interfaceRegressao
from func_RenomeiaArq import diretorio
from func_Sf import *
from func_Calcula import *
from func_manipulaArquivos import criaPasta, apagaArquivos
import sys
from func_Gerais import get_arquivosTreino, substituiSeedEmMLin
from datetime import datetime
from func_Gerais import get_arquivosSf, get_listaColunas, get_listaColunasDistancia
from random import seed
class fazRegressao(QtGui.QMainWindow, interfaceRegressao.Ui_MainWindow_regressao):
    def __init__(self, parent = None):
        QtGui.QWidget.__init__(self, parent)
        self.setupUi(self)
        self.window1 = None
        self.setFixedSize(800,600)
        self.comboBox_dataBase.clear()
        self.comboBox_distance.clear()
        self.label_tempoInicio.clear()
        self.label_tempoTranscrorrido.clear()
        self.label_arquivoEmProcesso.clear()
        self.label_tempoEstimado.clear()
        self.label_seed.clear()
        self.label_tipoMedia.setText(pegaConfig("tipoMedia"))
        self.escondeLabels()
        list1 = get_arquivosTreino("./outputFiles/")
        self.listDist = []
        listDist2 = []
        listDb = []
        nome = pegaConfig("descricaoDataset")
        quantia = pegaConfig("quantidadeProteinas")
        afinidade = pegaConfig("tipoAfinidade") 
        self.label_experimento.setText(nome)
        self.label_afinidade.setText(afinidade)
        self.label_quantia.setText(quantia)
        for text in list1:
            text = text.replace("./outputFiles/","")
            text2 = text.replace("_TE_Tre.csv","")
            text2 = text2.replace ("saida","")
            textDist = text2[-3:]
            textDB = text2.replace(textDist, "")
            textDB = textDB.replace("Todos","All") # para ficar em inglês
            if textDB not in listDb:
                self.comboBox_dataBase.addItem(textDB) # pega dbmoad,pdbbind, tex
            listDb.append(textDB)
            if textDist not in self.listDist:
                self.listDist.append(textDist)
        self.listDist = sorted(self.listDist)

        for item in self.listDist:
            self.comboBox_distance.addItem(item) # pega ditanica

        self.comboBox_distance.setCurrentIndex(0)
        self.comboBox_dataBase.model().sort(0)
        self.comboBox_dataBase.setCurrentIndex(0) 
        
        self.label_relogio.hide()
        #self.preencheColunas()
        get_listaColunasDistancia("./outputFiles/")
        self.setWindowTitle(self.windowTitle()+" to "+pegaConfig("descricaoDataset"))

    def iniciarRegressao(self): 
        if (self.listDist == []) or (pegaConfig("nomeExperimento")=="null"):
            reply = QtGui.QMessageBox.warning(self, 'Attention !!',"The files aren't prepared yet. Do the previous steps first!!!", QtGui.QMessageBox.Ok)
            pass
        else:
            reply = QtGui.QMessageBox.question(self, 'Message',"This operation takes some time. Do you want to proceed?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)

            if reply == QtGui.QMessageBox.Yes:
                apagaArquivos("./adjustmentFunctions/")
                self.escondeLabels()
                self.fazRegressao()
            else:
                pass
 
    def sair(self):        
        self.close()
        
    def fazRegressao(self):
        self.tempoInicio = datetime.now()
        dist = str(self.comboBox_distance.currentText())
        seed = substituiSeedEmMLin(dist) # substitui a semente no arquivo ml.in pelo valor da semente utilizada quando gera arquivos para correlação (30/12/2017)
        self.label_tempoInicio.setText(self.tempoInicio.strftime('%H:%M:%S - %d/%b/%y'))
        mensagem ="Doing linear regression"
        self.label_seed.setText(seed)
        self.escondeBotoes()
        self.label_relogio.show()
        self.progressBar.setValue(0)
        diretorio = "./outputFiles/"
        #parametros para alterar    
        num_col = int(self.comboBox_variaveis.currentText())+1
        base = str(self.comboBox_dataBase.currentText())
        base = base.replace("All", "Todos") # substitui para achar o nome certo do arquivo
        nomeArquivo = "saida"+base+str(dist)+"_TE_Tre.csv"
        arquivo = nomeArquivo
        #arquivo = arquivo.replace(".csv", "_TE_Tre.csv") # corrige nome do arquivo escolhido
        csv_file1 = diretorio+arquivo    # Not a scaled file    
        v1 = "Pred. Log(Ki)" 
        v2 = "N"
        v3 = "Standard deviation" 
        v4 = "R"
        v5 = "R-squared"
        v6 = "p-value1" # os p-value devem ter nomes diferentes
        v7 = "Adjusted R-square"
        v8 = "Spearman correlation"
        v9 = "p-value2"  # os p-value devem ter nomes diferentes
        v10 = "Quality factor (Q)"
        v11 = "q-squared for LOO"
        v12 = "F-stat"
        v13 = "Chi-squared"
        v14 = "RMSE"
        cabecalho = v1+","+v2+","+v3+","+v4+","+v5+","+v6+","+v7+","+v8+","+v9+","+v10+","+v11+","+v12+","+v13+","+v14+"\n"
        # define a possibilidade de utiliar somente linear regression pois normalmente tras os melhores resultados
        if self.radioButton_am.isChecked():
            metodos = ["LinearRegression","Ridge","RidgeCV","Lasso","LassoCV","ElasticNet","ElasticNetCV"]
        if self.radioButton_lr.isChecked():
            metodos = ["LinearRegression"]
        #print(metodos)
        
        cont =0
        for metodo in metodos:   
            cont = cont+1
            # mostra metodos
            if cont ==1:
                self.label_linearRegression.setEnabled(True)
                self.label_seta_1.show()
            if cont ==2:
                self.label_ridge.setEnabled(True)
                self.label_seta_2.show()    
            if cont ==3:
                self.label_ridgeCV.setEnabled(True)
                self.label_seta_3.show()
            if cont ==4:
                self.label_lasso.setEnabled(True)  
                self.label_seta_4.show()
            if cont ==5:
                self.label_lassoCV.setEnabled(True)
                self.label_seta_5.show()
            if cont ==6:
                self.label_elasticNet.setEnabled(True)
                self.label_seta_6.show()   
            if cont ==7:
                self.label_elasticNetCV.setEnabled(True)
                self.label_seta_7.show()

            try:
                fo1 = open(csv_file1,"r") # so para verificar se existe arquivo
                fo1.close()
                mensagem =(str(csv_file1)+" "+str(metodo)+" "+str(num_col))
                self.label_arquivoEmProcesso.setText(mensagem.replace("./outputFiles/",""))
                #QtGui.QApplication.processEvents() # para não travar
                # Chama rotinas para regressao
                existe = chama_calcula(csv_file1,metodo,num_col,cabecalho,diretorio, self.progressBar)
                #QtGui.QApplication.processEvents() # para não travar
            except IOError:
                mensagem ="The file "+csv_file1+" not exist. Generate in the main window with 'Do File' button"
                reply = QtGui.QMessageBox.warning(self, 'Alert',mensagem,QtGui.QMessageBox.Ok)

            # barra progresso
            # marca metodos
            if cont ==1:
                self.label_linearRegression_2.show()
            if cont ==2:
                self.label_ridge_2.show()
            if cont ==3:
                self.label_ridgeCV_2.show()
            if cont ==4:
                self.label_lasso_2.show()
            if cont ==5:
                self.label_lassoCV_2.show()
            if cont ==6:
                self.label_elasticNet_2.show()
            if cont ==7:
                self.label_elasticNetCV_2.show()
                
            tempoPassado = datetime.now() - self.tempoInicio
            tempoEstimado = (tempoPassado/cont)*7
            self.label_tempoTranscrorrido.setText(str(tempoPassado))  
            self.label_tempoEstimado.setText(str(tempoEstimado))           
        self.mostraBotoes()
        self.label_relogio.hide()
        if existe:
            mensagemExtra = ". This file was already generated before."
        else:
            mensagemExtra = ""
        QtGui.QMessageBox.information(self, "Message", "Operation completed"+mensagemExtra)
    def escondeBotoes(self):
        self.toolButton_iniciar.setEnabled(False)
        self.toolButton_exit.setEnabled(False)
    def mostraBotoes(self):
        self.toolButton_iniciar.setEnabled(True)
        self.toolButton_exit.setEnabled(True)  
    def escondeLabels(self):
        self.label_linearRegression_2.hide()
        self.label_ridge_2.hide()
        self.label_ridgeCV_2.hide()
        self.label_lasso_2.hide()
        self.label_lassoCV_2.hide()
        self.label_elasticNet_2.hide()
        self.label_elasticNetCV_2.hide()  
        
        self.label_seta_1.hide()
        self.label_seta_2.hide()
        self.label_seta_3.hide()
        self.label_seta_4.hide()
        self.label_seta_5.hide()
        self.label_seta_6.hide()
        self.label_seta_7.hide()
         
        self.label_linearRegression.setEnabled(False) 
        self.label_ridge.setEnabled(False) 
        self.label_ridgeCV.setEnabled(False) 
        self.label_lasso.setEnabled(False) 
        self.label_lassoCV.setEnabled(False) 
        self.label_elasticNet.setEnabled(False) 
        self.label_elasticNetCV.setEnabled(False)           
    def preencheColunas(self):   # preenche combo com colunas que ainda nao foram geradas
        self.comboBox_variaveis.clear()
        list2 = get_listaColunas("./outputFiles/")
        for x in range(2, 10):
            col = str(x)
            if not col in list2:
                self.comboBox_variaveis.addItem(col)                