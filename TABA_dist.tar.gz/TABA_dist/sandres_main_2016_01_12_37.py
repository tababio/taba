# SAnDReS   
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Walter F. de Azevedo Jr.   
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila, Nayara M. Bernhardt Levin, 
# Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems Biology Laboratory in 
# Porto Alegre, RS Brazil as version number 1.0.1. 
#
# Current Version 1.0.2. released on 12 January 2017.
#
# Xavier, M.M,; Heck, G.S.; de Avila, M.B.; Levin, N.M.; Pintro,  V.O.;  Carvalho, N.L.;  Azevedo, W.F. Jr.
# SAnDReS a Computational Tool for Statistical Analysis of  Docking  Results  and  Development  of  Scoring
# Functions. Comb.  Chem.  High Throughput Screen, 2016; 19
# DOI: 10.2174/1386207319666160927111347 
#
###############################################################################################################
# 
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    SAnDReS is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    SAnDReS is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with SAnDReS.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################################################
#
# Contact
# SAnDReS is in continuous development, feel free to download the latest version and use it in the analysis of your # docking results. If you have any question regarding SAnDReS, please feel free to e-mail me: walter@azevedolab.net 
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico - National Counsel of Technological 
# and Scientific Development (www.cnpq.br)  
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0 and 308883/2014-4.
#
###############################################################################################################



# Set up SAnDReS root directory
sandres_root = "C:\\sandres\\"

class ProteinStructure(object):
    """Function to create a protein object with information gathered from a PDB file"""
    total = 0 
    radius = []
    main_chain_atoms = ["N ","CA","C ","O "]
    aa = ["ALA","ARG","ASN","ASP","CYS","GLU","GLN","GLY","HIS","ILE",
          "LEU","LYS","MET","PHE","PRO","SER","THR","TRP","TYR","VAL"]
    
    # Atomic mass taken from GROMOS FF (53a6)
    atomic_mass = {"H": 1.008,
                   "C": 12.011,
                   "N": 14.0067,
                   "O": 15.9994,
                   "P": 30.9738,
                   "S": 32.06
                   }
    
    # Source for residue molecular weights: http://www.matrixscience.com/help/aa_help.html 
    # (Accessed on May 8th 2014)
    # To calculate the mass of a neutral peptide or protein, sum the residue masses plus the masses 
    # of the terminating groups (e.g. H at the N-terminus and OH at the C-terminus). 
    resMW = {"ALA": 71.0779,
             "ARG": 156.1857,
             "ASN": 114.1026,
             "ASP": 115.0874,
             "CYS": 103.1429,
             "GLU": 129.114,
             "GLN": 128.1292,
             "GLY": 57.0513,
             "HIS": 137.1393,
             "ILE": 113.1576,
             "LEU": 113.1576,
             "LYS": 128.1723,
             "MET": 131.1961,
             "PHE": 147.1739,
             "PRO": 97.1152,
             "SER": 87.0773,
             "THR": 101.1039,
             "TRP": 186.2099,
             "TYR": 163.1733,
             "VAL": 99.1311}
    
    @staticmethod
    def status():
        print("\nThe total number of protein structures is ",ProteinStructure.total)
    
    def __init__(self,file_in):
        import sys 
        self.file_in = file_in
        
        # Assigns the content of the PDB file to pdb_file
        try:
            pdb_file = open(self.file_in,"r")
        except:
            print("\nI can't find file ",self.file_in)
            print("\nPlease check directory and/or file name.")
            input("\nPress enter key to exit program.")
            sys.exit(0)  # Exiting program
            
        # Assigns the content of the PDB file to a list
        self.__list_in = pdb_file.readlines()   # Private attribute self.__list_in
        
        # Adds one to the count
        ProteinStructure.total += 1
 
    def make_sphere(self,number_of_spheres,my_radius):
        """Method to create spheres of atoms"""
        self.number_of_spheres = number_of_spheres
        ProteinStructure.my_radius = []
        for i in range(self.number_of_spheres):
            ProteinStructure.my_radius.append(my_radius[i])
        
        x_center = 0
        y_center = 0
        z_center = 0
        count_atoms = 0
        self.__count_lines     = [0,0,0,0,0,0,0,0,0,0]
        self.__count_lines_MC  = [0,0,0,0,0,0,0,0,0,0]
        self.__count_lines_SC  = [0,0,0,0,0,0,0,0,0,0]
        # my_matrix = [[0]*number_columns for i in range(number_rows)] 
        self.__matrix_4_sphere      = [[None]*1000000 for i in range(10)]
        self.__matrix_4_sphere_MC   = [[None]*1000000 for i in range(10)]
        self.__matrix_4_sphere_SC   = [[None]*1000000 for i in range(10)]
        
        # Looping through self.__list_4_active_ligand_atoms to find the center of the ligand
        for line in self.__list_4_active_ligand_atoms:  # Accessing private attribute self.__list_4_active_ligand_atoms
            x_center += float(line[30:38])
            y_center += float(line[38:46])
            z_center += float(line[46:54])
            count_atoms += 1
        if count_atoms > 0:
            x_center = x_center/count_atoms
            y_center = y_center/count_atoms
            z_center = z_center/count_atoms
        else:
            print("\nNo atoms in the list!")
                        
        # Create lists with sphere contents
        for i in range(self.number_of_spheres):
            j = 0
            # Looping through self.__list_4_all_atoms 
            for line in self.__list_4_all_atoms:    # Accessing private attribute self.__list_4_all_atoms
                x_atm = float(line[30:38])
                y_atm = float(line[38:46])
                z_atm = float(line[46:54])
                
                # Calculates distance from the center of the ligand
                dist = ( (x_center - x_atm)**2 + (y_center - y_atm)**2 + (z_center - z_atm)**2 )**0.5
               
                # Checks if atoms are inside sphere
                if dist <= ProteinStructure.my_radius[i] :
                    self.__matrix_4_sphere[i][j] = line
                    self.__count_lines[i] += 1
                    if line[0:6] == "ATOM  " and line[13:15] in ProteinStructure.main_chain_atoms:
                        self.__matrix_4_sphere_MC[i][j] = line
                        self.__count_lines_MC[i] += 1
                    else:
                        self.__matrix_4_sphere_SC[i][j] = line
                        self.__count_lines_SC[i] += 1 
                    j += 1      
       
    def make_sphere_wat(self,water_dir_in,pdb_in_4_water,lig_in_4_water,my_radius_4_water,my_max_water):
        """Method to create spheres of water atoms"""
        import sys 
        import os
        import errno
        x_center = 0
        y_center = 0
        z_center = 0 
        count_atoms_water = 0 
        count_lines_water     = 0
        list_water_sphere    = []
        ProteinStructure.total -= 1 # To decrease the total number of structures, that will be used to show the number of PDB files used for correlation coefficient analysis

        # Looping through self.__list_4_active_ligand_atoms to find the center of the ligand
        for line in self.__list_4_active_ligand_atoms:  # Accessing private attribute self.__list_4_active_ligand_atoms
            x_center += float(line[30:38])
            y_center += float(line[38:46])
            z_center += float(line[46:54])
            count_atoms_water += 1
        if count_atoms_water > 0:
            x_center = x_center/count_atoms_water
            y_center = y_center/count_atoms_water
            z_center = z_center/count_atoms_water
        else:
            sys.exit("\nNo atoms in the list!")
                          
        # Create lists with sphere contents
        if len(self.__list_4_water_atoms) > 0:
            # Looping through self.__list_4_water_atoms 
            for line in self.__list_4_water_atoms:    # Accessing private attribute self.__list_4_water_atoms
                
                # This if eliminates hydrogen atoms present in water molecules
                if line[13:14] != "H" and line[56:60] == "1.00" : # To avoid water molecules with occupation factor different of 1.00 
                    x_atm = float(line[30:38])
                    y_atm = float(line[38:46])
                    z_atm = float(line[46:54])
                
                    # Calculates distance for oxygen atoms only
                    dist = ( (x_center - x_atm)**2 + (y_center - y_atm)**2 + (z_center - z_atm)**2 )**0.5
                else:
                    dist = 1000.0   # In oder to not have hydrogen atoms and oxygen with occupation factor != 1.00
                    
                # Checks if atoms are inside sphere
                if dist <= my_radius_4_water and count_lines_water < my_max_water:
                    list_water_sphere.append(line)
                    count_lines_water += 1     
                    
        # Test if there is water molecule inside a sphere centered at the active ligand structure
        if count_lines_water > 0:
            path =water_dir_in[0:len(water_dir_in)]+pdb_in_4_water[0:4]+"\\" 
            # Create directories
            try:
                os.makedirs(path)
            except OSError as exception:
                if exception.errno != errno.EEXIST:
                    raise        
            # Write PDB file    
            new_PDB_file_wat_name = path+pdb_in_4_water[0:4]+"_"+lig_in_4_water+"_H2O.pdb"               
            new_PDB_file_wat = open(new_PDB_file_wat_name,"w")
            new_PDB_file_wat.writelines(self.__list_4_protein_atoms)
            new_PDB_file_wat.write("TER\n")
            new_PDB_file_wat.writelines(self.__list_4_ligand_atoms)
            new_PDB_file_wat.write("TER\n")
            new_PDB_file_wat.writelines(list_water_sphere)
            new_PDB_file_wat.write("END\n")
            new_PDB_file_wat.close()
        else:
            print("\nI didn't find any water molecules in the file: ",pdb_in_4_water," with radius <= ",my_radius_4_water)
        
        return count_lines_water
 
    def make_list_of_atoms(self,name_in,chain_in,number_in):
        """Method to create a list of atoms read from a PDB file"""
        self.name_in = name_in
        self.chain_in = chain_in
        self.number_in = number_in
        self.__list_4_protein_atoms         = []    # Create an empty list
        self.__list_4_protein_atoms_MC      = []    # Create an empty list
        self.__list_4_protein_atoms_SC      = []    # Create an empty list
        self.__list_4_ligand_atoms          = []    # Create an empty list
        self.__list_4_active_ligand_atoms   = []    # Create an empty list
        self.__list_4_water_atoms           = []    # Create an empty list
        self.__list_4_all_atoms             = []    # Create an empty list

        # Set initial values for count of atoms
        count_protein_atoms = 0
        count_protein_atoms_MC = 0  # For main-chain atoms only
        count_protein_atoms_SC = 0  # For side-chain atoms only
        count_ligand_atoms = 0
        count_active_ligand_atoms = 0
        count_water_atoms = 0
        count_all_atoms = 0
    
        # Looping through self.list_in to identify atoms
        for line in self.__list_in :    # Accessing private attribute self.__list_in
            if line[0:6] == "HETATM" and line[17:20] != "HOH": # Excludes HOH atoms from HETATM
                self.__list_4_ligand_atoms.append(line)
                self.__list_4_all_atoms.append(line)
                count_all_atoms += 1
                count_ligand_atoms += 1
            elif line[0:6] == "HETATM" and line[17:20] == "HOH" : # Read water atoms from HETATM
                self.__list_4_water_atoms.append(line)
                self.__list_4_all_atoms.append(line)
                count_all_atoms += 1
                count_water_atoms += 1
            elif line[0:6] == "ATOM  ": # Read protein atoms
                self.__list_4_protein_atoms.append(line)
                self.__list_4_all_atoms.append(line)
                count_all_atoms += 1
                count_protein_atoms += 1
                if line[13:15] in ProteinStructure.main_chain_atoms:
                    self.__list_4_protein_atoms_MC.append(line)
                    count_protein_atoms_MC += 1
                else:
                    self.__list_4_protein_atoms_SC.append(line)
                    count_protein_atoms_SC += 1
        
        # Looping through self.__list_in to identify only active ligand atoms
        for line in self.__list_in : # Accessing private attribute self.__list_in
            if line[0:6] == "HETATM" and line[17:20] == self.name_in and line[21:22] == self.chain_in and line[22:26] == self.number_in :# Excludes HOH atoms from HETATM
                self.__list_4_active_ligand_atoms.append(line)
                count_active_ligand_atoms += 1
          
        return count_protein_atoms,count_ligand_atoms, count_water_atoms,count_all_atoms,count_active_ligand_atoms
      
    def radius_of_gyration(self):
        """Method to calculate the radius of gyration for a molecule"""
        import math
    
        # Dictionary of masses for non-hydrogen atoms taken from GROMOS FF (53a6)
        atomic_masses_4_rG = {" C": 12.011,
                              " N": 14.0067,
                              " O": 15.9994,
                              " S": 32.06
                   }
    
        # list of masses for non-hydrogen atoms taken from GROMOS FF (53a6)
        list_of_atom_labels_4_rG = [" C"," N"," O"," S"]
    
        # Assigns initial values and declares lists
        list_x_4_rG                 = []                    # List of x atomic coordinates
        list_y_4_rG                 = []                    # List of y atomic coordinates
        list_z_4_rG                 = []                    # List of z atomic coordinates
        list_of_masses_4_rG         = []                    # List of atomic masses
        sum_distance2_mass_4_rG     = 0                     # Assigns initial value 0 for sum of distance2*list_of_masses_4_rG[i]
        sum_distance2_4_rG          = 0                     # Assigns initial value 0 for sum of distance2
        molWeight_4_rG              = 0                     # Assigns initial value 0 for molWeight_4_rG
        count_atoms_4_rG            = 0                     # Sets up initial value to 0 for the count_atoms_4_rG
    
        # Set up initial value to 0 for Atomic coordinates for center of mass
        xCM_4_rG = 0
        yCM_4_rG = 0
        zCM_4_rG = 0
    
        # Looping through the self.__list_4_protein_atoms to calculate rCM (xCM_4_rG, yCM_4_rG, zCM_4_rG)
        for line in self.__list_4_protein_atoms:
            if line[0:6] == "ATOM  ":
                if line[12:14] in list_of_atom_labels_4_rG: # Gets only atoms in the list_of_atom_labels_4_rG
            
                    # Gets atomic masses from the list atomic_masses_4_rG
                    molWeight_4_rG += float(atomic_masses_4_rG.get(str(line[12:14])) )  
            
                    # Adds atomic coordinates that will be used for center of mass calculation
                    xCM_4_rG += float(line[30:38])*float(atomic_masses_4_rG.get(str(line[12:14])) )  
                    yCM_4_rG += float(line[38:46])*float(atomic_masses_4_rG.get(str(line[12:14])) )
                    zCM_4_rG += float(line[46:54])*float(atomic_masses_4_rG.get(str(line[12:14])) )
            
                    list_x_4_rG.append(float(line[30:38]))           # Appends x atomic coordinate to list_x_4_rG
                    list_y_4_rG.append(float(line[38:46]))           # Appends y atomic coordinate to list_y_4_rG
                    list_z_4_rG.append(float(line[46:54]))           # Appends z atomic coordinate to list_z_4_rG
            
                    # Calculates distance vector for each non-hydrogen atoms
                    
                    list_of_masses_4_rG.append(float(atomic_masses_4_rG.get(str(line[12:14]))))   # Append mass to the list
                    
                    # Adds 1 to count_atoms_4_rG
                    count_atoms_4_rG += 1
        # Ends loop
        
        if count_atoms_4_rG > 0:
            # Calculates the atomic coordinates for the center of mass        
            xCM_4_rG = xCM_4_rG/molWeight_4_rG
            yCM_4_rG = yCM_4_rG/molWeight_4_rG
            zCM_4_rG = zCM_4_rG/molWeight_4_rG
    
            # Looping through to calculate radius of gyration (rG)
            for i in range(len(list_x_4_rG)):
                # Calculates distance vector for each non-hydrogen atom in the list
                distance2 =  (list_x_4_rG[i] - xCM_4_rG  )**2 + (list_y_4_rG[i] - yCM_4_rG)**2 + (list_z_4_rG[i] - zCM_4_rG)**2
        
                # Adds distance2 to sum_dist
                sum_distance2_4_rG+= distance2                                
        
                # Adds the product list_of_masses_4_rG[i]*distance2 to sum_distance2_mass_4_rG
                sum_distance2_mass_4_rG += list_of_masses_4_rG[i]*distance2   
        
            # Ends loop
            
            rG2 = sum_distance2_mass_4_rG/molWeight_4_rG    # Calculates rG2 = rG**2
            rG = math.sqrt(rG2)                             # Calculates rG
        else:
            rG = None                                       # Assigns None to rG
            print("\nNo atoms in the list!")
        
        return rG                                           # Returns radius of gyration (rG)
    
    def calculate_SS_bonds(self,system_4_SS):
        """Method to calculate the number of SS bonds present in a structure"""
        import math
        count_SS_bonds = 0
        count_SG = 0
        ss_x = []
        ss_y = []
        ss_z = []
        self.system_4_SS = system_4_SS
        
        # Get the list of atoms for the system
        self.__list_4_SS = self.get_list_of_atoms(self.system_4_SS) # Private attribute self.__list_4_SS
        
        # Looping through atoms to identify SS bonds
        for line in self.__list_4_SS:
            if line[0:6] == "ATOM  " and line[13:15] == "SG" and (float(line[56:60]) > 0.50) : # I consider only S atoms for which occupancy is higher than 0.50
                ss_x.append(float(line[30:38]))
                ss_y.append(float(line[38:46]))
                ss_z.append(float(line[46:54]))
                count_SG += 1
        
        # Looping through the SG atoms
        for i in range(count_SG):
            for j in range(i+1,count_SG):
                distance_SS = math.sqrt( (ss_x[i] - ss_x[j] )**2 + (ss_y[i] - ss_y[j] )**2 + (ss_z[i] - ss_z[j])**2   )
                if distance_SS < 2.1 and distance_SS > 2.0:
                    count_SS_bonds += 1
                                  
        return count_SS_bonds
        
    def get_list_of_atoms(self,my_atoms_in):
        """Method to get the right list of atoms"""
        import sys
        self.my_atoms_in = my_atoms_in
        
        #Identify three different type of atoms
        if self.my_atoms_in == "Protein":
            return self.__list_4_protein_atoms          # Accessing private attribute      
        elif self.my_atoms_in == "ProteinMC":
            return self.__list_4_protein_atoms_MC       # Accessing private attribute
        elif self.my_atoms_in == "ProteinSC":
            return self.__list_4_protein_atoms_SC       # Accessing private attribute
        elif self.my_atoms_in == "Ligand":
            return self.__list_4_ligand_atoms           # Accessing private attribute
        elif self.my_atoms_in == "Active":
            return self.__list_4_active_ligand_atoms    # Accessing private attribute
        elif self.my_atoms_in == "Water":
            return self.__list_4_water_atoms            # Accessing private attribute
        elif self.my_atoms_in == "Whole":
            return self.__list_4_all_atoms              # Accessing private attribute
        elif self.my_atoms_in == "Sphere0":
            return list(self.__matrix_4_sphere[0][0:self.__count_lines[0]])         # Accessing private attribute
        elif self.my_atoms_in == "Sphere0MC":
            return list(self.__matrix_4_sphere_MC[0][0:self.__count_lines_MC[0]])   # Accessing private attribute 
        elif self.my_atoms_in == "Sphere0SC":
            return list(self.__matrix_4_sphere_SC[0][0:self.__count_lines_SC[0]])   # Accessing private attribute 
        elif self.my_atoms_in == "Sphere1":
            return list(self.__matrix_4_sphere[1][0:self.__count_lines[1]])         # Accessing private attribute 
        elif self.my_atoms_in == "Sphere1MC":
            return list(self.__matrix_4_sphere_MC[1][0:self.__count_lines_MC[1]])   # Accessing private attribute 
        elif self.my_atoms_in == "Sphere1SC":
            return list(self.__matrix_4_sphere_SC[1][0:self.__count_lines_SC[1]] )  # Accessing private attribute
        elif self.my_atoms_in == "Sphere2":
            return list(self.__matrix_4_sphere[2][0:self.__count_lines[2]] )        # Accessing private attribute
        elif self.my_atoms_in == "Sphere2MC":
            return list(self.__matrix_4_sphere_MC[2][0:self.__count_lines_MC[2]] )  # Accessing private attribute
        elif self.my_atoms_in == "Sphere2SC":
            return list(self.__matrix_4_sphere_SC[2][0:self.__count_lines_SC[2]] )  # Accessing private attribute
        elif self.my_atoms_in == "Sphere3":
            return list(self.__matrix_4_sphere[3][0:self.__count_lines[3]] )        # Accessing private attribute
        elif self.my_atoms_in == "Sphere3MC":
            return list(self.__matrix_4_sphere_MC[3][0:self.__count_lines_MC[3]] )  # Accessing private attribute
        elif self.my_atoms_in == "Sphere3SC":
            return list(self.__matrix_4_sphere_SC[3][0:self.__count_lines_SC[3]] )  # Accessing private attribute
        elif self.my_atoms_in == "Sphere4":
            return list(self.__matrix_4_sphere[4][0:self.__count_lines[4]] )        # Accessing private attribute
        elif self.my_atoms_in == "Sphere4MC":
            return list(self.__matrix_4_sphere_MC[4][0:self.__count_lines_MC[4]] )  # Accessing private attribute
        elif self.my_atoms_in == "Sphere4SC":
            return list(self.__matrix_4_sphere_SC[4][0:self.__count_lines_SC[4]] )  # Accessing private attribute
        elif self.my_atoms_in == "Sphere5":
            return list(self.__matrix_4_sphere[5][0:self.__count_lines[5]] )        # Accessing private attribute
        elif self.my_atoms_in == "Sphere5MC":
            return list(self.__matrix_4_sphere_MC[5][0:self.__count_lines_MC[5]] )  # Accessing private attribute
        elif self.my_atoms_in == "Sphere5SC":
            return list(self.__matrix_4_sphere_SC[5][0:self.__count_lines_SC[5]] )  # Accessing private attribute
        elif self.my_atoms_in == "Sphere6":
            return list(self.__matrix_4_sphere[6][0:self.__count_lines[6]] )        # Accessing private attribute
        elif self.my_atoms_in == "Sphere6MC":
            return list(self.__matrix_4_sphere_MC[6][0:self.__count_lines_MC[6]] )  # Accessing private attribute
        elif self.my_atoms_in == "Sphere6SC":
            return list(self.__matrix_4_sphere_SC[6][0:self.__count_lines_SC[6]])   # Accessing private attribute
        elif self.my_atoms_in == "Sphere7":
            return list(self.__matrix_4_sphere[7][0:self.__count_lines[7]])         # Accessing private attribute
        elif self.my_atoms_in == "Sphere7MC":
            return list(self.__matrix_4_sphere_MC[7][0:self.__count_lines_MC[7]])   # Accessing private attribute
        elif self.my_atoms_in == "Sphere7SC":
            return list(self.__matrix_4_sphere_SC[7][0:self.__count_lines_SC[7]])   # Accessing private attribute
        elif self.my_atoms_in == "Sphere8":
            return list(self.__matrix_4_sphere[8][0:self.__count_lines[8]])         # Accessing private attribute
        elif self.my_atoms_in == "Sphere8MC":
            return list(self.__matrix_4_sphere_MC[8][0:self.__count_lines_MC[8]])   # Accessing private attribute
        elif self.my_atoms_in == "Sphere8SC":
            return list(self.__matrix_4_sphere_SC[8][0:self.__count_lines_SC[8]])   # Accessing private attribute
        elif self.my_atoms_in == "Sphere9":
            return list(self.__matrix_4_sphere[9][0:self.__count_lines[9]])         # Accessing private attribute
        elif self.my_atoms_in == "Sphere9MC":
            return list(self.__matrix_4_sphere_MC[9][0:self.__count_lines_MC[9]])   # Accessing private attribute
        elif self.my_atoms_in == "Sphere9SC":
            return list(self.__matrix_4_sphere_SC[9][0:self.__count_lines_SC[9]]  ) # Accessing private attribute     
        else:
            print("\nError! Unidentified type of atoms.")
            input("Press enter key to exit program!")
            sys.exit(0)  # Exiting program
        
    def calculate_B_value_Occupancy(self,system_4_BO):
        """Method to calculate mean B-value and occupancy"""
        import sys
        self.system_4_BO = system_4_BO      
        # Set initial values
        count_system_atoms = 0
        b_value_4_system = 0.0
        occupancy_4_system = 0.0
        
        # Get the list of atoms for the system
        self.__list_4_BO = self.get_list_of_atoms(self.system_4_BO) # Private attribute self.__list_4_BO
        
        # Looping through self.__list_4_BO to get b_value and occupancy
        for line in self.__list_4_BO:                   # Accessing private attribute
            if line != None:
                b_value_4_system += float(line[61:65])
                occupancy_4_system += float(line[56:60])
                count_system_atoms += 1
        if count_system_atoms > 0:
            b_value_4_system = b_value_4_system/count_system_atoms
            occupancy_4_system = occupancy_4_system/count_system_atoms
            return b_value_4_system, occupancy_4_system
        else:
            if self.system_4_BO == "Water":
                print("No water molecules!")
                return None,None  # To handle missing water molecules
            else:
                print("\nNo atoms in the list.")
                print("Please check the input PDB files or sphere radius.")
                input("Press enter key to exit program!")
                sys.exit(0)  # Exiting program
                    
    def protein_MW(self,selection_in):
        """Method to calculate molecular weight for protein, peptides and protein fragments"""
        import sys
        self.selection_in = selection_in
        readRes = []
        molWeight = 0.0
        count_protein_atoms_4_MW = 0 
        # Get the list of atoms for the system
        self.__list_4_MW = self.get_list_of_atoms(selection_in)    # Private attribute self.__list_4_MW
        
        # Looping through self.__list_4_MW to get molecular weights
        for line in self.__list_4_MW:                   # Accessing private attribute
            if line[0:6] == "ATOM  ":
                count_protein_atoms_4_MW += 1
                if line[17:20] in ProteinStructure.aa and line[22:26] not in readRes:
                    molWeight += ProteinStructure.resMW.get(str(line[17:20]))
                    readRes.append(line[22:26]) 
        molWeight = molWeight + 18.0148 # Adds masses for H from N-terminal and OH from C-terminal
        if count_protein_atoms_4_MW == 0:
            print("\nNo atoms in the list.")
            print("Please check the input PDB files and the radius of Spheres.")
            print("You may need to increase the radius of Spheres.")
            input("Press enter key to exit program!")
            sys.exit(0)  # Exiting program 
        else:
            return molWeight
    
    def read_resolution(self):
        """Method to read crystallographic resolution from a PDB"""
        self.__resol = None
        # Looping through self.__list_in to get resolution information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:21] == "REMARK   2 RESOLUTION" :
                # To overcome NULL values for resolution
                try:
                    self.__resol = float(line[26:30])
                except ValueError:
                    self.__resol = None
                
        return self.__resol

    def read_rfactor(self):
        """Method to read crystallographic R-factor from a PDB"""
        r_factor = None
        # Looping through self.__list_in to get R-factor information
        for line in self.__list_in:                     # Accessing private attribute
            if line[13:45] == "R VALUE            (WORKING SET)" :              # XPLOR, CNS, CNX, REFMAC, BUSTER-TNT and PHENIX
                # To overcome NULL values for R-factor
                try:
                    r_factor = float(line[48:53])
                except ValueError:
                    r_factor = None
                    
            elif line[13:45] == "R VALUE             (WORKING SET" :              # BUSTER-TNT
                # To overcome NULL values for R-factor
                try:
                    r_factor = float(line[48:55])
                except ValueError:
                    r_factor = None
            
            elif line[13:53] == "R VALUE          (WORKING SET, F>4SIG(F)":     # SHELXL
                # To overcome NULL values for R-factor
                try:
                    r_factor = float(line[56:62])
                except ValueError:
                    r_factor = None
                
        return r_factor
 
    def read_rfactor_work_test(self):
        """Method to read crystallographic R-factor for working+test sets from a PDB"""
        r_factor_work_test = None
        # Looping through self.__list_in to get R-factor information
        for line in self.__list_in:                     # Accessing private attribute
            if line[13:45] == "R VALUE      (WORKING + TEST SET)" :              # XPLOR, CNS, CNX, REFMAC, BUSTER-TNT and PHENIX
                # To overcome NULL values for R-factor
                try:
                    r_factor_work_test = float(line[48:53])
                except ValueError:
                    r_factor_work_test = None
                    
            elif line[13:45] == "R VALUE      (WORKING + TEST SET" :              # BUSTER-TNT
                # To overcome NULL values for R-factor
                try:
                    r_factor_work_test = float(line[48:55])
                except ValueError:
                    r_factor_work_test = None
            
            elif line[13:53] == "R VALUE   (WORKING + TEST SET, F>4SIG(F)":     # SHELXL
                # To overcome NULL values for R-factor
                try:
                    r_factor_work_test = float(line[56:62])
                except ValueError:
                    r_factor_work_test = None
                
        return r_factor_work_test
    
    def read_rfree(self):
        """Method to read crystallographic R-free from a PDB"""
        r_free = None
        get_data = False
        # Looping through self.__list_in to get R-free information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:43] == "REMARK   3  FIT TO DATA USED IN REFINEMENT." or line[0:42] == "REMARK   3  USING DATA ABOVE SIGMA CUTOFF." :
                get_data = True
                
            elif line[0:46] == "REMARK   3  FIT IN THE HIGHEST RESOLUTION BIN." or line[0:25] == "REMARK   3  NEUTRON DATA." :  # To avoid neutron data and CNS highest resolution shell for R-free
                get_data = False   
             
            elif line[0:47] == "REMARK   3   FREE R VALUE                      ":   # BUSTER/TNT
                # To overcome NULL values for R-free
                get_data =  False
                try:
                    r_free = float(line[48:54])
                except ValueError:
                    r_free = None
            
            elif line[0:46] == "REMARK   3   FREE R VALUE                     " and get_data:   # XPLOR, CNS, CNX, REFMAC, NUCLSQ, BUSTER-TNT, and PHENIX
                # To overcome NULL values for R-free
                try:
                    r_free = float(line[47:53])
                except ValueError:
                    r_free = None
                    
            elif line[0:54] == "REMARK   3   FREE R VALUE                  (F>4SIG(F)) ":   # SHELXL
                # To overcome NULL values for R-free
                try:
                    r_free = float(line[56:62])
                except ValueError:
                    r_free = None
        
        return r_free
   
    def read_error_rfree(self):
        """Method to read crystallographic estimated error on R-free from a PDB"""
        error_r_free = None
        get_data = False
        # Looping through self.__list_in to get R-free information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:43] == "REMARK   3  FIT TO DATA USED IN REFINEMENT." or line[0:42] == "REMARK   3  USING DATA ABOVE SIGMA CUTOFF." :
                get_data = True
                
            elif line[0:46] == "REMARK   3  FIT IN THE HIGHEST RESOLUTION BIN." or line[0:25] == "REMARK   3  NEUTRON DATA." :  # To avoid neutron data and CNS highest resolution shell for R-free
                get_data = False   
        
    
            elif line[0:53] == "REMARK   3   ESTIMATED ERROR OF FREE R VALUE         ":   # BUSTER/TNT
                # To overcome NULL values for R-free
                get_data =  False
                try:
                    error_r_free = float(line[54:60])
                except ValueError:
                    error_r_free = None             
 
            elif line[0:47] == "REMARK   3   ESTIMATED ERROR OF FREE R VALUE   " and get_data:   # BUSTER/TNT shorter
                # To overcome NULL values for R-free
                get_data =  False
                try:
                    error_r_free = float(line[48:54])
                except ValueError:
                    error_r_free = None
            
            elif line[0:46] == "REMARK   3   ESTIMATED ERROR OF FREE R VALUE  " and get_data:   # XPLOR, CNS, CNX, REFMAC, NUCLSQ, BUSTER-TNT, and PHENIX
                # To overcome NULL values for R-free
                try:
                    error_r_free = float(line[47:53])
                except ValueError:
                    error_r_free = None
                    
            elif line[0:54] == "REMARK   3   FREE R VALUE                  (F>4SIG(F)) ":   # SHELXL
                # To overcome NULL values for R-free
                try:
                    error_r_free = float(line[56:62])
                except ValueError:
                    error_r_free = None
        
        return error_r_free
       
   
    def read_low_resol(self):
        """Method to read number of low resolution range from a PDB"""
        resol_low = None
        # Looping through self.__list_in to get low-resolution information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:33] == "REMARK   3   RESOLUTION RANGE LOW" :
                # To overcome NULL values for resol_low reflections
                try:
                    resol_low = float(line[48:54])
                except ValueError:
                    resol_low = None
                
        return resol_low

    def read_min_fobs_sigma(self):
        """Method to read number of min(Fobs/sigma) from a PDB"""
        min_fobs_sigma = None
        # Looping through self.__list_in to get minimum Fobs/sigma information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:33] == "REMARK   3   MIN(FOBS/SIGMA_FOBS)" :
                # To overcome NULL values for min_fobs_sigma
                try:
                    min_fobs_sigma = float(line[48:53])
                except ValueError:
                    min_fobs_sigma = None
      
        return min_fobs_sigma
        
      
    def read_completeness(self):
        """Method to read completeness from a PDB"""
        completeness = None
        # Looping through self.__list_in to get completeness information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:35] == "REMARK   3   COMPLETENESS FOR RANGE" :
                # To overcome NULL values for completeness
                try:
                    completeness = float(line[48:54])
                except ValueError:
                    completeness = None
                
        return completeness

    def read_number_of_reflections(self):
        """Method to read number_reflections from a PDB"""
        number_reflections = None
        # Looping through self.__list_in to get the number of reflections
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:34] == "REMARK   3   NUMBER OF REFLECTIONS" :
                # To overcome NULL values for number_reflections
                try:
                    number_reflections = float(line[48:54])
                except ValueError:
                    number_reflections = None
                
        return number_reflections
    
    def read_b_value_Wilson_plot(self):
        """Method to read B-value from Wilson plot from a PDB file"""
        my_b_value_Wilson = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:47] == "REMARK   3   FROM WILSON PLOT           (A**2) ":          # XPLOR, CNS, CNX, REFMAC, NUCLSQ, BUSTER-TNT, and PHENIX
                # To overcome NULL values 
                try:
                    my_b_value_Wilson = float(line[48:54])
                except ValueError:
                    my_b_value_Wilson = None
     
        return my_b_value_Wilson
    
    def read_esd_Luzzati_plot(self):
        """Method to read ESD from Luzzati plot from a PDB file"""
        my_esd_Luzzati = None
        # Looping through self.__list_in to get value for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:46] == "REMARK   3   ESD FROM LUZZATI PLOT        (A) ":          # XPLOR, CNS, CNX, NUCLSQ, and BUSTER-TNT
                # To overcome NULL values 
                try:
                    my_esd_Luzzati = float(line[47:52])
                except ValueError:
                    my_esd_Luzzati = None
     
        return my_esd_Luzzati

    def read_esd_sigmaa_plot(self):
        """Method to read ESD from sigmaa plot from a PDB file"""
        my_esd_sigma = None
        # Looping through self.__list_in to get value for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:46] == "REMARK   3   ESD FROM SIGMAA              (A) ":          # XPLOR, CNS, CNX, and NUCLSQ
                # To overcome NULL values 
                try:
                    my_esd_sigma = float(line[47:52])
                except ValueError:
                    my_esd_sigma = None
     
        return my_esd_sigma
        
    def read_cv_esd_Luzzati_plot(self):
        """Method to read cross-validated ESD from Luzzati plot from a PDB file"""
        my_cv_esd_Luzzati = None
        # Looping through self.__list_in to get value for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:46] == "REMARK   3   ESD FROM C-V LUZZATI PLOT    (A) ":          # XPLOR, CNS, and CNX
                # To overcome NULL values 
                try:
                    my_cv_esd_Luzzati = float(line[47:52])
                except ValueError:
                    my_cv_esd_Luzzati = None
     
        return my_cv_esd_Luzzati
   
    def read_cv_esd_sigmaa_plot(self):
        """Method to read cross-validated ESD from sigmaa from a PDB file"""
        my_cv_esd_sigmaa = None
        # Looping through self.__list_in to get value for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:46] == "REMARK   3   ESD FROM C-V SIGMAA          (A) ":          # XPLOR, CNS, and CNX
                # To overcome NULL values 
                try:
                    my_cv_esd_sigmaa = float(line[47:52])
                except ValueError:
                    my_cv_esd_sigmaa = None
     
        return my_cv_esd_sigmaa
    
    def read_esu_based_r_value(self):
        """Method to read ESU based on R-value from a PDB file"""
        my_esu_based_r_value = None
        # Looping through self.__list_in to get value for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:64] == "REMARK   3   ESU BASED ON R VALUE                            (A)":          # REFMAC
                # To overcome NULL values 
                try:
                    my_esu_based_r_value = float(line[65:71])
                except ValueError:
                    my_esu_based_r_value = None
     
        return my_esu_based_r_value
  
    def read_esu_based_r_free(self):
        """Method to read ESU based on free R-value from a PDB file"""
        my_esu_based_r_free = None
        # Looping through self.__list_in to get value for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:64] == "REMARK   3   ESU BASED ON FREE R VALUE                       (A)":          # REFMAC
                # To overcome NULL values 
                try:
                    my_esu_based_r_free = float(line[65:71])
                except ValueError:
                    my_esu_based_r_free = None
     
        return my_esu_based_r_free
 
    def read_esu_based_max_like(self):
        """Method to read ESU based on maximum likelihood from a PDB file"""
        my_esu_based_max_like = None
        # Looping through self.__list_in to get value for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:64] == "REMARK   3   ESU BASED ON MAXIMUM LIKELIHOOD                 (A)":          # REFMAC
                # To overcome NULL values 
                try:
                    my_esu_based_max_like = float(line[65:71])
                except ValueError:
                    my_esu_based_max_like = None
     
        return my_esu_based_max_like
  
    def read_esu_b_based_max_like(self):
        """Method to read ESU for B-values based on maximum likelihood from a PDB file"""
        my_esu_b_value_based_max_like = None
        # Looping through self.__list_in to get value for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:64] == "REMARK   3   ESU FOR B VALUES BASED ON MAXIMUM LIKELIHOOD (A**2)":          # REFMAC
                # To overcome NULL values 
                try:
                    my_esu_b_value_based_max_like = float(line[65:72])
                except ValueError:
                    my_esu_b_value_based_max_like = None
     
        return my_esu_b_value_based_max_like
  
    def read_corr_coef_fo_fc(self):
        """Method to read correlation coefficient for Fo-Fc from a PDB file"""
        my_corr_coef_fo_fc = None
        # Looping through self.__list_in to get value for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:48] == "REMARK   3   CORRELATION COEFFICIENT FO-FC      ":          # REFMAC and BUSTER-TNT
                # To overcome NULL values 
                try:
                    my_corr_coef_fo_fc = float(line[49:54])
                except ValueError:
                    my_corr_coef_fo_fc = None
     
        return my_corr_coef_fo_fc
 
    def read_corr_coef_fo_fc_free(self):
        """Method to read correlation coefficient for Fo-Fc free from a PDB file"""
        my_corr_coef_fo_fc_free = None
        # Looping through self.__list_in to get value for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:48] == "REMARK   3   CORRELATION COEFFICIENT FO-FC FREE ":          # REFMAC and BUSTER-TNT
                # To overcome NULL values 
                try:
                    my_corr_coef_fo_fc_free = float(line[49:54])
                except ValueError:
                    my_corr_coef_fo_fc_free = None
     
        return my_corr_coef_fo_fc_free
 
    def read_bond_length(self):
        """Method to read RMSD for bond lengths from a PDB file"""
        remarks_4_bonds1 = ["REMARK   3   BOND LENGTHS        "]        # For XPLOR, CNS, CNX, BUSTER-TNT, and SHELXL
        remarks_4_bonds2 = ["REMARK   3    BOND LENGTH        "]        # For XPLOR,  PROLSQ, REFMAC
        remarks_4_bonds3 = ["REMARK   3   BOND LENGTHS REFINED"]        # REFMAC
        remarks_4_bonds4 = ["REMARK   3   BOND      "]                  # PHENIX 
        bond_length = None
        # Looping through self.__list_in to get RMSD for bond lengths
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:33] in remarks_4_bonds1:
                # To overcome NULL values for bond lengths
                try:
                    bond_length = float(line[47:53])
                except ValueError:
                    bond_length = None
            
            elif line[0:33] in remarks_4_bonds2:
                # To overcome NULL values for bond lengths
                try:
                    bond_length = float(line[51:58])
                except ValueError:
                    bond_length = None
                    
            elif line[0:33] in remarks_4_bonds3:
                # To overcome NULL values for bond lengths
                try:
                    bond_length = float(line[59:66])
                except ValueError:
                    bond_length = None
            
            elif line[0:23] in remarks_4_bonds4:
                # To overcome NULL values for bond lengths
                try:
                    bond_length = float(line[24:31])
                except ValueError:
                    bond_length = None
        
        return bond_length
    
    def read_bond_length_o(self):
        """Method to read bond length others from a PDB file"""
        my_bond_length_o = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   BOND LENGTHS OTHERS               (A)":  # REFMAC
                # To overcome NULL values 
                try:
                    my_bond_length_o = float(line[59:66])
                except ValueError:
                    my_bond_length_o = None
        
        return my_bond_length_o

    def read_bond_angle(self):
        """Method to read RMSD for bond angles from a PDB file"""
        remarks_4_angles1 = ["REMARK   3   BOND ANGLES         "]       # For XPLOR, CNS, CNX, and BUSTER-TNT
        remarks_4_angles2 = ["REMARK   3    ANGLE DISTANCE     "]       # For XPLOR,  PROLSQ
        remarks_4_angles3 = ["REMARK   3   BOND ANGLES REFINED "]       # REFMAC
        remarks_4_angles4 = ["REMARK   3   ANGLE     "]                 # PHENIX
        bond_angle = None
        # Looping through self.__list_in to get RMSD for bond angles
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:33] in remarks_4_angles1:
                # To overcome NULL values for bond angles
                try:
                    bond_angle = float(line[47:53])
                except ValueError:
                    bond_angle = None
            
            elif line[0:33] in remarks_4_angles2:
                # To overcome NULL values for bond angles
                try:
                    bond_angle = float(line[51:58])
                except ValueError:
                    bond_angle = None
                    
            elif line[0:33] in remarks_4_angles3:
                # To overcome NULL values for bond angles
                try:
                    bond_angle = float(line[59:66])
                except ValueError:
                    bond_angle = None
                    
            elif line[0:23] in remarks_4_angles4:
                # To overcome NULL values for bond angles
                try:
                    bond_angle = float(line[24:31])
                except ValueError:
                    bond_angle = None
        
        return bond_angle
  
    def read_bond_angle_o(self):
        """Method to read bond angle others from a PDB file"""
        my_bond_angle_o = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   BOND ANGLES OTHERS          (DEGREES)":  # REFMAC
                # To overcome NULL values 
                try:
                    my_bond_angle_o = float(line[59:66])
                except ValueError:
                    my_bond_angle_o = None
     
        return my_bond_angle_o
        
    def read_angle_distance(self):
        """Method to read angle distances (SHELXL) from a PDB file"""
        my_angle_distance = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:54] == "REMARK   3   ANGLE DISTANCES                      (A) ": # SHELXL
                # To overcome NULL values 
                try:
                    my_angle_distance = float(line[55:61])
                except ValueError:
                    my_angle_distance = None
     
        return my_angle_distance

    def read_restraint_plane(self):
        """Method to read distances from restraint planes (SHELXL) from a PDB file"""
        my_restraint_plane = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:54] == "REMARK   3   DISTANCES FROM RESTRAINT PLANES      (A) ": # SHELXL
                # To overcome NULL values 
                try:
                    my_restraint_plane = float(line[55:61])
                except ValueError:
                    my_restraint_plane = None
     
        return my_restraint_plane

    def read_zero_chiral_volume(self):
        """Method to read zero chiral volumes (SHELXL) from a PDB file"""
        my_zero_chiral_volume = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:54] == "REMARK   3   ZERO CHIRAL VOLUMES               (A**3) ": # SHELXL
                # To overcome NULL values 
                try:
                    my_zero_chiral_volume = float(line[55:61])
                except ValueError:
                    my_zero_chiral_volume = None
     
        return my_zero_chiral_volume

    def read_non_zero_chiral_volume(self):
        """Method to read non-zero chiral volumes (SHELXL) from a PDB file"""
        my_non_zero_chiral_volume = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:54] == "REMARK   3   NON-ZERO CHIRAL VOLUMES           (A**3) ": # SHELXL
                # To overcome NULL values 
                try:
                    my_non_zero_chiral_volume = float(line[55:61])
                except ValueError:
                    my_non_zero_chiral_volume = None
     
        return my_non_zero_chiral_volume

    def read_anti_bumping(self):
        """Method to read anti-bumping distance restraints (SHELXL) from a PDB file"""
        my_anti_bumping = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:54] == "REMARK   3   ANTI-BUMPING DISTANCE RESTRAINTS     (A) ": # SHELXL
                # To overcome NULL values 
                try:
                    my_anti_bumping = float(line[55:61])
                except ValueError:
                    my_anti_bumping = None
     
        return my_anti_bumping
        
    def read_torsion1(self):
        """Method to read torsion angle period 1 from a PDB file"""
        torsion1 = None
        # Looping through self.__list_in to get RMSD for torsion period 1
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:37] == "REMARK   3   TORSION ANGLES, PERIOD 1":   # REFMAC
                # To overcome NULL values for torsion period 1
                try:
                    torsion1 = float(line[59:66])
                except ValueError:
                    torsion1 = None
        
        return torsion1 
    
    def read_torsion2(self):
        """Method to read torsion angle period 2 from a PDB file"""
        torsion2 = None
        # Looping through self.__list_in to get RMSD for torsion period 2
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:37] == "REMARK   3   TORSION ANGLES, PERIOD 2":   # REFMAC
                # To overcome NULL values for torsion period 2
                try:
                    torsion2 = float(line[59:66])
                except ValueError:
                    torsion2 = None
                    
        return torsion2
    
    def read_torsion3(self):
        """Method to read torsion angle period 3 from a PDB file"""
        torsion3 = None
        # Looping through self.__list_in to get RMSD for torsion period 3
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:37] == "REMARK   3   TORSION ANGLES, PERIOD 3":   # REFMAC
                # To overcome NULL values for torsion period 3
                try:
                    torsion3 = float(line[59:66])
                except ValueError:
                    torsion3 = None
        
        return torsion3

    def read_torsion4(self):
        """Method to read torsion angle period 4 from a PDB file"""
        torsion4 = None
        # Looping through self.__list_in to get RMSD for torsion period 4
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:37] == "REMARK   3   TORSION ANGLES, PERIOD 4":   # REFMAC
                # To overcome NULL values for torsion period 4
                try:
                    torsion4 = float(line[59:66])
                except ValueError:
                    torsion4 = None
        
        return torsion4
 
    def read_torsion_angle_buster_tnt(self):
        """Method to read torsion angles Buster-TNT from a PDB file"""
        my_torsion_angle_buster_tnt = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:46] == "REMARK   3   TORSION ANGLES         (DEGREES) ": # BUSTER-TNT 
                # To overcome NULL values 
                try:
                    my_torsion_angle_buster_tnt = float(line[47:52])
                except ValueError:
                    my_torsion_angle_buster_tnt = None
     
        return my_torsion_angle_buster_tnt
 
    def read_trigonal_carbon_planes_buster_tnt(self):
        """Method to read trigonal carbon planes Buster-TNT from a PDB file"""
        my_trigonal_carbon_planes_buster_tnt = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:46] == "REMARK   3   TRIGONAL CARBON PLANES       (A) ": # BUSTER-TNT 
                # To overcome NULL values 
                try:
                    my_trigonal_carbon_planes_buster_tnt = float(line[47:52])
                except ValueError:
                    my_trigonal_carbon_planes_buster_tnt = None
     
        return my_trigonal_carbon_planes_buster_tnt
 
    def read_general_planes_buster_tnt(self):
        """Method to read general planes Buster-TNT from a PDB file"""
        my_general_planes_buster_tnt = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:46] == "REMARK   3   GENERAL PLANES               (A) ": # BUSTER-TNT 
                # To overcome NULL values 
                try:
                    my_general_planes_buster_tnt = float(line[47:52])
                except ValueError:
                    my_general_planes_buster_tnt = None
     
        return my_general_planes_buster_tnt
   
    def read_isotropic_thermal_factor_buster_tnt(self):
        """Method to read isotropic thermal factors Buster-TNT from a PDB file"""
        my_isotropic_thermal_factor_buster_tnt = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:46] == "REMARK   3   ISOTROPIC THERMAL FACTORS (A**2) ": # BUSTER-TNT 
                # To overcome NULL values 
                try:
                    my_isotropic_thermal_factor_buster_tnt = float(line[47:52])
                except ValueError:
                    my_isotropic_thermal_factor_buster_tnt = None
     
        return my_isotropic_thermal_factor_buster_tnt
   
    def read_non_bonded_contacts_buster_tnt(self):
        """Method to read non-bonded contacts Buster-TNT from a PDB file"""
        my_non_bonded_contacts_buster_tnt = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:46] == "REMARK   3   NON-BONDED CONTACTS          (A) ": # BUSTER-TNT 
                # To overcome NULL values 
                try:
                    my_non_bonded_contacts_buster_tnt = float(line[47:52])
                except ValueError:
                    my_non_bonded_contacts_buster_tnt = None
     
        return my_non_bonded_contacts_buster_tnt
 
    def read_omega_peptide_buster_tnt(self):
        """Method to read RMSD for omega peptide torsion angle (Buster-TNT) from a PDB file"""
        my_omega_peptide_buster_tnt = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:53] == "REMARK   3    PEPTIDE OMEGA TORSION ANGLES (DEGREES) ": # BUSTER-TNT 
                # To overcome NULL values 
                try:
                    my_omega_peptide_buster_tnt = float(line[54:63])
                except ValueError:
                    my_omega_peptide_buster_tnt = None
     
        return my_omega_peptide_buster_tnt
    
    def read_coordinate_error_phenix(self):
        """Method to read coordinate error (PHENIX) from a PDB file"""
        my_coordinate_error_phenix = None
        # Looping through self.__list_in to get parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:61] == "REMARK   3   COORDINATE ERROR (MAXIMUM-LIKELIHOOD BASED)     ": # PHENIX 
                # To overcome NULL values 
                try:
                    my_coordinate_error_phenix = float(line[62:68])
                except ValueError:
                    my_coordinate_error_phenix = None
     
        return my_coordinate_error_phenix
    
    def read_phase_error_phenix(self):
        """Method to read phase error (PHENIX) from a PDB file"""
        my_phase_error_phenix = None
        # Looping through self.__list_in to get parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:61] == "REMARK   3   PHASE ERROR (DEGREES, MAXIMUM-LIKELIHOOD BASED) ": # PHENIX 
                # To overcome NULL values 
                try:
                    my_phase_error_phenix = float(line[62:68])
                except ValueError:
                    my_phase_error_phenix = None
     
        return my_phase_error_phenix
 
    def read_chirality_phenix(self):
        """Method to read RMSD for chirality (PHENIX) from a PDB file"""
        my_chirality_phenix = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:23] == "REMARK   3   CHIRALITY ": # PHENIX 
                # To overcome NULL values 
                try:
                    my_chirality_phenix = float(line[24:31])
                except ValueError:
                    my_chirality_phenix = None
     
        return my_chirality_phenix
   
    def read_planarity_phenix(self):
        """Method to read RMSD for planarity (PHENIX) from a PDB file"""
        my_planarity_phenix = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:23] == "REMARK   3   PLANARITY ": # PHENIX 
                # To overcome NULL values 
                try:
                    my_planarity_phenix = float(line[24:31])
                except ValueError:
                    my_planarity_phenix = None
     
        return my_planarity_phenix
 
    def read_dihedral_phenix(self):
        """Method to read RMSD for dihedral (PHENIX) from a PDB file"""
        my_dihedral_phenix = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:23] == "REMARK   3   DIHEDRAL  ": # PHENIX 
                # To overcome NULL values 
                try:
                    my_dihedral_phenix = float(line[24:31])
                except ValueError:
                    my_dihedral_phenix = None
     
        return my_dihedral_phenix
           
    def read_chiral_center_restraint(self):
        """Method to read chiral center restraints from a PDB file"""
        my_chiral_center_restraint = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   CHIRAL-CENTER RESTRAINTS       (A**3)":  # REFMAC
                # To overcome NULL values 
                try:
                    my_chiral_center_restraint = float(line[59:66])
                except ValueError:
                    my_chiral_center_restraint = None
     
        return my_chiral_center_restraint

    def read_general_planes(self):
        """Method to read general planes from a PDB file"""
        my_general_planes = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   GENERAL PLANES REFINED ATOMS      (A)":
                # To overcome NULL values 
                try:
                    my_general_planes = float(line[59:66])
                except ValueError:
                    my_general_planes = None
     
        return my_general_planes

    def read_general_planes_o(self):
        """Method to read general planes others from a PDB file"""
        my_general_planes_o = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   GENERAL PLANES OTHERS             (A)":
                # To overcome NULL values 
                try:
                    my_general_planes_o = float(line[59:66])
                except ValueError:
                    my_general_planes_o = None
     
        return my_general_planes_o
  
    def read_non_bonded_contacts(self):
        """Method to read non-bonded contacts from a PDB file"""
        my_non_bonded_contacts = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   NON-BONDED CONTACTS REFINED ATOMS (A)":
                # To overcome NULL values 
                try:
                    my_non_bonded_contacts = float(line[59:66])
                except ValueError:
                    my_non_bonded_contacts = None
     
        return my_non_bonded_contacts

    def read_non_bonded_contacts_o(self):
        """Method to read non-bonded contacts others from a PDB file"""
        my_non_bonded_contacts_o = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   NON-BONDED CONTACTS OTHERS        (A)":
                # To overcome NULL values 
                try:
                    my_non_bonded_contacts_o = float(line[59:66])
                except ValueError:
                    my_non_bonded_contacts_o = None
     
        return my_non_bonded_contacts_o
  
    def read_non_bonded_torsion(self):
        """Method to read non-bonded torsions from a PDB file"""
        my_non_bonded_torsion = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   NON-BONDED TORSION REFINED ATOMS  (A)":
                # To overcome NULL values 
                try:
                    my_non_bonded_torsion = float(line[59:66])
                except ValueError:
                    my_non_bonded_torsion = None
     
        return my_non_bonded_torsion

    def read_non_bonded_torsion_o(self):
        """Method to read non-bonded torsions others from a PDB file"""
        my_non_bonded_torsion_o = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   NON-BONDED TORSION OTHERS         (A)":
                # To overcome NULL values 
                try:
                    my_non_bonded_torsion_o = float(line[59:66])
                except ValueError:
                    my_non_bonded_torsion_o = None
     
        return my_non_bonded_torsion_o
  
    def read_h_bond(self):
        """Method to read H bonds from a PDB file"""
        my_h_bond = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   H-BOND (X...Y) REFINED ATOMS      (A)":
                # To overcome NULL values 
                try:
                    my_h_bond = float(line[59:66])
                except ValueError:
                    my_h_bond = None
     
        return my_h_bond

    def read_h_bond_o(self):
        """Method to read H bonds others from a PDB file"""
        my_h_bond_o = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   H-BOND (X...Y) OTHERS             (A)":
                # To overcome NULL values 
                try:
                    my_h_bond_o = float(line[59:66])
                except ValueError:
                    my_h_bond_o = None
     
        return my_h_bond_o

    def read_potential_metal_ion(self):
        """Method to read potential metal ion from a PDB file"""
        my_potential_metal_ion = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   POTENTIAL METAL-ION REFINED ATOMS (A)":
                # To overcome NULL values 
                try:
                    my_potential_metal_ion = float(line[59:66])
                except ValueError:
                    my_potential_metal_ion = None
     
        return my_potential_metal_ion
  
    def read_symmetry_vdw(self):
        """Method to read symmetry VDW from a PDB file"""
        my_symmetry_vdw = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   SYMMETRY VDW REFINED ATOMS        (A)":
                # To overcome NULL values 
                try:
                    my_symmetry_vdw = float(line[59:66])
                except ValueError:
                    my_symmetry_vdw = None
     
        return my_symmetry_vdw

    def read_symmetry_vdw_o(self):
        """Method to read symmetry VDW others from a PDB file"""
        my_symmetry_vdw_o = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   SYMMETRY VDW OTHERS               (A)":
                # To overcome NULL values 
                try:
                    my_symmetry_vdw_o = float(line[59:66])
                except ValueError:
                    my_symmetry_vdw_o = None
     
        return my_symmetry_vdw_o
  
    def read_symmetry_h_bond(self):
        """Method to read symmetry H bond from a PDB file"""
        my_symmetry_h_bond = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   SYMMETRY H-BOND REFINED ATOMS     (A)":
                # To overcome NULL values 
                try:
                    my_symmetry_h_bond = float(line[59:66])
                except ValueError:
                    my_symmetry_h_bond = None
     
        return my_symmetry_h_bond

    def read_symmetry_metal_ion(self):
        """Method to read symmetry metal ion from a PDB file"""
        my_symmetry_metal_ion = None
        # Looping through self.__list_in to get RMSD for parameter 
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:50] == "REMARK   3   SYMMETRY METAL-ION REFINED ATOMS  (A)":
                # To overcome NULL values 
                try:
                    my_symmetry_metal_ion = float(line[59:66])
                except ValueError:
                    my_symmetry_metal_ion = None
     
        return my_symmetry_metal_ion

    def read_xtal_temperature(self):
        """Method to read temperature from a PDB"""
        xtal_temp = None
        # Looping through self.__list_in to get temperature information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:43] == "REMARK 200  TEMPERATURE           (KELVIN) ":
                # To overcome NULL values for R-merge
                try:
                    xtal_temp = float(line[44:52])
                except ValueError:
                    xtal_temp = None
        
        return xtal_temp    

    def read_xray_wavelength(self):
        """Method to read xray wavelength from a PDB"""
        xray_wavelength = None
        # Looping through self.__list_in to get information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:43] == "REMARK 200  WAVELENGTH OR RANGE        (A) ":
                # To overcome NULL values for R-merge
                try:
                    xray_wavelength = float(line[44:52])
                except ValueError:
                    xray_wavelength = None
        
        return xray_wavelength    

    def read_unique(self):
        """Method to read number of unique reflections from a PDB"""
        unique = None
        # Looping through self.__list_in to get the number of unique reflections
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:40] == "REMARK 200  NUMBER OF UNIQUE REFLECTIONS" :
                # To overcome NULL values for unique reflections
                try:
                    unique = float(line[44:50])
                except ValueError:
                    unique = None
                
        return unique

    def read_resolution_range_low(self):
        """Method to read resolution range low from a PDB"""
        resolution_range_low = None
        # Looping through self.__list_in to get information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:43] == "REMARK 200  RESOLUTION RANGE LOW       (A) ":
                # To overcome NULL values for R-merge
                try:
                    resolution_range_low = float(line[44:52])
                except ValueError:
                    resolution_range_low = None
        
        return resolution_range_low    

    def read_rejection_criteria_sigma_i(self):
        """Method to read rejection criteria sigma(I) from a PDB"""
        rejection_criteria_sigma_i = None
        # Looping through self.__list_in to get information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:43] == "REMARK 200  REJECTION CRITERIA  (SIGMA(I)) ":
                # To overcome NULL values for R-merge
                try:
                    rejection_criteria_sigma_i = float(line[44:52])
                except ValueError:
                    rejection_criteria_sigma_i = None
        
        return rejection_criteria_sigma_i    

    def read_completeness_for_range_data(self):                           
        """Method to read completeness for range (data) from a PDB"""
        completeness_for_range_data = None
        # Looping through self.__list_in to get information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:43] == "REMARK 200  COMPLETENESS FOR RANGE     (%) ":
                # To overcome NULL values for R-merge
                try:
                    completeness_for_range_data = float(line[44:52])
                except ValueError:
                    completeness_for_range_data = None
        
        return completeness_for_range_data 
   
    def read_i_sigma_i_data_set(self):                           
        """Method to read I/sigma(I) for data set from a PDB"""
        i_sigma_i_data_set = None
        # Looping through self.__list_in to get information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:43] == "REMARK 200  <I/SIGMA(I)> FOR THE DATA SET  ":
                # To overcome NULL values 
                try:
                    i_sigma_i_data_set = float(line[44:52])
                except ValueError:
                    i_sigma_i_data_set = None
        
        return i_sigma_i_data_set 
   
    def read_highest_resolution_shell_data_set(self):                           
        """Method to read highest resolution shell for data set from a PDB"""
        highest_resolution_shell_data_set = None
        # Looping through self.__list_in to get information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:53] == "REMARK 200  HIGHEST RESOLUTION SHELL, RANGE HIGH (A) ":
                # To overcome NULL values 
                try:
                    highest_resolution_shell_data_set = float(line[54:59])
                except ValueError:
                    highest_resolution_shell_data_set = None

        return highest_resolution_shell_data_set

    def read_highest_resolution_shell_low_data_set(self):                           
        """Method to read highest resolution shell low for data set from a PDB"""
        highest_resolution_shell_low_data_set = None
        # Looping through self.__list_in to get information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:53] == "REMARK 200  HIGHEST RESOLUTION SHELL, RANGE LOW  (A) ":
                # To overcome NULL values 
                try:
                    highest_resolution_shell_low_data_set = float(line[54:59])
                except ValueError:
                    highest_resolution_shell_low_data_set = None
        
        return highest_resolution_shell_low_data_set 

    def read_completeness_for_shell(self):                           
        """Method to read completenss for shell for data set from a PDB"""
        completeness_for_shell = None
        # Looping through self.__list_in to get information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:43] == "REMARK 200  COMPLETENESS FOR SHELL     (%) ":
                # To overcome NULL values 
                try:
                    completeness_for_shell = float(line[44:49])
                except ValueError:
                    completeness_for_shell = None
        
        return completeness_for_shell 

    def read_i_sigma_i_for_shell(self):                           
        """Method to read I/sigma(I) for shell for data set from a PDB"""
        i_sigma_i_for_shell = None
        # Looping through self.__list_in to get information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:43] == "REMARK 200  <I/SIGMA(I)> FOR SHELL         ":
                # To overcome NULL values 
                try:
                    i_sigma_i_for_shell = float(line[44:49])
                except ValueError:
                    i_sigma_i_for_shell = None
        
        return i_sigma_i_for_shell 
  
    def read_solvent_content(self):
        """Method to read solvent content from a PDB file"""
        # Looping through self.__list_in to get the solvent content
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:26] == "REMARK 280 SOLVENT CONTENT":
                # To overcome NULL values for solvent content
                try:
                    solv_cont = float(line[37:43])
                except ValueError:
                    solv_cont = None
        
        return solv_cont 

    def read_matthews_coefficient(self):
        """Method to read Matthews coefficient from a PDB file"""
        # Looping through self.__list_in to get Matthews coefficient
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:26] == "REMARK 280 MATTHEWS COEFFI":
                # To overcome NULL values for Matthews coefficient
                try:
                    matthews_coef = float(line[54:59])
                except ValueError:
                    matthews_coef = None
        
        return matthews_coef 

    def read_missing_res(self):
        """Method to read information about missing residues in the PDB"""
        count_missing_res = 0
        # Looping through self.__list_in to get the number of missing residues
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:10] == "REMARK 465" and line[15:18] in ProteinStructure.aa:
                count_missing_res += 1
        return count_missing_res

    def calculate_unit_cell_vol(self):
        """Method to read read CRYST1 information and calculate the unit cell volume and related information"""
        import math
        param_a = None
        param_b = None
        param_c = None
        p_alpha = None
        p_beta  = None
        p_gamma = None
        type_of_cell = None
        vol_unit_cell = None
        vol_unit_cell_star = None 
        max_num_ref = None
        # Looping through self.__list_in to get resolution information
        for line in self.__list_in:                     # Accessing private attribute
            if line[0:6] == "CRYST1" :
                # To overcome NULL values for resolution
                try:
                    param_a = float(line[7:15])
                    param_b = float(line[16:24])
                    param_c = float(line[25:33])
                    p_alpha = float(line[34:40])
                    p_beta  = float(line[41:47])
                    p_gamma = float(line[48:54])
                    type_of_cell = str(line[55:56])
                    vol_p = 1 - math.cos(p_alpha)**2 - math.cos(p_beta)**2 - math.cos(p_gamma)**2
                    vol_p = vol_p + 2*math.cos(p_alpha)*math.cos(p_beta)*math.cos(p_gamma)
                    vol_unit_cell = param_a*param_b*param_c*math.sqrt(vol_p)
                    if vol_unit_cell != 0:
                        vol_unit_cell_star = 1/vol_unit_cell
                    else:
                        vol_unit_cell_star = None
                    if self.__resol != None:
                        if type_of_cell == "P" or type_of_cell == "R":
                            max_num_ref = ( 32*math.pi/(3*float(self.__resol)**3) )*vol_unit_cell
                        elif type_of_cell == "C" or type_of_cell == "I" :
                            max_num_ref = ( 64*math.pi/(3*self.__resol**3) )*vol_unit_cell
                        elif type_of_cell == "F":
                            max_num_ref = ( 128*math.pi/(3*self.__resol**3) )*vol_unit_cell
                        else:
                            max_num_ref = None
                    else:
                        max_num_ref = None
                        
                except ValueError:
                    param_a = None
                    param_b = None
                    param_c = None
                    p_alpha = None
                    p_beta  = None
                    p_gamma = None
                    type_of_cell = None
                    type_of_cell = None
                    vol_unit_cell = None
                    vol_unit_cell_star = None 
                    max_num_ref = None
                
        return vol_unit_cell,vol_unit_cell_star,max_num_ref
    
    def genBioMat(self,pdb_4_biomat,my_dir_biomat):
        """Method to generate biological assembly from bio-matrix written on REMARK 350"""
        import os, sys
        
        # Sets initial matrix as a list of lists
        rot_matrix = [[0]*3 for i in range(10000)] 

        # Sets initial vector as a list of three elements
        vector = []
    
        # Assigns zero to counter variable
        count_lines = 0
        count_matrix = 0
        
        checkBioMatIn = False
    
        # Looping through to read BIOMAT
        for line in self.__list_in:
            if count_matrix < 99:
                if line[0:40] == "REMARK 350 APPLY THE FOLLOWING TO CHAINS":
                    print(line)
                if line[0:18] == "REMARK 350   BIOMT" and int(line[20:23]) > 1:
                    count_matrix = int(line[20:23])
                    rot_matrix[count_lines][0] = float(line[23:33])
                    rot_matrix[count_lines][1] = float(line[33:43])
                    rot_matrix[count_lines][2] = float(line[43:53])
                    vector.append(float(line[53:68]))
                    count_lines += 1
            elif count_matrix < 999:
                if line[0:40] == "REMARK 350 APPLY THE FOLLOWING TO CHAINS":
                    print(line)
                if line[0:18] == "REMARK 350   BIOMT" and int(line[20:23]) > 1:
                    count_matrix = int(line[20:25])
                    rot_matrix[count_lines][0] = float(line[25:34])
                    rot_matrix[count_lines][1] = float(line[35:44])
                    rot_matrix[count_lines][2] = float(line[45:54])
                    vector.append(float(line[54:69]))
                    count_lines += 1
            elif count_matrix < 9999:
                if line[0:40] == "REMARK 350 APPLY THE FOLLOWING TO CHAINS":
                    print(line)
                if line[0:18] == "REMARK 350   BIOMT" and int(line[20:23]) > 1:
                    count_matrix = int(line[20:25])
                    rot_matrix[count_lines][0] = float(line[25:35])
                    rot_matrix[count_lines][1] = float(line[35:45])
                    rot_matrix[count_lines][2] = float(line[45:55])
                    vector.append(float(line[55:70]))
                    count_lines += 1

        chain_list = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
    
        count_chain_id = 0
        
        # Generates biological assembly if count_matrix > 1
        if count_matrix > 1:
            
            try:
                # Renames old PDB file 
                os.rename(str(my_dir_biomat)+str(pdb_4_biomat)+".pdb", str(my_dir_biomat)+str(pdb_4_biomat)+"_before_biomat.pdb")
            except FileExistsError:
                print("SAnDReS Error! I can't rename "+str(pdb_4_biomat)+".pdb to "+str(pdb_4_biomat)+"_before_biomat.pdb." )
                sys.exit("Finishing SAnDReS execution!")
                
            # Read and opens output file
            pdbFileOut = str(my_dir_biomat)+str(pdb_4_biomat)+".pdb"
            fo_pdbOut = open(pdbFileOut,"w")
            print("\nGenerating biological assembly for ",pdbFileOut)
            checkBioMatIn = True
    
            # Writing original PDB
            for line in self.__list_in:
                if line[0:3] == "END":
                    line = "TER                                                                             \n"
                if line[0:6] == "CONECT" or line[0:6] == "MASTER":
                    continue
                else:
                    fo_pdbOut.write(line)
    
            # First I have to read the PDB file to identify chain Ids and remove them from the chain_list
            for line in self.__list_in:
                if line[0:6] == "ATOM  " or line[0:6] == "HETATM":
                    if line[21:22] in chain_list:
                        chain_list.remove(line[21:22])
                
            # Looping through to calculate new atomic coordinates for biological assembly and write them into the new PDB file
            for k in range(count_matrix-1):
                if count_matrix < 26:
                    chain_id_out = chain_list[k]
                    for line in self.__list_in:
                        if line[0:6] == "ATOM  " or line[0:6] == "HETATM":
                            x = float(line[30:38])*rot_matrix[3*k+0][0] + float(line[38:46])*rot_matrix[3*k+0][1] + float(line[46:54])*rot_matrix[3*k+0][2] + vector[3*k+0]
                            y = float(line[30:38])*rot_matrix[3*k+1][0] + float(line[38:46])*rot_matrix[3*k+1][1] + float(line[46:54])*rot_matrix[3*k+1][2] + vector[3*k+1]
                            z = float(line[30:38])*rot_matrix[3*k+2][0] + float(line[38:46])*rot_matrix[3*k+2][1] + float(line[46:54])*rot_matrix[3*k+2][2] + vector[3*k+2]
                            line_out = line[0:21]+chain_id_out[0:1]+line[22:30]+str( "%8.3f%8.3f%8.3f"%(x,y,z))+line[54:80]+"\n"
                            #newPDB.append(line_out)
                            fo_pdbOut.write(line_out)
                        elif line[0:3] == "TER":
                            line_out = line[0:21]+chain_id_out[0:1]+line[22:30]+"\n"
                            #newPDB.append(line_out)
                            fo_pdbOut.write(line_out)
        
                    line_out = "TER"+line[3:21]+chain_id_out[0:1]+line[22:30]+"\n"   
                    #newPDB.append(line_out)
                    fo_pdbOut.write(line_out)
                else:
                    chain_id_out = str(count_chain_id)
                    count_chain_id += 1
                    try:
                        for line in self.__list_in:
                            if line[0:6] == "ATOM  " or line[0:6] == "HETATM":
                                x = float(line[30:38])*rot_matrix[3*k+0][0] + float(line[38:46])*rot_matrix[3*k+0][1] + float(line[46:54])*rot_matrix[3*k+0][2] + vector[3*k+0]
                                y = float(line[30:38])*rot_matrix[3*k+1][0] + float(line[38:46])*rot_matrix[3*k+1][1] + float(line[46:54])*rot_matrix[3*k+1][2] + vector[3*k+1]
                                z = float(line[30:38])*rot_matrix[3*k+2][0] + float(line[38:46])*rot_matrix[3*k+2][1] + float(line[46:54])*rot_matrix[3*k+2][2] + vector[3*k+2]
                                line_out = line[0:21]+chain_id_out[0:1]+line[22:30]+str( "%8.3f%8.3f%8.3f"%(x,y,z))+line[54:80]+"\n"
                                #newPDB.append(line_out)
                                fo_pdbOut.write(line_out)
                            elif line[0:3] == "TER":
                                line_out = line[0:21]+chain_id_out[0:1]+line[22:30]+"\n"
                                #newPDB.append(line_out)
                                fo_pdbOut.write(line_out)
        
                        line_out = "TER"+line[3:21]+chain_id_out[0:1]+line[22:30]+"\n"   
                        #newPDB.append(line_out)
                        fo_pdbOut.write(line_out)
                    except MemoryError:
                        print("Memory Error")
                        print("It has been created ",count_chain_id," chains.")
        
        
            # Close file
            fo_pdbOut.close()
        return checkBioMatIn
    
# Class for Spearman's correlation coefficient
class Spearman(object):
    """Calculates the correlation coefficient between two lists"""
    def __init__(self,list1,list2):
        self.list1 = list1
        self.list2 = list2
        
    def correlation_coefficient(self):
        """Calculates correlation coefficient between two lists"""
        #import scipy 
        from scipy.stats import spearmanr
        from scipy.stats import pearsonr
        import numpy as np 
        len1 = len(self.list1)  # For re-docking this is for RMSD values
        len2 = len(self.list2)  # For re-docking this is for scoring function values
        
        # Get minimum for scoring function
        my_min = np.min(self.list2)
        
        # get index for minimum in list2 
        my_index_4_rmsd = self.list2.index(my_min)
        
        # Get RMSD for minimum scoring function values
        my_minimum_rmsd = self.list1[my_index_4_rmsd]
                
        # Checks whether both lists have the same length
        if len1 != len2 :
            print("\nError! Number of elements in list1 != number of elements in list2!")
            return None
        else:
            std_deviation2 = np.std(self.list2)
            
            if std_deviation2 != 0:  # Avoids error message for lists where all elements are the same (standard deviation = 0)
                corr,pvalue = spearmanr(self.list1,self.list2)
                self.corr = corr
                self.pvalue = pvalue
                try:
                    pearson_cc,pearson_p = pearsonr(self.list1,self.list2)
                    my_mean = np.mean(self.list2)       # For scoring function values
                    # my_median = np.median(self.list2)   # For scoring function values
                except:
                    pearson_cc = 10.0
                    pearson_p = None
                    my_mean = None
                    # my_median = None
            else:
                self.corr = 10.0
                self.pvalue = None
                pearson_cc = 10.0
                pearson_p = None
                my_mean = None
                # my_median = None
    
            return my_minimum_rmsd,self.corr,self.pvalue,std_deviation2,pearson_cc,pearson_p,my_mean
        
    def correlation_coefficient2(self):
        """Calculates Spearman's rank correlation coeffcient between two lists"""
        #import scipy 
        from scipy.stats import spearmanr
        from scipy.stats import pearsonr
        import numpy as np 
        len1 = len(self.list1)
        len2 = len(self.list2)
        
        # Checks whether both lists have the same length
        if len1 != len2 :
            print("\nError! Number of elements in list1 != number of elements in list2!")
            return None
        else:
            try:
                std_deviation = np.std(self.list2)
            except:
                std_deviation = 0
            
            if std_deviation != 0:  # Avoids error message for lists where all elements are the same (standard deviation = 0)
                try:
                    corr,pvalue = spearmanr(self.list1,self.list2)
                    self.corr = corr
                    self.pvalue = pvalue
                    try:
                        pearson_cc,pearson_p = pearsonr(self.list1,self.list2)
                    except:
                        pearson_cc = 10.0
                        pearson_p = None
                except:
                    self.corr = 10.0
                    self.pvalue = None
                    pearson_cc = 10.0
                    pearson_p = None
            else:
                self.corr = 10.0
                self.pvalue = None
                pearson_cc = 10.0
                pearson_p = None
    
            return self.corr,self.pvalue,pearson_cc,pearson_p
    
    def calculateStats4List(self,my_pdb_list_in,my_list_in):
        """Calculates mean, median, standard deviation, maximum and minimum values for a list"""
        import numpy as np 
        self.my_pdb_list_in = my_pdb_list_in
        self.my_list_in = my_list_in
        mean_value = np.mean(self.my_list_in)
        median_value =  np.median(self.my_list_in)
        std = np.std(self.my_list_in)
        min_value = np.min(self.my_list_in)
        max_value = np.max(self.my_list_in)
        for line in self.my_list_in:
            if float(line) == float(min_value):
                min_pdb_out_index = self.my_list_in.index(line)
                min_pdb_out = self.my_pdb_list_in[min_pdb_out_index]
            if float(line) == float(max_value):
                max_pdb_out_index = self.my_list_in.index(line)
                max_pdb_out = self.my_pdb_list_in[max_pdb_out_index]

        return median_value,mean_value,std,min_value,min_pdb_out,max_value,max_pdb_out
                
    def make_csv_file(self,number_of_columns,csv_file,csv_list1,csv_list2):
            self.number_of_columns = number_of_columns
            self.csv_file = csv_file
            self.csv_list1 = csv_list1
            self.csv_list2 = csv_list2
            new_csv_file = open(self.csv_file,"w")
            if self.number_of_columns == 1:
                for i in range(len(self.csv_list1)):
                    line_out = str(csv_list2[i])+"\n"
                    new_csv_file.write(line_out) 
            elif self.number_of_columns == 2:
                for i in range(len(self.csv_list1)):
                    line_out = str(self.csv_list1[i])+","+str(csv_list2[i])+"\n"
                    new_csv_file.write(line_out) 
            else:
                print("\nError! Undefined number of columns for output csv file.")
            new_csv_file.close()

# Class for statistical analysis and plots
class StatAnalysis(object):
    """Generates histogram and scatter plots"""
    
    def __init__(self,list1,list2):
        self.list1 = list1
        self.list2 = list2
        
    def correlation_coefficient(self):
        """Calculates Spearman's rank correlation coefficient using Scipy"""
        import scipy
        from scipy.stats import spearmanr
        
        # Tests if the length of both lists are equal, and it is so calculates correlation coefficient
        len1 = len(self.list1)
        len2 = len(self.list2)
        if len1 == len2 :
            corr,pvalue = spearmanr(self.list1,self.list2)
            self.corr = corr
            self.pvalue = pvalue
            return self.corr,self.pvalue
        else:
            print("\nError! Number of elements in list1 != number of elements in list2!")
            return None, None
               
    def scatter_plot(self,x_axis,y_axis,plot_title,x_min,x_max,y_min,y_max,size_markers,point_color,marker_value,plt_format,grid_boolean_var,dpi_value,project_dir_in,poly_deg_in,root_input_csv_file_in,type_of_plot_in,flag_text,fig_x_in,fig_y_in,cc1_in,pvalue1_in):
        """Method for 2-D Plot two lists"""
        import time 
        import numpy as np
        import matplotlib.pyplot as plt
        
        self.type_of_plot_in = type_of_plot_in        
        self.x_axis = x_axis
        self.y_axis = y_axis
        self.plot_title = plot_title
        self.x_min = float(x_min)
        self.x_max = float(x_max)
        self.y_min = float(y_min)
        self.y_max = float(y_max) 
        self.size_markers = int(size_markers)
        self.point_color = str(point_color.replace(" ","")) 
        self.marker_value = str(marker_value[0:1])
        self.plt_format = str(plt_format.replace(" ","").lower())
        self.trans = False
        self.dpi_value = int(dpi_value)
        self.poly_deg_in =  int(poly_deg_in)
    
        self.cc1_in = str("%5.3f"%cc1_in)
        
        self.grid_boolean_var = grid_boolean_var
        
        # No transparency in the plot
        trans = False
        
        # Checks if cc1_in is not a number
        if "nan" in self.cc1_in:
            print("Not plotting this one...")
            return          # Returns without plot
         
        self.pvalue1_in = str("%5.3f"%pvalue1_in)
        # Checks if pvalue1_in is not a number
        if "nan" in self.pvalue1_in:
            print("Not plotting this one...")
            return          # Returns without plot
        
        self.flag_text = str(flag_text)
        
        self.fig_x_in = fig_x_in
        self.fig_y_in = fig_y_in 
        
        
        # Program to plot multiple scatter plots.
        # We included the grid option, axis limits, labels, title and legends with specified location.
        # We used marker to specify the type of marker to be used in the scatter plot
        # We used color and size to specify the color and size for the markers
        # We saved the resulting plot as a file with transparent background.
        # This method can't be called before correlation_coefficient method
            
        plt.grid(self.grid_boolean_var)                                                                              # Includes grid lines
        plt.xlim(self.x_min,self.x_max)                                                             # Sets the limits for  x axis, xmin,xmax
        plt.ylim(self.y_min,self.y_max)                                                             # Sets the limits for  y axis, ymin,ymax
        plt.xlabel(self.x_axis)                                                                     # Label for x-axis
        plt.ylabel(self.y_axis)                                                                     # Label for y-axis
        plt.title(self.plot_title)  
        
        if self.pvalue1_in == "0.000":
            p_value_string1 = "p-value < 0.001"
        else:
            p_value_string1 = "p-value = "+self.pvalue1_in
            
        # Takes care of TEXT request
        if self.flag_text.upper() == "TEXT":                                                                # Adds title
            plt.figtext(self.fig_x_in,self.fig_y_in,"rho = "+self.cc1_in+"\n"+p_value_string1 )  
        
        if self.poly_deg_in > 0 and self.type_of_plot_in.upper() == "SCATTER":
            #Least-squares polynomial fitting 
            print("Least-squares polynomial fitting  has been requested!")
            z = np.polyfit(self.list1,self.list2, self.poly_deg_in)
            p = np.poly1d(z)
            xp = np.linspace(self.x_min,self.x_max, 100)
            #plt.plot(self.list1,self.list2, '.', xp, p(xp), '-')
            plt.plot(xp, p(xp), '-',color='black')
            
        if self.type_of_plot_in.upper() == "SCATTER":
            plt.scatter(self.list1,self.list2, s=self.size_markers, \
                        c = self.point_color, marker = self.marker_value)                           # Scatter plot with specified size (s), color (c), maker and label        
            
        #plt.text(0.05*self.x_max,0.9*self.y_max,"Spearman's rank correlation coef.(p-value) = %6.3f (%6.3f)"%(self.corr,self.pvalue) )
        elif self.type_of_plot_in.upper() == "PLOT":
            plt.plot(self.list1,self.list2, c = self.point_color)
            p = 0 
        elif self.type_of_plot_in.upper() == "PLOTPDB":
            x_axis_list1 = []
            i_x = 0
            for line in self.list2:
                x_axis_list1.append(i_x)
                i_x += 1
            #plt.plot(self.list1,self.list2, c = self.point_color)
            plt.plot(self.list1,self.list2, c = self.point_color)
            p = 0 
        elif self.type_of_plot_in.upper() == "PLOTMIN":
            # Finds minimum values for y-axis
            min1 = np.min(self.list2) 
            
            # Looping through self.list2 to find the index for minimum value in y-axis
            my_index_min1 = 0
            for line_min1 in self.list2:
                if line_min1 == min1:
                    my_best_model_number = self.list1[my_index_min1]
                my_index_min1 += 1
            
            if self.y_min < 0:
                # Shows arrow where the minimum is
                plt.annotate('Minimum for '+self.y_axis[0:len(self.y_axis)-4], xy=(my_best_model_number, min1), xytext=(0.9*my_best_model_number, -0.8*min1),
                             arrowprops=dict(facecolor='black', shrink=0.05),
                             )
            else:
                # Shows arrow where the minimum is
                plt.annotate('Minimum for '+self.y_axis[0:len(self.y_axis)-4], xy=(my_best_model_number, min1), xytext=(0.9*my_best_model_number, 0.8*min1),
                             arrowprops=dict(facecolor='black', shrink=0.05),
                             )
                
            plt.plot(self.list1,self.list2, c = self.point_color)
            p = 0 
        #my_local_time = str(time.strftime("%Y_%m_%d_%H_%M_%S"))
        my_plot_file = project_dir_in+root_input_csv_file_in+"."+str(self.plt_format.replace(" ",""))
        plt.savefig(my_plot_file, transparent=trans, dpi=self.dpi_value,format=self.plt_format)             # Saves the plot in the current directory with 1800 dpi resolution and transparent background
        
        # Shows plot on screen  
        plt.show()          # Open windows containing the plot image
        time.sleep(5)       # Shows plot for 5 seconds
        plt.close()         # Close plot                                                       
        return p 

    def hist_plot(self,x_label_in,y_label_in,x_axis, y_axis, plot_in, bin_in, plot_title, x_min, x_max, y_min, y_max, size_markers, point_color, marker_value, plt_format, trans, dpi_value,plt_color_in,project_dir_in,root_input_csv_file_in):
        """Method to plot a histogram"""
        import matplotlib.pyplot as plt
        import time  
        self.plt_format = str(plt_format.replace(" ",""))
        plt.grid(True)                               # Includes grid lines                                     
                                                    
        # Sets the limits for  y axis, ymin,ymax
        plt.xlabel(x_label_in)            # Label for x-axis
        plt.ylabel(y_label_in)            # Label for y-axis
        plt.title(plot_title)             # Adds title
   
        plt.hist(y_axis,bins=bin_in,range=[x_min,x_max],color = str(plt_color_in))        # Histogram
        my_plot_file = project_dir_in+root_input_csv_file_in+"."+str(self.plt_format.replace(" ",""))
        
        # Saves the plot in the current directory with 1800 dpi resolution and transparent background
        plt.savefig(my_plot_file, transparent=trans, dpi=dpi_value,format=str(self.plt_format.replace(" ","")))            
        
        # Shows plot on screen 
        plt.show()      # Open windows containing the plot image
        #time.sleep(10)  # Shows plot for 10 seconds
        plt.close()     # Close plot 

# Class for statistical analysis and multiple plots
class MultStatAnalysis(object):
    """Generates multiple plots"""
    
    def __init__(self,list1,list2,list3,list4,list5,list6,list7,list8,list9,list10,number_of_colums_in):
        import sys 
        self.list1 = list1
        self.list2 = list2
        self.list3 = list3
        self.list4 = list4
        self.list5 = list5
        self.list6 = list6
        self.list7 = list7 
        self.list8 = list8
        self.list9 = list9
        self.list10 = list10
        self.number_of_colums_in = number_of_colums_in
        if self.number_of_colums_in > 10:
            print("Error! I can handle up to ten files to plot!")
            print("Finishing SAnDReS!")
            sys.exit()
    
    def mult_scatter_plot(self,x_axis,y_axis,plot_title,x_min,x_max,y_min,y_max,size_markers,point_color,marker_value,plt_format,trans,dpi_value,project_dir_in,poly_deg_in,root_input_csv_file_in,type_of_plot_in,legend_flag_in,legend_list_in):
        """Method for 2-D Plot of multiple lists (up to ten lists)"""
        import time 
        import matplotlib.pyplot as plt

        self.legend_list_in = legend_list_in
        self.legend_flag_in = legend_flag_in
        self.type_of_plot_in = type_of_plot_in        
        self.x_axis = x_axis
        self.y_axis = y_axis
        self.plot_title = plot_title
        self.x_min = float(x_min)
        self.x_max = float(x_max)
        self.y_min = float(y_min)
        self.y_max = float(y_max) 
        self.size_markers = int(size_markers)
        self.point_color = str(point_color)
        self.marker_value = str(marker_value[0:1])
        self.plt_format = str(plt_format.replace(" ","").lower())
        self.trans = trans
        self.dpi_value = int(dpi_value)
        self.poly_deg_in =  int(poly_deg_in)
        
        # Program to plot multiple scatter plots.
        # We included the grid option, axis limits, labels, title and legends with specified location.
        # We used marker to specify the type of marker to be used in the scatter plot
        # We used color and size to specify the color and size for the markers
        # We saved the resulting plot as a file with transparent background.
        # This method can't be called before correlation_coefficient method
            
        plt.grid(True)                                                                              # Includes grid lines
        plt.xlim(self.x_min,self.x_max)                                                             # Sets the limits for  x axis, xmin,xmax
        plt.ylim(self.y_min,self.y_max)                                                             # Sets the limits for  y axis, ymin,ymax
        plt.xlabel(self.x_axis)                                                                     # Label for x-axis
        plt.ylabel(self.y_axis)                                                                     # Label for y-axis
        plt.title(self.plot_title)
                                                                        # Adds title
        
        if self.number_of_colums_in == 10:
            plt.plot(self.list1,self.list2, c = "blue", label = "Test") 
            plt.plot(self.list1,self.list3, c = "red") 
            plt.plot(self.list1,self.list4, c = "green") 
            plt.plot(self.list1,self.list5, c = "cyan")
            plt.plot(self.list1,self.list6, c = "black")
            plt.plot(self.list1,self.list7, c = "purple")
            plt.plot(self.list1,self.list8, c = "grey") 
            plt.plot(self.list1,self.list9, c = "orange")
            plt.plot(self.list1,self.list9, c = "pink")
        elif self.number_of_colums_in == 9:
            plt.plot(self.list1,self.list2, c = "blue") 
            plt.plot(self.list1,self.list3, c = "red") 
            plt.plot(self.list1,self.list4, c = "green") 
            plt.plot(self.list1,self.list5, c = "cyan")
            plt.plot(self.list1,self.list6, c = "black")
            plt.plot(self.list1,self.list7, c = "purple")
            plt.plot(self.list1,self.list8, c = "grey") 
            plt.plot(self.list1,self.list9, c = "orange")
        elif self.number_of_colums_in == 8:
            plt.plot(self.list1,self.list2, c = "blue", label = self.legend_list_in[0])
            plt.plot(self.list1,self.list3, c = "red",label = self.legend_list_in[1] ) 
            plt.plot(self.list1,self.list4, c = "green",label = self.legend_list_in[2]) 
            plt.plot(self.list1,self.list5, c = "cyan",label = self.legend_list_in[3])
            plt.plot(self.list1,self.list6, c = "black",label = self.legend_list_in[4])
            plt.plot(self.list1,self.list7, c = "purple",label = self.legend_list_in[5])
            plt.plot(self.list1,self.list8, c = "grey",label = self.legend_list_in[6])
        elif self.number_of_colums_in == 7:
            plt.plot(self.list1,self.list2, c = "blue", label = "T = 150 K" )
            plt.plot(self.list1,self.list3, c = "red",label = "T = 400 K"  ) 
            plt.plot(self.list1,self.list4, c = "green",label = "T = 1000 K") 
            plt.plot(self.list1,self.list5, c = "cyan", label = "T = 800 K")
            plt.plot(self.list1,self.list6, c = "black",label = "T = 500 K")
            plt.plot(self.list1,self.list7, c = "purple",label = "T = 300 K")
        elif self.number_of_colums_in == 6:
            plt.plot(self.list1,self.list2, c = "blue") 
            plt.plot(self.list1,self.list3, c = "red") 
            plt.plot(self.list1,self.list4, c = "green") 
            plt.plot(self.list1,self.list5, c = "cyan")
            plt.plot(self.list1,self.list6, c = "black")
        elif self.number_of_colums_in == 5:
            plt.plot(self.list1,self.list2, c = "blue") 
            plt.plot(self.list1,self.list3, c = "red") 
            plt.plot(self.list1,self.list4, c = "green") 
            plt.plot(self.list1,self.list5, c = "cyan")
        elif self.number_of_colums_in == 4:
            plt.plot(self.list1,self.list2, c = "blue") 
            plt.plot(self.list1,self.list3, c = "red") 
            plt.plot(self.list1,self.list4, c = "green") 
        elif self.number_of_colums_in == 3:
            plt.plot(self.list1,self.list2, c = "blue") 
            plt.plot(self.list1,self.list3, c = "red") 
        elif self.number_of_colums_in == 5:
            plt.plot(self.list1,self.list2, c = "blue") 
        
        if self.legend_flag_in:
            plt.legend()
            
        #my_local_time = str(time.strftime("%Y_%m_%d_%H_%M_%S"))
        my_plot_file = project_dir_in+root_input_csv_file_in+"."+str(self.plt_format.replace(" ",""))
        plt.savefig(my_plot_file, transparent=trans, dpi=self.dpi_value,format=self.plt_format)             # Saves the plot in the current directory with 1800 dpi resolution and transparent background
        
        # Shows plot on screen         
        plt.show()              # Open windows containing the plot image
        time.sleep(7)           # Shows plot for7 seconds
        plt.close()             # Close plot                                                       

def pre_download(my_dir_in,my_file_in):
    """Function to check if the file is already in the structure directory"""
    file_present = False
    
    # Try to open file
    try:
        my_fo = open(my_dir_in+my_file_in,"r")
        file_present  = True
        my_fo.close()
    except:
        file_present  = False
    
    # Return boolean variable
    return file_present 

def show_binding_info(my_dir_in,access_code,lig_in,chain_in):      
    """Function to show binding information from a csv file"""
    import csv
    import sys
    
    # Try to open csv file
    try:
        my_fo = open(my_dir_in+access_code+".csv","r")
        my_csv = csv.reader(my_fo)
    except:
        sys.exit("I can't find file "+my_dir_in+access_code+".csv!")   
        
    # Looping through csv file
    for line in my_csv:
        break
    for line in my_csv:
        if line[0] == access_code and line[1] == chain_in and line[2] == lig_in:
            print("\nBinding information for PDB: ",access_code,"Ligand: ",lig_in,chain_in,": ",line[3],"\n")
      
    my_fo.close()

def get_lig_info(access_code,my_dir_in,binding_info,lig_in,chain_in):
    """Function to download a csv formatted file from PDB with ligand information"""
    import urllib.request, urllib.parse, urllib.error
    import time
    #import csv
    #import sys
    #import numpy as np
    
    # Set up initial values for variable
    check_if_code_in = False
    file_2_download = access_code[0:4].replace(" ","")
    
    # Specify file format
    file_2_download = file_2_download+".csv"
    
    # Check if file is alrady in the structure directory
    flag_4_file_present = pre_download(my_dir_in,file_2_download)
    if flag_4_file_present:
        print("\n "+file_2_download+" file is already in the directory "+my_dir_in+"!\n")
        # Call show_binding_info()
        show_binding_info(my_dir_in,access_code,lig_in,chain_in)
        return
    
    # Specify url
    my_url = 'http://www.rcsb.org/pdb/rest/customReport?pdbids='+access_code[0:4].upper()+'&customReportColumns=structureId,chainId,ligandId,'+binding_info+',&service=wsfile&format=csv&ssa=n'
    
    # Try to download file    
    try: 
        file_object = urllib.request.urlopen(my_url)
        structure = file_object.read()
        file_object.close()
        
        file_object = urllib.request.urlopen(my_url)
        #structure_line = file_object.readline()
        file_object.close()
    except:
        check_if_code_in = False
        my_iteraction = 1
        print("RCSB is complaining about 'High User Activity'.")
        print("I will try to wait longer for each file...")
        my_time_to_wait = my_iteraction*120
        print("Waiting for",my_time_to_wait," seconds...")
        time.sleep(my_time_to_wait)
        print("Downloading file "+file_2_download+" from http://www.rcsb.org/")
        loop_flag = True
        
        # while loop to keep trying to download
        while loop_flag:
            try: 
                file_object = urllib.request.urlopen(my_url)
                structure = file_object.read()
                file_object.close()
        
                file_object = urllib.request.urlopen(my_url)
                #structure_line = file_object.readline()
                file_object.close()
                loop_flag = False
                check_if_code_in = True
            except:
                my_iteraction += 1
                loop_flag = True
                check_if_code_in = False
    
            if my_time_to_wait > 359:
                print("It is taking too long!")
                print("Try to split in different inputs chkstr.in, with a smaller number of structures per input.\n")
                return check_if_code_in
                break
                
    print("\n "+file_2_download+" downloaded from http://www.rcsb.org/")
    with open(my_dir_in+file_2_download,"wb") as my_file_4_download:
        my_file_4_download.write(structure)
        my_file_4_download.close()
        check_if_code_in = True
    
    # Call show_binding_info()
    show_binding_info(my_dir_in,access_code,lig_in,chain_in)
       
# Functions for main program
def polscore(my_scoring_function_file,num_ind_var,path_in,my_strdir_in,my_mlr_method_in):
    """ Polscore function"""
    
    # Main program
    import sys 

    # Sets up the directory where Python scripts are
    sys.path.append(path_in)
    import scikit_regression_methods_v1_1 as pol1     
       
    # Set up Polscore directory
    polscore_dir = my_strdir_in+"\\Polscore\\"
    
    # Append to polscore.log file
    polscore_log_fo = open(my_strdir_in+"polscore.log","a")
    polscore_csv_fo = open(my_strdir_in+"polscore.csv","a")

    # Calls function read_csv_4_polscore()
    my_input_file_name, my_first_line, my_x_axis_label, num_var, x,y = read_csv_4_polscore(polscore_dir+my_scoring_function_file,num_ind_var)

    print("X-axis label: ",my_x_axis_label)
    print("File name: ",my_input_file_name)
    
    # Calls filter_data_4_polscore
    my_indep_variables,z = filter_data_4_polscore(x,y,num_var)

    # Creates regression model (return self.b, self.R2, self.R2adj,self.sd,self.F,self.Fpv)
    polscore_model = pol1.Multvar_reg_modeling(num_var,y,z,'y',my_indep_variables,my_mlr_method_in)     
    my_model_coefs,my_R2,my_R2_adj,my_sd,my_rho,my_rho_p = polscore_model.summary()

    # Calls function to generate POLSCORE models
    p1,my_model_string0 = gen_model_4_polscore(num_var,my_model_coefs,my_first_line,x,y) 
        
    my_model_string1 = my_model_string0.replace("++"," + ")
    my_model_string2 = my_model_string1.replace("--"," - ")
    my_model_string3 = my_model_string2.replace("+  -"," - ")
    my_model_string = my_model_string3.replace("+   "," + ")
    
    my_index2 = my_scoring_function_file.index(".csv")
    my_index1 = my_index2 - 7
    pol_index = my_scoring_function_file[my_index1:my_index2]
    
    # Fix the number of characters
    my_str_7_char = str(pol_index)
    if len(my_str_7_char)< 8:
        my_str_in1 = str((7-len(my_str_7_char) )*"0")+my_str_7_char
    polscore_log_fo.write("\n\n##################################### POLSCORE MODEL GENERATOR ###########################################\n")
    polscore_log_fo.write("\nPolynomial equation number "+my_str_in1+": "+my_model_string)  
    polscore_log_fo.write("\nFile: "+my_scoring_function_file)
    polscore_log_fo.write("\nBest fit equation between observed and predicted information:"+str(p1))
    polscore_log_fo.write('\nR-squared            % -5.6f' % my_R2 )
    polscore_log_fo.write('\nAdjusted R-square    % -5.6f' % my_R2_adj )
    polscore_log_fo.write('\nStandard deviation   % -5.6f' % my_sd)
    polscore_log_fo.write('\nSpearman correlation % -5.6f' % my_rho )
    polscore_log_fo.write('\np-value              % -5.6f' % my_rho_p )
        
    if my_rho_p < 0.0001:
        my_rho_p = 0.000
    polscore_csv_fo.write(my_scoring_function_file+","+\
                          str(my_R2)+","+str(my_R2_adj)+","+str(my_sd)+","+\
                          str(my_rho)+","+str(my_rho_p)+"\n")
    
def read_csv_4_polscore(my_scoring_function_file_in,num_ind_var_in):
    """Function to read CSV file"""
    
    import csv
    import numpy as np
    
    # Reads input file name and polynomial equation degree
    input_file_name = my_scoring_function_file_in
    var = num_ind_var_in
    
    # Reads first line to get headers
    csv_in = open(input_file_name,"r") 
    get_csv_lines = csv.reader(csv_in)
    
    # Reads CSV file first line only
    for line in get_csv_lines:     
        x_axis_label = line[var]
        break
    csv_in.close()
    
    # Reads CSV file and skips first line
    csv = np.genfromtxt (input_file_name, delimiter=",", skip_header = 1) 
    
    # Gets each column from CSV file
    y = csv[:,var] 
    x = csv[:,0:var]
    
    return input_file_name,line,x_axis_label, var, x,y
    
def gen_model_4_polscore(var,qsar_coefs,first_line,x_in,y_in):
    """Function to generate POLSCORE models"""
    import numpy as np
    
    # Looping through to generate POLSCORE model
    p = 0
    total_variables = var + 1
    polscore_model_string = ""
    for i in range(total_variables):
        if i == 0:
            p += qsar_coefs[i]
            polscore_model_string += str("%12.6f"%qsar_coefs[i])+"+" 
        else:
            p += qsar_coefs[i]*x_in[:,i-1]
            polscore_model_string += str("+%12.6f"%qsar_coefs[i])+"*("+first_line[i-1]+")"
    
    # Generate best fit line for experimental and computational POLSCORE model (least-squares polynomial fitting) 
    z = np.polyfit(y_in,p, 1)
    p1 = np.poly1d(z)
  
    return p1,polscore_model_string

def filter_data_4_polscore(x,y,var):
    """Function to filter data"""
    import numpy as np
    
    # Defines numbers of rows and columns 
    columns = var
    rows = len(y)

    # Sets up a matrix
    z = np.array([[0]*columns]*rows,float)           # np.array([[0]*column]*row,float)

    # looping through x to get independent variable columns
    for i in range(rows):
        for j in range(columns):
            z[i,j] = x[i,j]
        
    # Looping through to create a list with independent variables
    my_indep_variables = []
    for i in range(columns):
        my_indep_variables.append("x"+str(i+1))
 
    return my_indep_variables,z

def getUnits(binding_affinity):
    """Function to get units for a type of binding affinity downloaded from PDB"""
    
    # Dictionary for units of binding affinity found in the PDB (October 21st 2015 version)
    units = {"Ki":"(in nM)",
             "Kd":"(in nM)",
             "EC50":"(in nM)",
             "IC50":"(in nM)",
             "deltaG":"(in kJ/mol)",
             "deltaH":"(in kJ/mol)",
             "Ka":"(in 1/M)"}
    
    identified_unit = False
    
    # Looping through units
    for line in units:
        if line.upper() == binding_affinity.upper():
            my_unit = units[line]
            identified_unit = True
            return my_unit
    
    if not identified_unit:
        print("Binding affinity not in the dictionary!")
        return "Not identified!"
#---------------------------------Acho que o download de KI começa aqui (Amauri)
def getBind(my_dir_in,structureId,binding_info):
    """Function to download CSV file with binding affinty"""
    import urllib.request, urllib.parse, urllib.error
    import time
    #import csv
    #import sys
    
    # String for local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Sets up initial values for variable and list
    check_if_code_in = False
    my_structureId_string = structureId.lower()
    my_binding_list = ["Ki","Kd","EC50","IC50","deltaG","deltaH","Ka"]
    
    # Looping through my_binding_list
    for bind_in in my_binding_list:
        if binding_info.upper() == bind_in.upper():
            binding_info1 = bind_in
    
    # Specify file
    file_2_download =my_structureId_string+".csv"
    
    # Check if file is already in the structure directory
    flag_4_file_present = pre_download(my_dir_in,file_2_download)
    if flag_4_file_present:
        check_if_code_in = True
        return check_if_code_in
    
    # Specify url
    #my_url = 'http://www.rcsb.org/pdb/rest/customReport?pdbids='+my_structureId_string+'&customReportColumns=structureId,chainId,ligandId,'+binding_info+',&service=wsfile&format=csv&ssa=n'
    my_url = 'http://www.rcsb.org/pdb/rest/customReport?pdbids='+my_structureId_string+'&customReportColumns=structureId,chainId,ligandId,'+binding_info1+'&service=wsfile&format=csv&ssa=n'
    
    # Try to download file    
    try: 
        file_object = urllib.request.urlopen(my_url)
        structure = file_object.read()
        file_object.close()
        
        file_object = urllib.request.urlopen(my_url)
        #structure_line = file_object.readline()
        file_object.close()
    except:
        check_if_code_in = False
        my_iteraction = 1
        print("RCSB is complaining about 'High User Activity'.")
        print("I will try to wait longer for each file...")
        my_time_to_wait = my_iteraction*20
        print("Waiting for",my_time_to_wait," seconds...")
        time.sleep(my_time_to_wait)
        print("\n "+file_2_download+" file downloaded from http://www.rcsb.org/")
        loop_flag = True
        
        # while loop to keep trying to download
        while loop_flag:
            try: 
                file_object = urllib.request.urlopen(my_url)
                structure = file_object.read()
                file_object.close()
        
                file_object = urllib.request.urlopen(my_url)
                #structure_line = file_object.readline()
                file_object.close()
                loop_flag = False
                check_if_code_in = True
            except:
                my_iteraction += 1
                loop_flag = True
                check_if_code_in = False
    
            if my_time_to_wait > 359:
                print("It is taking too long!")
                print("Try to split in different inputs getbind.in, with a smaller number of structures per input.\n")
                return check_if_code_in
                break
            
    time.sleep(1)
    
    with open(my_dir_in+file_2_download,"wb") as my_file_4_download:
        my_file_4_download.write(structure)
        my_file_4_download.close()
        check_if_code_in = True

def getSTR(access_code,file_format_in,my_dir_in):
    """Function to download a formatted file from PDB"""
    
    import urllib.request, urllib.parse, urllib.error
    import time
    
    # Sets up initial values for variable
    check_if_code_in = False
    file_2_download = access_code[0:4].replace(" ","")
    file_format = file_format_in.lower()
    
    # Identify the file format
    if file_format == "pdb":
        file_2_download = file_2_download+".pdb"
    elif file_format == "html": 
        file_2_download = file_2_download.lower()+".html" 
    elif file_format == "cif":
        file_2_download = file_2_download+".cif"
    elif file_format == "fas":
        file_2_download = file_2_download+".fasta"
    elif file_format == "xml":
        file_2_download = file_2_download+".xml"
    elif file_format == "sf":
        file_2_download = file_2_download+"-sf.cif"
    elif file_format == "sdf":
        file_2_download = file_2_download+".sdf"
    else:
        print("Unrecognizable format")
        return check_if_code_in
    
    # Check if file is alrady in the structure directory
    flag_4_file_present = pre_download(my_dir_in,file_2_download)
    if flag_4_file_present:
        print("File "+file_2_download+" is in the directory "+my_dir_in+"!\nIgnoring download request!\n")
        check_if_code_in = True
        return check_if_code_in
    
    #Tests file formats
    if file_format == "fas":
        # Directs to fasta directory
        my_url = 'http://www.rcsb.org/pdb/files/fasta.txt?structureIdList='+access_code[0:4]
    elif file_format =="sdf":
        # Directs to ligand directory
        my_url = 'http://www.rcsb.org/pdb/files/ligand/'+file_2_download
    elif file_format == "html":
        #my_url = 'http://www.rcsb.org/pdb/explore/explore.do?structureId=2a4l'
        my_url = 'http://www.rcsb.org/pdb/explore/explore.do?structureId='+access_code[0:4].lower()
    else:
        # Directs to files directory for all other formats
        my_url = 'http://files.rcsb.org/download/'+file_2_download
        
    # Try to download file    
    try: 
        file_object = urllib.request.urlopen(my_url)
        structure = file_object.read()
        file_object.close()
        
        file_object = urllib.request.urlopen(my_url)
        structure_line = file_object.readline()
        file_object.close()
        
        # To take care of non-existing FASTA format files
        if file_format == "fas":
            if ">" not in str(structure_line):
                print("We're sorry, but the requested file",file_2_download," is not available.")
                print("Please check your access code or contact PDB staff at http://www.rcsb.org/pdb/home/contactUs.do ")
                input("Type enter to continue...")
                check_if_code_in = False
                return check_if_code_in

    except:
        check_if_code_in = False
        my_iteraction = 1
        print("RCSB is complaining about 'High User Activity'.")
        print("I will try to wait longer for each file...")
        my_time_to_wait = my_iteraction*120
        print("Waiting for",my_time_to_wait," seconds...")
        time.sleep(my_time_to_wait)
        print("\n "+file_2_download+" file downloaded from http://www.rcsb.org/")
        loop_flag = True
        
        # while loop to keep trying to download
        while loop_flag:
            try: 
                file_object = urllib.request.urlopen(my_url)
                structure = file_object.read()
                file_object.close()
        
                file_object = urllib.request.urlopen(my_url)
                structure_line = file_object.readline()
                file_object.close()
                loop_flag = False
                check_if_code_in = True
            except:
                my_iteraction += 1
                loop_flag = True
                check_if_code_in = False
    
            if my_time_to_wait > 359:
                print("It is taking too long!")
                print("Try to split in diffent inputs getstr.in, with a smaller number of structures per input.\n")
                return check_if_code_in
                break
            
    time.sleep(1)
    
    print("\n "+file_2_download+" file downloaded from http://www.rcsb.org/")
    with open(my_dir_in+file_2_download,"wb") as my_file_4_download:
        my_file_4_download.write(structure)
        my_file_4_download.close()
        check_if_code_in = True
    
    # Check if there is "High User Activity"
    if ".html" in file_2_download:
        print("Checking if the download was complete...")
        my_downloaded_html = open(my_dir_in+file_2_download,"r")
        my_lines = my_downloaded_html.read()
        my_downloaded_html.close()
        my_iteraction = 1
        
        while "High User Activity" in my_lines:
            print("RCSB is complainning about 'High User Activity'.")
            print("I will try to wait longer for each file...")
            my_time_to_wait = my_iteraction*30
            print("Waiting for",my_time_to_wait," seconds...")
            time.sleep(my_time_to_wait)
            print("Downloading file "+file_2_download+" from http://www.rcsb.org/")
            
            with open(my_dir_in+file_2_download,"wb") as my_file_4_download:
                my_file_4_download.write(structure)
                my_file_4_download.close()
                check_if_code_in = True
            if my_time_to_wait > 359:
                print("It is taking too long!")
                print("Try to split in diffent inputs getstr.in, with a smaller number of structures per input.\n")
                break
            my_downloaded_html = open(my_dir_in+file_2_download,"r")
            my_lines = my_downloaded_html.read()
            my_downloaded_html.close()
            my_iteraction += 1
            
        print("Download finished!")
    #elif ".pdb" in file_2_download:  
    #    print("Checking if the download was complete...")
    #    my_downloaded_pdb = open(my_dir_in+file_2_download,"r")
    #    my_lines = my_downloaded_pdb.read()
    #    my_downloaded_pdb.close()
    #    my_iteraction = 1
        
    return check_if_code_in

def read_sandres_par(par_in):
    """Function to read SAnDReS parameter"""
    import csv
    
    # OPen sandres_par.csv
    fo = open(sandres_root+"sandres_par.csv","r")
    my_csv = csv.reader(fo)

    # Looping through my_csv    
    for par in my_csv:
        if par[0] == par_in:
            par_out =  par[1]
            break
    
    return par_out
    
def read_bad_ligs():
    """Function to read file bad_ligands.csv which stores ligands to excluded from the dataset"""
    import csv
    
    # Set count_ligs to zero
    count_ligs = 0
    
    # Set empty list
    my_list_of_ligs = []
    
    # Call read_sandres_par() to get omitted ligand files
    my_bad_lig = read_sandres_par("omitted_lig_file")
    
    print("\nOmitted ligands from "+my_bad_lig)
    
    # Open bad_ligands.csv 
    try:
        my_bad_lig_fo = open(sandres_root+"Ligands\\Omitted_Ligands\\"+my_bad_lig,"r")
        my_bad_lig_csv = csv.reader(my_bad_lig_fo)
    except IOError:
        print("\nI can't find "+my_bad_lig+" file in the ligands directory!")
        return my_list_of_ligs
    
    # looping through bad_ligands.csv 
    for line in my_bad_lig_csv:
        for lig in line:
            count_ligs += 1
            my_list_of_ligs.append(lig)
    
    # Close File
    my_bad_lig_fo.close()
    
    return my_list_of_ligs[1:]
           
def chkSTR(access_code,file_format_in,my_dir_in):
    """Function to check whether a structure file in the structure directory or not"""
    import sys
    #import numpy as np
    import csv
    
    # Call read_bad_logs() function      
    bad_ligands = read_bad_ligs()
    
    # Set empty list
    my_list_of_pdbs = []
    
    # Set initial values for boolean variables
    check_if_code_in = False
    my_binding_value = None
    binding_presence = False
    
    # Identify type of binding information  
    if file_format_in.upper() == "IC50":
        file_format = file_format_in.upper()
    elif file_format_in.upper() == "KI":
        file_format = "Ki" 
    elif file_format_in.upper() == "KD":
        file_format = "Kd" 
    elif file_format_in.upper() == "DELTAG":
        file_format = "deltaG" 
    elif file_format_in.upper() == "DELTAH":
        file_format = "deltaH" 
    elif file_format_in.upper() == "KA":
        file_format = "Ka" 
    elif file_format_in.upper() == "EC50":
        file_format = "EC50" 
    else:
        print("SAnDReS Warning! Unrecognizable Type of Binding Information!")
        print("Finishing check structure!")
        return check_if_code_in, access_code.upper()
    
    # Prepare file_2_check
    file_2_check = my_dir_in+access_code.lower()+".csv"
      
    # Open file_2_check
    try:
        code_file = open(file_2_check,"r")
        my_csv_fo = csv.reader(code_file)
        check_if_code_in = True
    except:
        print("\nI can't find file ",file_2_check)
        print("\nPlease check directory and/or file name.")
        print("Finishing SAnDReS execution!")
        sys.exit()
    
    # Set empty list
    my_lines = []
    
    # Looping through csv file
    for line in my_csv_fo:
        if "An error has occurred" in line[0]:
            print("\nSanDReS Fatal Error! Download error message in "+file_2_check+"\n")
            print("\nFinishing SAnDReS!")
            sys.exit()
            
        if line[2] not in bad_ligands and line[2] not in my_lines and line[2] != "ligandId":
            if "D" in str(line[3]):
                my_lines.append(line[2])
                print("\nLigand code: "+line[2])
    
    my_ligand = "   "
    my_ligand_chain = " "
    my_ligand_number = 999
    
    if  file_format.upper() == "IC50" or file_format.upper() == "KI" or file_format.upper() == "KD" or \
        file_format.upper() == "KA" or file_format.upper() == "DELTAG" or file_format.upper() == "DELTAH" or \
        file_format.upper() == "EC50" :
        
        # Looping through to get ligand name
        binding_affinity = False
        for line in my_lines:
            if "D" in line or binding_affinity:
                binding_affinity = True
                
        # Looping through to get complete ligand information
        #interactions = True
        my_chklig_file = open(my_dir_in+"chklig.in","a")    
        code_file.close()
        
        for line in my_lines:
            if line != "ligandId":  # Only to keep overall tree structures, but not necessary
                tmp_my_ligand = str(line.upper()) 
                
                if tmp_my_ligand not in bad_ligands:
                    my_ligand = tmp_my_ligand
                    
                    # Fix the number of characters
                    my_str_3_char = str(my_ligand.replace(" ",""))
                    if len(my_str_3_char)< 4:
                        my_str_lig = str((3-len(my_str_3_char) )*" ")+my_str_3_char
                        my_ligand = my_str_lig # We must have three columns
                    else:
                        print("Please check input file.")
                        sys.exit()
                
                    # Open PDB file to check ligand information
                    my_fo_pdb = open(my_dir_in+access_code+".pdb","r")
                    my_count_hetatm = 0
                    
                    # looping through pdb file to get ligand information
                    for my_pdb_line in my_fo_pdb:
                        if my_pdb_line[0:6] == "HETATM" and my_pdb_line[17:20] == my_ligand and my_pdb_line[17:20] not in bad_ligands:
                            my_ligand_chain = my_pdb_line[21:22]
                            my_ligand_number = my_pdb_line[22:26]
                
                            # Counts non-hydrogen atoms
                            if my_pdb_line[13:14] != "H":
                                my_count_hetatm += 1
                        
                            # Fix the number of characters
                            my_str_4_char = str(my_ligand_number.replace(" ",""))
                            if len(my_str_4_char)< 5:
                                my_str_lig = str((4-len(my_str_4_char) )*" ")+my_str_4_char
                                my_ligand_number = my_str_lig # We must have four columns
                            else:
                                print("Ligand number should be less than 9999! Please check input file.")
                                sys.exit()
                    
                        if my_count_hetatm > 2:
                            #interactions = False
                            my_list_of_pdbs.append(access_code)
                            break      
                    
                    my_fo_pdb.close()
                    print("\nGathering binding affinity information for ",access_code,my_ligand,my_ligand_chain)
                    
                    # Call get_lig_info (my_dir_in+access_code.lower()+".html")  (access_code,my_dir_in,binding_info):
                    get_lig_info(access_code,my_dir_in,file_format,my_ligand,my_ligand_chain)
                    
                    my_binding_value = 0.0                            
                    
                    if my_binding_value == None: 
                        binding_presence = False
                    else:
                        binding_presence = True
        
        #binding_presence = True
        #my_binding_value = 0.0
        
        if not binding_presence:
            my_binding_value =  None
            print("I didn't find any binding affinity value in the file ",file_2_check,"!")
            print("Please check at www.rcsb.org/pdb")
            no_binding_aff_code = access_code.upper()
        else:
            if my_ligand_chain == " ":
                no_binding_aff_code = None
                print("I didn't find information about the ligand chain for structure ",access_code.upper(),"!")
                print("Please check at www.rcsb.org/pdb!")
            else:      
                try:      
                    my_binding_value = round(float(my_binding_value),3)
                    if my_ligand.upper() not in bad_ligands:
                        sandres_line_out = "CHKLIG,"+access_code.upper()+","+my_ligand.upper()+","+my_ligand_chain+","+str(my_ligand_number)+","+str(my_binding_value)+"\n" 
                        my_chklig_file.write(sandres_line_out)
                    no_binding_aff_code = None
                except:
                    print()
                              
    #binding_presence = False
    #multiple_values = False
    try:
        return check_if_code_in, no_binding_aff_code
    except:
        no_binding_aff_code = None
        return check_if_code_in, no_binding_aff_code
          
def update_pdb_codes_chklig(my_dir_in,my_pdb_list_2_delete):
    """Function to get rid of a PDB list in chklig.in file """
    import shutil
    import csv
    import sys
    import time
    
    # String for local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Update chklig.in
    my_chklig_list = []
    shutil.copy2(my_dir_in+"chklig.in",my_dir_in+"chklig_"+my_local_time+".in")
    try:
        chklig_fo = open(my_dir_in+"chklig.in","r")
        chklig_csv =  csv.reader(chklig_fo)
    except:
        print("\nI can't find file "+my_dir_in+"chklig.in")
        print("\nPlease check directory and/or file name.")
        input("\nPress enter key to exit program.")
        sys.exit(0)  # Exiting program
        
    # Looping through chklig.in
    for line0 in chklig_csv:
        my_chklig_list.append(line0)
        break
    
    print("\nUpdating chklig.in")
    # Looping through the rest of chklig.in
    for line1 in chklig_csv:
        if line1[1] in my_pdb_list_2_delete:
            print("Deleting: "+line1[1])
        else:
            print(line1)
            my_chklig_list.append(line1)
    
    chklig_fo.close()
    
    chklig_fo = open(my_dir_in+"chklig.in","w")
   
    # Write first line
    my_first_line_in_chklig0 = str(my_chklig_list[0]).replace("[","")
    my_first_line_in_chklig1 = my_first_line_in_chklig0.replace("]","")
    my_first_line_in_chklig2 = my_first_line_in_chklig1.replace("'","")
    chklig_fo.write(my_first_line_in_chklig2+"\n")
    
    # Looping my_chklig_list    
    for line in my_chklig_list[1:]:
        if line[0] == "CHKLIG":
            my_line_in_chklig0 = "CHKLIG"
            for line000 in line[1:]:
                my_line_in_chklig0 += ","+line000
            
            chklig_fo.write(my_line_in_chklig0+"\n")
    
    chklig_fo.close()
    
def update_pdb_codes_ststru(my_dir_in,my_pdb_list_2_delete):
    """Function to get rid of a PDB list in ststru.in file """
    import shutil
    import csv
    import sys
    import time
    
    # String for local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Update ststru.in
    my_ststru_list = []
    shutil.copy2(my_dir_in+"ststru.in",my_dir_in+"ststru_"+my_local_time+".in")
    try:
        ststru_fo = open(my_dir_in+"ststru.in","r")
        ststru_csv =  csv.reader(ststru_fo)
    except:
        print("\nI can't find file "+my_dir_in+"ststru.in")
        print("\nPlease check directory and/or file name.")
        input("\nPress enter key to exit program.")
        sys.exit(0)  # Exiting program
        
    # Looping through ststru.in
    for line0 in ststru_csv:
        my_ststru_list.append(line0)
        break
    
    print("\nUpdating ststru.in")
    # Looping through the rest of ststru.in
    for line1 in ststru_csv:
        if line1[0] != "ENDOF":
            if line1[1] in my_pdb_list_2_delete:
                print("Deleting: "+line1[1])
            else:
                print(line1)
                my_ststru_list.append(line1)
        else:
            my_ststru_list.append(line1)
    
    ststru_fo.close()
    
    ststru_fo = open(my_dir_in+"ststru.in","w")
   
    
    # Looping my_ststru_list    
    for line in my_ststru_list[1:]:
        if line[0] == "STSTRU":
            my_line_in_ststru0 = "STSTRU"
            for line000 in line[1:]:
                my_line_in_ststru0 += ","+line000
            
            ststru_fo.write(my_line_in_ststru0+"\n")
    
    ststru_fo.write("ENDOF")
    
    ststru_fo.close()
               
def change2comma(my_file_name):
    """Function to check CSV file"""
    import csv
    import sys
    
    my_new_list_4_csv = []
    
    # Try to open csv File
    try:
        my_file_fo = open(my_file_name, "r")
        my_csv_file = csv.reader(my_file_fo)
    except IOError:
        print("I can't file file ",my_file_name)
        sys.exit()
    
    # Looping through CSV file    
    for line in my_csv_file:
        # Check semicolon
        my_string = str(line)
        if ";" in my_string:
            my_new_string = my_string.replace(";",",")
            my_new_list_4_csv.append(my_new_string)
        else:
            my_new_list_4_csv.append(my_string)
    
    # Close file
    my_file_fo.close()
    
    # Open my_file
    my_fo = open(my_file_name,"w")

    # Looping through my_new_list_4_csv
    for line in my_new_list_4_csv:
        my_fo.write(line[2:len(line)-2]+"\n" )

    # Close file
    my_fo.close()
      
# main() function
def main():
    import sys
    import time
    import csv
    import math
    import numpy as np
    
    # Sets uo initial values for variables, lists and defines arrays
    # a = np.array([[0]*column]*row,float)    # A matrix row(3) x column(1000)
    b_value_array_sphere_all        = np.array([[0]*10000]*10,float)        # np.array([[0]*column]*row,float)
    b_value_array_sphere_MC         = np.array([[0]*10000]*10,float)        # np.array([[0]*column]*row,float)
    b_value_array_sphere_SC         = np.array([[0]*10000]*10,float)        # np.array([[0]*column]*row,float)
    occupancy_array_sphere_all      = np.array([[0]*10000]*10,float)        # np.array([[0]*column]*row,float)
    occupancy_array_sphere_MC       = np.array([[0]*10000]*10,float)        # np.array([[0]*column]*row,float)
    occupancy_array_sphere_SC       = np.array([[0]*10000]*10,float)        # np.array([[0]*column]*row,float)
    
    # pdb_remark_info stores parameters read from PDB files
    pdb_remark_info                 = np.array([[0]*10000]*500,float)       # np.array([[0]*column]*row,float)
    missing_pdb_remark_info         = np.array([0]*5000,int)                # np.array([0]*column,int)
    no_pdb_remark_info              = np.array([[0]*10000]*500,int)         # np.array([[0]*column]*row,int) 
    rmsd_array                      = np.array([[0]*10000]*1000,float)      # np.array([[0]*column]*row,float)
    score_array                     = np.array([[0]*10000]*1000,float)      # np.array([[0]*column]*row,float)
    count_aux_PDB                   = np.array([0]*10000,int)               # np.array([0]*column,int)
    
    expBindingArray                 = np.array([0]*10000,float) 
    new_rmsd_array                  = np.array([0]*10000,float) 

    ccR                             = np.array([0]*5000,float)
    ccP                             = np.array([0]*5000,float)
    
    my_array1 = np.array([0]*100000,float)     # np.array([0]*number_of_lines)
    my_array2 = np.array([0]*100000,float)     # np.array([0]*number_of_lines)
    
    my_mult_array = np.array([[0]*10000]*10,float)        # np.array([[0]*column]*row,float)
            
    # Lists for STRMSD
    strmsd_column = []
    strmsd_info =   []
    
    # List for text to be displayed when STSTRU is requested
    remark_ststru_info = ["Crystallographic high-resolution limit        ",
                          "Crystallographic low-resolution limit         ",
                          "Crystallographic R-factor                     ",
                          "Crystallographic R-free                       ",
                          "Completeness                                  ",
                          "RMSD from ideal values (bond length)          ",
                          "RMSD from ideal values (bond angle)           ",
                          "RMSD from ideal (torsion angle period 1)      ",
                          "RMSD from ideal (torsion angle period 2)      ",
                          "RMSD from ideal (torsion angle period 3)      ",
                          "RMSD from ideal (torsion angle period 4)      ",
                          "Information about missing residues            ",
                          "Mean B-value (active ligand)                  ",
                          "Mean occupancy (active ligand)                ",
                          "Mean B-value (whole structure)                ",
                          "Mean occupancy (whole structure)              ",
                          "Mean B-value (water molecules)                ",
                          "Mean occupancy (water molecules)              ",
                          "Mean B-value (main-chain protein atoms)       ",
                          "Mean occupancy (main-chain protein atoms)     ",
                          "Mean B-value (side-chain protein atoms)       ",
                          "Mean occupancy (side-chain protein atoms)     "
                          ]
    
    # List for text to be displayed when STDOCK is requested
    remark_output_info = ["Crystallographic high-resolution limit        ",
                          "Crystallographic low-resolution limit         ",
                          "Crystallographic R-factor                     ",
                          "Crystallographic R-free                       ",
                          "Error for crystallographic R-free             ",
                          "Minimum fobs/sigma                            ",
                          "Number of reflections                         ",
                          "Completeness                                  ",
                          "B-value from Wilson plot                      ",
                          "ESD from Luzzati plot                         ",
                          "ESD from sigmaa plot                          ",
                          "Cross-validated ESD from Luzzati plot         ",
                          "Cross-validated ESD from sigmaa plot          ",
                          "ESU based on R-value                          ",
                          "ESU based on R-free                           ",
                          "ESU based on maximum likelihood               ",
                          "ESU for B-values based on maximum likelihood  ",
                          "Correlation coefficient for Fo-Fc             ",
                          "Correlation coefficient for Fo-Fc free        ",
                          "RMSD from ideal values (bond length)          ",
                          "RMSD from ideal values (bond length others)   ",
                          "RMSD from ideal values (bond angle)           ",
                          "RMSD from ideal values (bond angle others)    ",
                          "Angle distances (SHELXL)                      ",
                          "Distances from restraint planes (SHELXL)      ",
                          "Zero chiral volumes (SHELXL)                  ",
                          "Non-zero chiral volumes (SHELXL)              ",
                          "Anti-bumping distance restraints (SHELXL)     ",
                          "RMSD from ideal (torsion angle period 1)      ",
                          "RMSD from ideal (torsion angle period 2)      ",
                          "RMSD from ideal (torsion angle period 3)      ", #30
                          "RMSD from ideal (torsion angle period 4)      ",
                          "Torsion angles from Buster-TNT program        ",
                          "Trigonal carbon planes (Buster-TNT)           ",
                          "General planes                  (Buster-TNT)  ",
                          "Isotropic thermal factors(Buster-TNT)         ",
                          "non-bonded contacts (Buster-TNT)              ",
                          "RMSD for omega pep. torsion angle(Buster-TNT) ",
                          "Coordinate error (max-like. method) (PHENIX)  ",
                          "Phase error (max-like. method) (PHENIX)       ",
                          "RMSD for chirality (PHENIX)                   ", #40
                          "RMSD for planarity (PHENIX)                   ",
                          "RMSD for dihedral (PHENIX)                    ",
                          "RMSD for chiral center restraints             ",
                          "RMSD for general planes refined atoms         ",
                          "RMSD for general planes other atoms           ",
                          "RMSD for non-bonded contacts refined atoms    ",
                          "RMSD for non-bonded contacts other atoms      ",
                          "RMSD for non-bonded torsions                  ",
                          "RMSD for non-bonded torsion others            ",
                          "RMSD for H-bonds (X...Y) refined atoms        ", #50
                          "RMSD for H-bonds (X...Y) refined other atoms  ",
                          "RMSD for potential metal-ion refined atoms    ",
                          "RMSD for symmetry VDW refined atoms           ",
                          "RMSD for symmetry VDW refined other atoms     ",
                          "RMSD for symmetry H-bond refined atoms        ",
                          "RMSD for symmetry metal-ion refined atoms     ",
                          "Crystal temperature                           ", #57
                          "X-ray wavelength                              ", #58
                          "Number of unique reflections                  ", #59
                          "Resolution range low                          ", #60
                          "Completeness for range (data)                 ",
                          "I/sigma(I) for data set                       ",
                          "Highest resolution shell for data set         ",
                          "Highest resolution shell low for data set     ",
                          "Completenss for shell for data set            ",
                          "I/sigma(I) for shell for data set             ",
                          "Solvent content                               ",
                          "Matthews coefficient                          ",
                          "Information about missing residues            ",
                          "Number of rotatable bonds in the ligand       ",
                          "Number of protein atoms                       ",
                          "Number of ligand atoms                        ",
                          "Number of solvent atoms                       ",
                          "Number of all atoms                           ",
                          "Number of active-ligand atoms                 ",
                          "Protein molecular weight                      ",
                          "Mean B-value (ligand and co-factors)          ",
                          "Mean occupancy (ligand and co-factors)        ",
                          "Mean B-value (water molecules)                ",
                          "Mean occupancy (water molecules)              ",
                          "Mean B-value (whole structure)                ",
                          "Mean occupancy (whole structure)              ",
                          "Mean B-value (main-chain protein atoms)       ",
                          "Mean occupancy (main-chain protein atoms)     ",
                          "Mean B-value (side-chain protein atoms)       ",
                          "Mean occupancy (side-chain protein atoms)     ",
                          "Mean B-value (active ligand)                  ",
                          "Mean occupancy (active ligand)                ",
                          "Unit cell volume                              ",
                          "Reciprocal unit cell volume                   ",
                          "Total number of possible reflections          "
                          ]
    
    undetermined_remark_ststru_info = []
    my_list_of_pdb_with_water       = []
    my_list_of_pdb_with_no_water    = []
    water_dir                       = None
    project_dir                   = None
    radius                          = []
    radius_wat                      = []
    max_number_wat                  = []
    volume                          = []
    count_spheres                   = 0
    count_PDB                       = 0 
    count_PDB_wat                   = 0
    
    name_PDB                        = []
    name_no_PDB                     = []
    code_PDB                        = []
    name_PDB_wat                    = []
    name_PDB_wat_sphere             = []
    name_LIG                        = []
    name_LIG_aux                    = []
    name_LIG_wat                    = []
    chain_LIG                       = []
    chain_LIG_wat                   = []
    number_LIG                      = []
    number_LIG_wat                  = []
    
    rmsd                            = []
    
    
    number_TOR                      = []
    

    number_prot_atm_wat             = []
    number_lig_atm_wat              = []
    number_water_atm_wat            = []
    number_all_atm_wat              = []
    number_active_atm_wat           = []
    
    no_binding_list                    = []
    
    my_list_scoring_functions = []
    
    # Sandres information
    my_line_info_about_sandres = "SAnDReS " 
    
    # Read STRDIR
    try:
        my_input_csv_file = open("C:\sandres\inputs\strdir.in","r")
        info_in0 = csv.reader(my_input_csv_file) 
    except IOError:
        print("\nI can't find file ",info_in0)
        print("\nPlease check directory and/or file name.")
        input("\nPress enter key to exit program.")
        sys.exit(0)  # Exiting program
    
    # Looping through the input file to get the structure directory
    for line in info_in0:
        if line[0][0:6].upper() == "STRDIR":
            project_dir = line[1].replace(" ","")
            print("\nAll structures and input files should be in the directory: ",project_dir)
        elif line[0][0:1] == "#":
            continue    # Do nothing
        else:
            sandres_line = "Unrecognizible command"
            print(sandres_line)
            ##sandres_log_file.write (sandres_line+"\n")
            sys.exit()
    
    
    sandres_line = """
  _____               _____  _____       _____ 
 / ____|  /\         |  __ \|  __ \     / ____|
| (___   /  \   _ __ | |  | | |__) |___| (___  
 \___ \ / /\ \ | '_ \| |  | |  _  // _ \\___  \ 
 ____) / ____ \| | | | |__| | | \ \  __/____) )
|_____/_/    \_\_| |_|_____/|_|  \_\___|_____/ 
                                               
Statistical Analysis of Docking Results and Scoring functions

Written by Walter F. de Azevedo Jr. 
with help from
Mariana M. Xavier, Gabriela Sehnem Heck, 
Mauricio B. de Avila, Nayara M. Bernhardt Levin, 
Val de Oliveira Pintro, and Nathalia L. Carvalho.
                          """
    
    sandres_line = "\n\nCurrent Project Directory: "+project_dir+"\n"
    print(sandres_line)

    #input_name = None
    eof_flag = False
    
    # Import script input2run.py
    # import input2run 
    my_sandres_in = open(project_dir+"sandres.in","r")
    my_sandres_in_input_file = my_sandres_in.read()
       
    input_name = my_sandres_in_input_file
        
    # Start MAJOR while loop (here March 11th 2015)
    while input_name != "quit()":
         
        # Finishes if quit()
        if input_name == "quit()":
            print("\nquit() has been requested!")
            print("Finishing SAnDReS!")
            sys.exit()
        
        # Read STRDIR
        elif input_name.upper() == "STRDIR":
            # Set strucurure dir information
            info_in1 = "STRDIR,"+project_dir
            
            # Read STRDIR
            try:
                my_input_csv_file = open("C:\sandres\inputs\strdir.in","r")
                info_in1 = csv.reader(my_input_csv_file) 
            except IOError:
                print("\nI can't find file ",info_in0)
                print("\nPlease check directory and/or file name.")
                input("\nPress enter key to exit program.")
                sys.exit(0)  # Exiting program
            my_input_csv_file.close()
            
        # Read command file
        elif "showinfo.in" in input_name:
            try:
                # Assigns the content of the input_file to info_in1
                my_input_csv_file = open("c:\sandres\inputs\showinfo.in","r")
                info_in1 = csv.reader(my_input_csv_file) 
                #my_input_csv_file.close()
            except IOError:
                print("\nI can't find file ",input_name)
                print("\nPlease check directory and/or file name.")
                input("\nPress enter key to exit program.")
                sys.exit(0)  # Exiting program
        # Read command file
        elif ".in" in input_name:
            try:
                # Assigns the content of the input_file to info_in1
                my_input_csv_file = open(project_dir+input_name,"r")
                info_in1 = csv.reader(my_input_csv_file) 
                #my_input_csv_file.close()
            except IOError:
                print("\nI can't find file ",input_name)
                print("\nPlease check directory and/or file name.")
                input("\nPress enter key to exit program.")
                sys.exit(0)  # Exiting program
        else:
            info_in1 = input_name.replace(" ","")           
        
        # Sets counts to zero
        count_no_atoms_chklig = 0
        count_bio_assemblies = 0
        
        # Assigns initial values for logical variavles
        stdock = False
        chklig = False
        biomat = False
        getstr = False 
        chkstr = False
        stscor = False
        stensembledock = False
        ststru = False
        fndwat = False
        unique = False
        forall = False
        
           
        # Looping through the input file to get the tasks to be carried out
        for line in info_in1:
            if line[0][0:5].upper() == "ENDOF":
                print("\nENDOF has been requested!")
                eof_flag = True
                #my_input_csv_file.close()
            
            # About the program
            elif line[0][0:8].upper() == "SHOWINFO":
                print(my_line_info_about_sandres,end = ": ")
                my_line_info_about_sandres = "Statistical Analysis of Docking Results and Scoring functions"
                              
            # Read STRDIR
            elif line[0][0:6].upper() == "STRDIR":
                print("\nAll structures and input files should be in the directory: ",project_dir)
                new_project_dir_answer = input("\nDo you want to change the structure directory (yes/no)?")
                if new_project_dir_answer.lower() == "yes":
                    project_dir = input("Type new structure directory => ")
                    info_in0 = open("C:\sandres\inputs\strdir.in","w")
                    info_in0.write("STRDIR,"+project_dir.replace(" ",""))
                    info_in0.close()
                    sandres_line = "\n\nCurrent Project Directory: "+project_dir+"\n"
                    print(sandres_line)
                    
                else:
                    print("\nAll structures and input files should be in the directory: ",project_dir)
                
                info_in1 = "ENDOF"
                        
            elif line[0][0:6].upper() == "SPHERE":
                if count_spheres > 10:
                    print("\nWarning number of sphere should be up to 10.")
                else: 
                    radius.append( float(line[1]) )
                    print(line)
                    count_spheres += 1
                       
            elif line[0][0:6].upper() == "STDOCK":
                # Open log file
                sandres_log_file = open(project_dir+"stdock.log","w") 
                if not stdock:
                    sandres_line = "\n\n################################################# STDOCK #################################################"
                    print(sandres_line)
                    sandres_log_file.write (sandres_line+"\n")
                    sandres_line = "\nSTDOCK request. This task calculates Spearman's rank correlation coefficient between docking RMSD and structural parameters."
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                my_PDB_file = line[1].replace(" ","")+".pdb"
                name_PDB.append(my_PDB_file)
                name_LIG.append(line[2].replace(" ",""))
                chain_LIG.append(line[3].replace(" ",""))
                
                # Fix the number of characters
                my_str_4_char = str(line[4].replace(" ",""))
                if len(my_str_4_char)< 5:
                    my_str_lig = str((4-len(my_str_4_char) )*" ")+my_str_4_char
                    number_LIG.append(my_str_lig) # We must have four columns
                else:
                    print("Ligand number should be less than 9999! Please check input file.")
                    sys.exit()
                    
                rmsd.append(float(line[5]))
                number_TOR.append(float(line[6]))
                print(line)
                count_PDB += 1
                stdock = True
                
            elif line[0][0:6].upper() == "CHKLIG":
                # Open log file
                sandres_log_file = open(project_dir+"chklig.log","w") 
                if not chklig:
                    sandres_line = "\n\n################################################# CHKLIG #################################################"
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                    sandres_line = "\nCHKLIG request. This task checks whether information about ligand is correct."
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                my_PDB_file = project_dir+line[1].replace(" ","")+".pdb"
                my_CHKLIG_name = line[2].replace(" ","")  # problems with "  U" and " DA"
                my_CHKLIG_chain = line[3].replace(" ","")
                
                # Fix the number of characters
                my_str_4_char = str(line[4].replace(" ",""))
                if len(my_str_4_char)< 5:
                    my_str_lig = str((4-len(my_str_4_char) )*" ")+my_str_4_char
                    number_LIG.append(my_str_lig) # We must have four columns
                else:
                    print("Ligand number should be less than 9999! Please check input file.")
                    sys.exit()
                
                rmsd.append(None)
                number_TOR.append(None)
                count_PDB += 1
                chklig = True
                
                sandres_line = "\nParsing PDB file: "+my_PDB_file
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                # Instantiates a protein object
                my_protein = ProteinStructure(my_PDB_file)
            
                # Calls make_list_4_prot_atoms() method
                number_prot_atm_in,number_lig_atm_in,number_water_atm_in,number_all_atm_in,number_active_atm_in = my_protein.make_list_of_atoms(my_CHKLIG_name,my_CHKLIG_chain,my_str_lig)
                
                if number_active_atm_in == 0 or number_active_atm_in == None:
                    print("\nWarning! No atoms found for active ligand: ",my_CHKLIG_name,",",my_CHKLIG_chain,",",my_str_lig,"in the file ",my_PDB_file)
                    name_PDB.append(my_PDB_file)
                    name_LIG.append(my_CHKLIG_name)
                    chain_LIG.append(my_CHKLIG_chain)
                    number_LIG.append(my_str_lig) # We must have four columns
                    count_no_atoms_chklig += 1
                else:
                    sandres_line = "\nI found "+str(number_lig_atm_in)+" atoms in the active ligand: "+my_CHKLIG_name+","+my_CHKLIG_chain+","+my_str_lig+" in the file "+my_PDB_file 
                    sandres_log_file.write (sandres_line+"\n")
                    
            elif line[0][0:6].upper() == "GENINP":
                
                # Open log file
                sandres_log_file = open(project_dir+"geninp.log","w") 
                sandres_line = "\n\n################################################# GENINP #################################################"
                print(sandres_line) 
                sandres_log_file.write (sandres_line+"\n")
                sandres_line = "\nGENINP request. \nThis task generates the following input files: ststru.in, fndwat.in, and biomat.in ."
                print(sandres_line) 
                sandres_log_file.write (sandres_line+"\n")
                # Checks whether UNIQUE has been requested
                if line[1][0:6].upper() == "UNIQUE":
                    unique = True
                elif line[1][0:6].upper() == "FORALL":
                    forall = True
                else:
                    print("\nUnrecognizable command!")
                    print("Finishing SAnDReS!")
                    sys.exit()
                
                # Gets file names, sphere radius (A) and maximum number of water molecules
                my_CHKLIG_file = project_dir+line[2].replace(" ","")
                my_STSTRU_file = project_dir+line[3].replace(" ","")
                my_BIOMAT_file = project_dir+line[4].replace(" ","")
                my_FNDWAT_file = project_dir+line[5].replace(" ","")
                my_FNDWAT_radius = line[6].replace(" ","")
                my_FNDWAT_max = line[7].replace(" ","")
                
                # Open chklig.in
                try:
                    foo_chklig = csv.reader(open(my_CHKLIG_file,"r"))
                except IOError:
                    print("\nI can't find file ",my_CHKLIG_file)
                    print("\nPlease check directory and/or file name.")
                    input("\nPress enter key to exit program.")
                    sys.exit(0)  # Exiting program
                
                # Open ststru.in
                try:
                    foo_ststru = open(my_STSTRU_file,"w")
                except IOError:
                    print("\nI can't find file ",my_STSTRU_file)
                    print("\nPlease check directory and/or file name.")
                    input("\nPress enter key to exit program.")
                    sys.exit(0)  # Exiting program
                
                # Open biomat.in
                try:
                    foo_biomat = open(my_BIOMAT_file,"w")
                except IOError:
                    print("\nI can't find file ",my_BIOMAT_file)
                    print("\nPlease check directory and/or file name.")
                    input("\nPress enter key to exit program.")
                    sys.exit(0)  # Exiting program
                
                # Open fndwat.in
                try:
                    foo_fndwat = open(my_FNDWAT_file,"w")
                except IOError:
                    print("\nI can't find file ",my_FNDWAT_file)
                    print("\nPlease check directory and/or file name.")
                    input("\nPress enter key to exit program.")
                    sys.exit(0)  # Exiting program
                              
                # Read chklig.in 
                sandres_line = "\nReading ligand information from "+my_CHKLIG_file
                print(sandres_line)
                #sandres_log_file.write (sandres_line+"\n")  
                count_lines_in_chklig = 0
                my_LIG_RESOL_dict = {}
                my_LIG_PDB_dict = {}
                my_LIG_CHAIN_dict = {}
                my_LIG_NUMBER_dict = {}
                for line in foo_chklig:
                    if line[0][0:6].upper() == "CHKLIG":
                        my_PDB_file_CHKLIG = project_dir+line[1].replace(" ","")+".pdb"
                    
                        # Instantiates a protein object
                        my_protein = ProteinStructure(my_PDB_file_CHKLIG)
                        
                        resolution_PDB = float( my_protein.read_resolution() )
                        
                        my_aux_label_LIG = line[2].replace(" ","")
                        # For UNIQUE we elimiate repeated ligands
                        if unique:
                            if my_aux_label_LIG not in name_LIG_aux:
                                #name_LIG.append(my_aux_label_LIG)
                                my_LIG_RESOL_dict.update({my_aux_label_LIG:resolution_PDB})
                                my_LIG_PDB_dict.update({my_aux_label_LIG:line[1].replace(" ","")})
                                count_lines_in_chklig += 1
                                #name_PDB.append(line[1].replace(" ",""))
                                
                                # Fix the number of characters
                                my_str_4_char = str(line[4].replace(" ",""))
                                if len(my_str_4_char)< 5:
                                    my_str_lig = str((4-len(my_str_4_char) )*" ")+my_str_4_char
                                    #number_LIG.append(my_str_lig) # We must have four columns
                                    my_LIG_NUMBER_dict.update({my_aux_label_LIG:my_str_lig}) 
                                else:
                                    print("Ligand number should be less than 9999! Please check input file.")
                                    sys.exit()
                                my_LIG_CHAIN_dict.update({my_aux_label_LIG:line[3].replace(" ","")})
                                #chain_LIG.append(line[3].replace(" ",""))
                            else:
                                my_current_resolution = resolution_PDB
                                my_old_resolution = my_LIG_RESOL_dict.get(my_aux_label_LIG)
                                my_old_PDB = my_LIG_PDB_dict.get(my_aux_label_LIG)
                                my_old_NUMBER = my_LIG_NUMBER_dict.get(my_aux_label_LIG)
                                my_old_CHAIN = my_LIG_CHAIN_dict.get(my_aux_label_LIG)
                                if my_old_resolution < my_current_resolution:
                                    my_LIG_RESOL_dict.update({my_aux_label_LIG:my_old_resolution})
                                    my_LIG_PDB_dict.update({my_aux_label_LIG:my_old_PDB})
                                    my_LIG_NUMBER_dict.update({my_aux_label_LIG:my_old_NUMBER})
                                    my_LIG_CHAIN_dict.update({my_aux_label_LIG:my_old_CHAIN})
                                else:
                                    my_LIG_RESOL_dict.update({my_aux_label_LIG:resolution_PDB})
                                    my_LIG_PDB_dict.update({my_aux_label_LIG:line[1].replace(" ","")})
                                    # Fix the number of characters
                                    my_str_4_char = str(line[4].replace(" ",""))
                                    if len(my_str_4_char)< 5:
                                        my_str_lig = str((4-len(my_str_4_char) )*" ")+my_str_4_char
                                    my_LIG_NUMBER_dict.update({my_aux_label_LIG:my_str_lig})
                                    my_LIG_CHAIN_dict.update({my_aux_label_LIG:line[3].replace(" ","")})
                            name_LIG_aux.append(my_aux_label_LIG)
                        elif forall:
                            count_lines_in_chklig += 1
                            #name_PDB.append(line[1].replace(" ",""))
                            my_aux_label_LIG = line[2].replace(" ","")
                            #my_LIG_PDB_dict.update({my_aux_label_LIG:line[1].replace(" ","")})
                            #count_lines_in_chklig += 1
                            
                            my_LIG_RESOL_dict.update({my_aux_label_LIG:resolution_PDB})
                            my_LIG_PDB_dict.update({my_aux_label_LIG:line[1].replace(" ","")})
                            count_lines_in_chklig += 1
                            
                            #name_LIG.append(my_aux_label_LIG)
                            
                            # Fix the number of characters
                            my_str_4_char = str(line[4].replace(" ",""))
                            if len(my_str_4_char)< 5:
                                my_str_lig = str((4-len(my_str_4_char) )*" ")+my_str_4_char
                                #number_LIG.append(my_str_lig) # We must have four columns
                                my_LIG_NUMBER_dict.update({my_aux_label_LIG:my_str_lig})
                            else:
                                print("Ligand number should be less than 9999! Please check input file.")
                                sys.exit()   
                            
                            #chain_LIG.append(line[3].replace(" ",""))
                            my_LIG_CHAIN_dict.update({my_aux_label_LIG:line[3].replace(" ","")})
                            name_LIG_aux.append(my_aux_label_LIG)     
                        
                for my_dict_line in my_LIG_RESOL_dict:
                    name_LIG.append(my_dict_line)
                    name_PDB.append(my_LIG_PDB_dict.get(my_dict_line))
                    number_LIG.append(my_LIG_NUMBER_dict.get(my_dict_line))
                    chain_LIG.append(my_LIG_CHAIN_dict.get(my_dict_line))
               
                # Write ststru.in and fndwat.in
                sandres_line = "\nWriting files: \n"+my_STSTRU_file+",\n"+my_FNDWAT_file+", \n"
                print(sandres_line)
                my_local_time = str(time.strftime("%Y_%m_%d_%H_%M_%S"))
                sandres_log_file.write (sandres_line) 
                foo_fndwat.write("WATDIR,"+project_dir+"Dataset_"+my_local_time+"\\\n")    # For Windows 
                count_lines_in_chklig = len(my_LIG_RESOL_dict)
                
                                
                for i_chklig in range(count_lines_in_chklig): 
                    line_out_STSTRU = "STSTRU,"+str(name_PDB[i_chklig])+","+str(name_LIG[i_chklig])+","+str(chain_LIG[i_chklig])+","+str(number_LIG[i_chklig])+"\n" 
                    foo_ststru.write(line_out_STSTRU)  
                    line_out_FNDWAT = "FNDWAT,"+str(name_PDB[i_chklig])+","+str(name_LIG[i_chklig])+","+str(chain_LIG[i_chklig])+","+str(number_LIG[i_chklig])+","+str(my_FNDWAT_radius)+","+str(my_FNDWAT_max)+"\n" 
                    foo_fndwat.write(line_out_FNDWAT)
                    
                foo_ststru.write("ENDOF")
                foo_fndwat.write("ENDOF")
                
                # Write biomat.in
                sandres_line = "and "+my_BIOMAT_file
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n") 
                foo_biomat.write("BIOMAT")
                for i_chklig in my_LIG_RESOL_dict:
                    foo_biomat.write(","+str(my_LIG_PDB_dict.get(i_chklig) ) )  
                foo_biomat.write("\nENDOF")
                
                # Close generated files
                foo_ststru.close()
                foo_biomat.close()
                foo_fndwat.close()
                
            elif line[0][0:6].upper() == "STSTRU":
                # Open log file
                sandres_log_file = open(project_dir+"ststru.log","w")
                sandres_big_csv_file = open(project_dir+"ststru.csv","w") 
                if not ststru:
                    sandres_line = "\n\n######################################################### STSTRU ########################################################"
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                    sandres_line = """\nSTSTRU request. This task shows statistical information about resolution, R-factor, R-free, completeness,
                RMSD deviation from ideal geometry, missing residues, B-value, and occupancy and selects the PDB files that show the highest 
                and the lowest for each of the metioned parameters."""
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                my_PDB_file = project_dir+line[1].replace(" ","")+".pdb"
                count_PDB += 1
                name_PDB.append(my_PDB_file)
                code_PDB.append(line[1].replace(" ",""))
                name_LIG.append(None)
                chain_LIG.append(None)
                number_LIG.append(None) # We must have four columns
                rmsd.append(None)
                number_TOR.append(None)
                ststru = True
            
            elif line[0][0:6].upper() == "STRMSD":
                # Open log file
                sandres_log_file = open(project_dir+"strmsd.log","w") 
                
                # Open csv file
                sandres_csv_file = open(project_dir+"strmsd.csv","w") 
                
                count_records = 2
                strmsd_file1 = project_dir+line[1]
                strmsd_column.append(int(line[count_records]))
                strmsd_info.append(line[count_records+1])
                count_records += 2
                
                # while loop to read each record in the input row
                while True:
                    try:
                        strmsd_column.append(int(line[count_records]))
                        strmsd_info.append(line[count_records+1])
                        count_records += 2
                    except:
                        break
                
                try:
                    # Assigns the content of the input_file to strmsd_foo
                    strmsd_temp = open(strmsd_file1,"r")
                    strmsd_foo = csv.reader(strmsd_temp)
                except:
                    print("\nI can't find file ",strmsd_file1)
                    print("\nPlease check directory and/or file name.")
                    input("\nPress enter key to exit program.")
                    sys.exit(0)  # Exiting program
                
                # Identify the rmsd column using index method
                try:
                    rmsd_index_aux = strmsd_info.index("RMSD")
                    rmsd_index = strmsd_column[rmsd_index_aux]
                except ValueError:
                    print("I can't find RMSD in the list rmsd_index_aux read from CSV file with re-docking results!")
                    print("Finishing SAnDReS")
                    sys.exit()
                
                # Remove rmsd_index from strmsd_column
                strmsd_column.remove(rmsd_index)
                
                # Remove "RMSD" from strmsd_info
                strmsd_info.remove("RMSD")
                
                # Read header line (first line only)
                semicolon_flag = False
                for my_header_line in strmsd_foo:
                    my_header_string = str(my_header_line)
                    if ";" in my_header_string:
                        print("semi-colon")
                        semicolon_flag = True
                        break
                    else:
                        print(my_header_line)
                        break
                
                # If there is semicolon, we change to comma
                if semicolon_flag:
                    
                    # Call get_rid_semicolon:  
                    print("Semicolon")
                    strmsd_temp.close()
                    change2comma(strmsd_file1)
                    
                    # Try to open strmasd_file1
                    try:
                        # Assigns the content of the input_file to strmsd_foo
                        strmsd_foo = csv.reader(open(strmsd_file1,"r"))
                    except:
                        print("\nI can't find file ",strmsd_file1)
                        print("\nPlease check directory and/or file name.")
                        input("\nPress enter key to exit program.")
                        sys.exit(0)  # Exiting program
                    
                    # Shows heders
                    for my_header_line in strmsd_foo:
                        print(my_header_line)
                        break
                    
                # for loop to read csv file
                local_index = 0
                for strmsd_line in strmsd_foo:
                    rmsd_array[0,local_index] =  float(strmsd_line[rmsd_index-1]) # rmsd array
                    score_index = 0
                    for strmsd_aux in strmsd_column:
                        score_array[score_index,local_index] = strmsd_line[strmsd_aux-1]
                        score_index += 1
                    local_index += 1
                count_score_index = score_index
                score_index = 0
                
                # for loop to calculate Spearman's rank correlation coefficient
                sandres_line = "\n\n################################################# STRMSD #################################################"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                sandres_line = "\nSTRMSD request. This task calculates correlation coefficient between docking RMSD and score functions."
                print(sandres_line) 
                sandres_log_file.write (sandres_line+"\n")
                sandres_line = "\nResults for STRMSD"
                print(sandres_line) 
                sandres_log_file.write (sandres_line+"\n")
                score_index = 0
                print("\nPerforming Statistical Analysis...")
                sandres_log_file.write ("\nPerforming Statistical Analysis...\n")
                print("\n\n######################################### Statistical Analysis ##########################################")
                sandres_log_file.write ("\n\n######################################### Statistical Analysis ##########################################\n")
                print("\nCorrelation between docking RMSD and the following variables")
                sandres_log_file.write ("\nCorrelation between docking RMSD and the following scoring functions\n")
                print("Scoring function    RMSD(A)\t Mean(SF)\tStd Dev\t\t rho\tp-value1\t R2\tp-value2")
                sandres_log_file.write ("Scoring function\t\t  RMSD(A)\t Mean(SF)\t  Std Dev\t\t  rho\t p-value1\t\t R2\tp-value2\t\tCSV File\n")   
                for score_index in range(count_score_index):
                    score_list = list(score_array[score_index][0:local_index])
                    rmsd_list = list(rmsd_array[0][0:local_index])
                    stat_info = Spearman(rmsd_list,score_list)
                    min_rmsd_in,ccR_strmsd,ccP_strmsd,my_std_dev,my_pearson,my_pearson_p,my_mean_in  = stat_info.correlation_coefficient()
                    
                    my_pearson_2 = my_pearson*my_pearson
                    
                    # Fix the number of characters
                    my_str = str(score_index)
                    if len(my_str)< 4:
                        my_str = str((3-len(my_str) )*"0")+my_str
                        strmsd_file2 = "strmsd"+my_str+".csv"
                    
                    stat_info.make_csv_file(2,project_dir+strmsd_file2,rmsd_list, score_list   )
                    
                    # Fix the number of characters for scoring functions
                    my_str_info1 = str(strmsd_info[score_index])
                    if len(my_str_info1)< 20:
                        my_str_info2 = my_str_info1+str((19-len(my_str_info1) )*" ")
                    else:
                        my_str_info2 = my_str_info1[0:20]
                    
                    # Try to write information
                    try:
                        line_strmsd1 = my_str_info2+str( "%6.3f\t%6.3e\t%6.3e\t%6.3f\t%6.3e\t%6.3f\t%6.3e"%( min_rmsd_in,my_mean_in,my_std_dev,ccR_strmsd,ccP_strmsd,my_pearson_2,my_pearson_p ))
                        line_strmsd2 = my_str_info2+str( "%6.3f\t\t\t%6.3e\t\t%6.3e\t%6.3f\t%6.3e\t\t%6.3f\t%6.3e\t\t%s"%( min_rmsd_in,my_mean_in,my_std_dev,ccR_strmsd,ccP_strmsd,my_pearson_2,my_pearson_p,strmsd_file2[0:len(strmsd_file2)-4] )+"\n")
                        line_strmsd3 = my_str_info2+str( ",\t%s,\t%6.3f,\t%6.3f"%( strmsd_file2,ccR_strmsd,ccP_strmsd )+"\n")
                        print(line_strmsd1) 
                        sandres_log_file.write(line_strmsd2)  # It was : sandres_log_file.write (my_str_info2)
                        sandres_csv_file.write(line_strmsd3)
                        score_index += 1
                    except TypeError:
                        continue
                
                # Show number of poses
                sandres_line =  "\nNumber of poses in the dataset: "+str( len(rmsd_list))
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                # Show Mean RMSD
                sandres_line = str("Mean RMSD: %6.3f"%(np.mean(rmsd_list)))+" A"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                # Show Median for RMSD
                sandres_line = str("Median for RMSD: %6.3f"%(np.median(rmsd_list)))+" A"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                # Show Standard Deviation for RMSD
                sandres_line = str("Standard deviation for RMSD: %6.3f"%(np.std(rmsd_list)))+" A"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                       
                # Calculate docking accuracy
                count_rmsd_less_than_4 = 0
                count_rmsd_less_than_3 = 0
                count_rmsd_less_than_2 = 0
                count_total_rmsd = len(rmsd_list)
        
                # Looping through rmsd_list (RMSD)
                for rmsd_value in rmsd_list:
                    if (rmsd_value<2.0):
                        count_rmsd_less_than_2 += 1
                        count_rmsd_less_than_3 += 1
                        count_rmsd_less_than_4 += 1
                    elif (rmsd_value<3.0):
                        count_rmsd_less_than_3 += 1
                        count_rmsd_less_than_4 += 1
                    elif (rmsd_value<4.0):
                        count_rmsd_less_than_4 += 1
        
                # Check if count_total_rmsd > 0
                if count_total_rmsd > 0:
                    f_rmsd_a =  count_rmsd_less_than_2/count_total_rmsd
                    f_rmsd_b =  count_rmsd_less_than_3/count_total_rmsd
                    f_rmsd_c =  count_rmsd_less_than_4/count_total_rmsd
                    da1 = f_rmsd_a + 0.5*(f_rmsd_b - f_rmsd_a)
                    extda1 = da1+ 0.25*(f_rmsd_c - f_rmsd_b)
                    
                    perc_extda1 = 100*extda1
                    perc_da1 = 100*da1
                    
                    # Show Extended Docking Accuracy
                    sandres_line = str("\nDA1(2,3): %6.3f"%(perc_da1))+" %"
                    print(sandres_line)
                    sandres_log_file.write (sandres_line+"\n")
                
                    # Show Extended Docking Accuracy
                    sandres_line = str("DA2(2,3,4): %6.3f"%(perc_extda1))+" %"
                    print(sandres_line)
                    sandres_log_file.write (sandres_line+"\n")
                    
                    sandres_line = "\nDA1(2,3) = f_a + 0.5(f_b - f_a)"
                    print(sandres_line)
                    sandres_log_file.write (sandres_line+"\n")
                    sandres_line = "where DA1(2,3) is the docking accuracy, \nf_a is the fraction of poses for which the docking RMSD is less than  2 A,"
                    print(sandres_line)
                    sandres_log_file.write (sandres_line+"\n")
                    sandres_line = "and f_b is the fraction of poses for which the docking RMSD is less than  3 A."
                    print(sandres_line)
                    sandres_log_file.write (sandres_line+"\n")
                    
                    sandres_line = "\nDA2(2,3,4) = DA1(2,3) + 0.25(f_c - f_b)"
                    print(sandres_line)
                    sandres_log_file.write (sandres_line+"\n")
                    sandres_line = "where DA2(2,3,4) is the extended docking accuracy and"
                    print(sandres_line)
                    sandres_log_file.write (sandres_line+"\n")
                    sandres_line = "and f_c is the fraction of poses for which the docking RMSD is less than  4 A."
                    print(sandres_line)
                    sandres_log_file.write (sandres_line+"\n")
                    
                sandres_line = "\nRMSD is the RMSD for the lowest scoring function value"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                sandres_line = "Mean(SF) is the mean value for the scoring function values"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                sandres_line = "Std Def is the standard deviation for the scoring function values"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                sandres_line = "rho is Spearman rank-order correlation coefficient"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                sandres_line = "p-value1 is for rho"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                sandres_line = "R2 is the squared Pearson correlation coefficient"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                sandres_line = "p-value2 is for R2"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                sandres_line = "\n\nAnalysis finished here for STRMSD request!" 
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                # Close files
                sandres_log_file.close()
                sandres_csv_file.close()
                
                
            elif line[0][0:6].upper() == "WATDIR":
                water_dir_aux = line[1][0:].replace(" ","") # Get rid of any " "
                water_dir = water_dir_aux   # Don't Addd one " " at the end
            
            elif line[0][0:6] == "FNDWAT":
                # Open log file
                sandres_log_file = open(project_dir+"fndwat.log","w") 
                if not fndwat:
                    sandres_line = "\n\n######################################################### FNDWAT ########################################################"
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                    sandres_line = "\nFNDWAT request. This task generates a PDB file for protein structure, ligand and water molecules close to the ligand."
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                aux_wat_pdb = line[1].replace(" ","")+".pdb"
                aux_wat = project_dir+line[1].replace(" ","")+".pdb"
                name_PDB_wat.append(aux_wat)
                name_PDB_wat_sphere.append(aux_wat_pdb)
                name_LIG_wat.append(line[2].replace(" ",""))
                chain_LIG_wat.append(line[3].replace(" ",""))
                
                # Fix the number of characters
                my_str_4_char = str(line[4].replace(" ",""))
                if len(my_str_4_char)< 5:
                    my_str_lig = str((4-len(my_str_4_char) )*" ")+my_str_4_char
                    number_LIG_wat.append(my_str_lig) # We must have four columns
                else:
                    print("Ligand number should be less than 9999! Please check input file.")
                    sys.exit()
                
                radius_wat.append( float(line[5]) )
                max_number_wat.append(int(line[6]))
                print(line)
                count_PDB_wat += 1   
                fndwat = True
                
            elif line[0][0:6].upper() == "BIOMAT":
                # Open log file
                sandres_log_file = open(project_dir+"biomat.log","w") 
                count_BIOMAT_lines = 0
                if not biomat:
                    sandres_line = "\n\n################################################# BIOMAT #################################################"
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                    sandres_line = "\nBIOMAT request. This task checks BIOMAT presence and generates biological assembly."
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                for aux_biomat_line in line[1:]:
                    count_BIOMAT_lines += 1
                    biomat_line = aux_biomat_line.replace(" ","")
                    my_PDB_biomat = project_dir+biomat_line[0:4]+".pdb"
                    sandres_line = "\nChecking PDB "+my_PDB_biomat+" for Bio-matrix..."
                    print(sandres_line)
                    sandres_log_file.write (sandres_line+"\n")
                    my_protein_biomat = ProteinStructure(my_PDB_biomat)
                    check_bio_assembly = my_protein_biomat.genBioMat(biomat_line[0:4],project_dir)
                    if check_bio_assembly:
                        count_bio_assemblies += 1 
                        name_PDB.append(my_PDB_biomat)
                biomat = True
            elif line[0][0:8].upper() == "POLSCORE":
                #polscore_dir = project_dir+"\\Polscore\\"
                polscore_csv_file_in = line[1]
                selected_mlr_method = line[3].replace(" ","")
                polscore_path_in = sandres_root
                polscore(polscore_csv_file_in,int(line[2]),polscore_path_in,project_dir,selected_mlr_method)
                
            elif line[0][0:7].upper() == "GETBIND":
                
                # Set empty list
                no_download_list = []
                
                # Open log file
                sandres_log_file = open(project_dir+"getbind.log","w") 
                
                # Write header to log file
                sandres_line = "\n\n################################################# GETBIND ################################################"
                print(sandres_line) 
                sandres_log_file.write (sandres_line+"\n")
                sandres_line = "\nGETBIND request. This task downloads binding affinity information ("+line[1]+") from www.rcsb.org/pdb."
                print(sandres_line) 
                sandres_log_file.write (sandres_line+"\n")
            
                # Get binding affinity type
                binding_info_in = line[1].upper()
                
                # Looping pdb access codes
                count_pdb_2_download = 0
                count_pdb_in_dir = 0
                for my_pdb_lines in line[2:]:
                    structureId_in = my_pdb_lines.lower() 
                    count_pdb_2_download += 1
                    
                    # Call getBind
                    my_getBind_flag = getBind(project_dir,structureId_in,binding_info_in)
                    
                    if my_getBind_flag:
                        sandres_line = "\nIgnoring download request for " +structureId_in+".csv file!\n"
                        print(sandres_line)
                        sandres_log_file.write (sandres_line+"\n")
                        no_download_list.append(structureId_in)
                        count_pdb_in_dir += 1
                    else:
                        sandres_line = "\n "+structureId_in+".csv file downloaded from http://www.rcsb.org/!\n"
                        print(sandres_line)
                        sandres_log_file.write (sandres_line+"\n")
                
                sandres_line = "\n######################################################################" 
                print(sandres_line)
                sandres_log_file.write (sandres_line)
                sandres_line = "\nSummary of results for GETBIND:\n"
                print(sandres_line)
                sandres_log_file.write (sandres_line) 
                sandres_line = "Structure directory: "+project_dir+"\n"
                print(sandres_line)
                sandres_log_file.write (sandres_line)
                my_unit_in = getUnits(binding_info_in)
                sandres_line = "\nType of binding information: "+line[1]+my_unit_in+"\n"
                print(sandres_line)
                sandres_log_file.write (sandres_line)
                sandres_line = "Total number of requests for downloading: "+str(count_pdb_2_download )+"\n"
                print(sandres_line)
                sandres_log_file.write (sandres_line)
                sandres_line = "Total number of files found in the structure directory: "+str( count_pdb_in_dir )+"\n"
                print(sandres_line)
                sandres_log_file.write (sandres_line)
                sandres_line = "Total number of files download from http://www.rcsb.org/: "+str(count_pdb_2_download - count_pdb_in_dir)+"\n"
                print(sandres_line)
                sandres_log_file.write (sandres_line)           
                sandres_line = "######################################################################"
                print(sandres_line)
                sandres_log_file.write (sandres_line)
                sandres_line = "\n\nAnalysis finished here for GETBIND request!"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                        
                sandres_log_file.close()
                
            elif line[0][0:6].upper() == "GETSTR" or line[0][0:6].upper() == "NEWGET":
                # Open log file
                sandres_log_file = open(project_dir+"getstr.log","a") 
                if not getstr:
                    sandres_line = "\n\n################################################# GETSTR #################################################"
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                    sandres_line = "\nGETSTR request. This task downloads structures from www.rcsb.org/pdb."
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                format_in = line[1].replace(" ","")
                for aux_getstr_line in line[2:]:
                    getstr_line = aux_getstr_line.replace(" ","")
                    check_getstr = getSTR(getstr_line,format_in,project_dir) 
                    if check_getstr:
                        name_PDB.append(getstr_line)
                    else:
                        name_no_PDB.append(getstr_line) 
                getstr = True
                
                # Defintion of my type of affinities
                my_type_of_aff = ["ic50","ki","kd","ec50","deltag","deltah","ka"]
                
                # Check to write new chkstr.in for PDB format only
                if format_in == "PDB" and line[0][0:6].upper() == "GETSTR":
                    # Looping through my_type_of_aff
                    for type_aff in my_type_of_aff:
                        # Open input file chkstr.in
                        my_chkstr_foo = open(project_dir+"chkstr_"+type_aff+".in","w")
                        my_chkstr_foo.write("CHKSTR,"+type_aff.upper())                  
                        for line in name_PDB:
                            my_chkstr_foo.write(","+line)
                        my_chkstr_foo.write("\nENDOF")
                        my_chkstr_foo.close()
                        print("\nA total of ",len(name_PDB),"PDB access codes have been written to chkstr_"+type_aff+".in\n")
                
            elif line[0][0:6].upper() == "CHKSTR":
                # Open log file
                sandres_log_file = open(project_dir+"chkstr.log","w") 
            
                # Set counts to zero
                count_chkstr = 0
                count_no_binding_info = 0
                count_no_structure = 0
                
                if not chkstr:
                    sandres_line = "\n\n################################################# CHKSTR #################################################"
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                    sandres_line = "\nCHKSTR request. \nThis task checks whether structures are in the directory "+project_dir+".\n"
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                format_in = line[1].replace(" ","")
                
                for aux_chkstr_line in line[2:]:
                    count_chkstr += 1
                    chkstr_line = aux_chkstr_line.replace(" ","")
                    if format_in.upper() == "IC50":
                        sandres_line = "\nChecking if "+chkstr_line[0:4].upper()+" is in the structure directory..."
                        sandres_log_file.write (sandres_line+"\n")
                        check_chkstr,no_binding_code = chkSTR(chkstr_line[0:4].lower(),format_in,project_dir)
                       
                        if no_binding_code != None:
                            no_binding_list.append(no_binding_code)
                            count_no_binding_info += 1
                    else:    
                        sandres_line = "\nChecking if "+chkstr_line.upper()+" is in the structure directory..."
                        sandres_log_file.write (sandres_line+"\n")
                        check_chkstr, no_binding_code = chkSTR(chkstr_line,format_in,project_dir)
                        
                        if no_binding_code != None:
                            no_binding_list.append(no_binding_code)
                            count_no_binding_info += 1
                    if check_chkstr:
                        name_PDB.append(chkstr_line)
                    else:
                        count_no_structure += 1
                        name_no_PDB.append(chkstr_line)
                        sandres_line = "\nOK. The file "+chkstr_line+" is not in the structure directory."
                        print(sandres_line)
                        sandres_log_file.write (sandres_line+"\n")
                        sandres_line = "Trying to download "+chkstr_line+" from http://www.rcsb.org/pdb/files/"
                        print(sandres_line)
                        sandres_log_file.write (sandres_line+"\n")
                        check_getstr = getSTR(chkstr_line[0:4],format_in,project_dir)
                chkstr = True
            
            elif line[0][0:6].upper() == "CUTOFF":
                cutoff_criteria_aux = line[1][0:4].upper()
                cutoff_criteria = cutoff_criteria_aux.replace(" ","")
                if cutoff_criteria == "RMSD":
                    rmsd_cutoff = float(line[2])
                elif cutoff_criteria == "NTOR":
                    ntor_cutoff = int(line[2])
                else:
                    print("Unrecognizeble command. Finishing program!")
                    sys.exit()
            
            elif line[0][0:10].upper() == "FACTORXLOG":
                log_factor = 1  # Default value to avoid surprises
                log_criteria_aux = line[1][0:6].upper()
                log_criteria = log_criteria_aux.replace(" ","")
                if log_criteria == "LOG(C)":
                    log_factor = 1.0
                else:
                    log_factor = -1.0
            elif line[0][0:9] == "SCOREFUNC":
                for line1 in line[1:]:
                    # Fix the number of characters in the output file name
                    my_str = str(line1)
                    if len(my_str)< 20:
                        my_str1 = my_str+str((19-len(my_str) )*" ")
                    my_list_scoring_functions.append(my_str1) 
                print(my_list_scoring_functions)
                
            elif line[0][0:14].upper() == "STENSEMBLEDOCK": 
                if not stensembledock:
                    # Open log file
                    sandres_log_file = open(project_dir+"stensembledock.log","w") 
                    sandres_line = "\n\n############################################### STENSEMBLEDOCK ##############################################"
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                    sandres_line = "\nSTENSEMBLEDOCK request. This task calculates Spearman's rank correlation coefficient between RMSD and scoring functions!"
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                if (cutoff_criteria[0:4] == "RMSD") and (float(line[5]) < float(rmsd_cutoff) ):
                    rmsd_in = line[5].replace(" ","")         
                    rmsd_in1 = float(rmsd_in)
                    new_rmsd_array[count_PDB] = rmsd_in1  
                    count_scoring_functions = 0
                    for aux_stensembledock_line in line[7:]:
                        stensembledock_line = aux_stensembledock_line.replace(" ","")
                        float_stensembledock = float(stensembledock_line)
                        score_array[count_scoring_functions,count_PDB] = float_stensembledock
                        count_scoring_functions += 1
                    count_PDB += 1
                elif (cutoff_criteria[0:4] == "NTOR") and (int(line[6]) <= ntor_cutoff) :
                    rmsd_in = line[5].replace(" ","")
                    rmsd_in1 = float(rmsd_in)
                    new_rmsd_array[count_PDB] = float(rmsd_in1) 
                    count_scoring_functions = 0
                    for aux_stensembledock_line in line[7:]:
                        stensembledock_line = aux_stensembledock_line.replace(" ","")
                        float_stensembledock = float(stensembledock_line)
                        score_array[count_scoring_functions,count_PDB] = float_stensembledock
                        count_scoring_functions += 1
                    count_PDB += 1
                    
                stensembledock = True
            elif line[0][0:6].upper() == "STSCOR": 
                if not stscor:
                    # Open log file
                    sandres_log_file = open(project_dir+"stscor.log","w") 
                    sandres_line = "\n\n################################################# STSCOR #################################################"
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                    sandres_line = "\nSTSCOR request. This task calculates Spearman's rank correlation coefficient between Log10(experimental binding) and scoring functions!"
                    print(sandres_line) 
                    sandres_log_file.write (sandres_line+"\n")
                # Here we have torsions or RMSD NEVER both line[6] will be used for either one or another
                if (cutoff_criteria[0:4] == "RMSD") and (float(line[6]) < float(rmsd_cutoff) ):
                    expBinding_in = line[5].replace(" ","")         
                    expBinding_in1 = float(expBinding_in)
                    expBindingArray[count_PDB] = log_factor*( -9 + math.log10(expBinding_in1) ) # We consider that IC50, Ki and Kd are in nM 
                    count_scoring_functions = 0
                    for aux_stscor_line in line[7:]:
                        stscor_line = aux_stscor_line.replace(" ","")
                        float_stscor = float(stscor_line)
                        score_array[count_scoring_functions,count_PDB] = float_stscor
                        count_scoring_functions += 1
                    count_PDB += 1
                elif (cutoff_criteria[0:4] == "NTOR") and (int(line[6]) <= ntor_cutoff) :
                    expBinding_in = line[5].replace(" ","")
                    expBinding_in1 = float(expBinding_in)
                    expBindingArray[count_PDB] = log_factor*(-9 + math.log10(float(expBinding_in1)) ) 
                    count_scoring_functions = 0
                    
                    for aux_stscor_line in line[7:]:
                        stscor_line = aux_stscor_line.replace(" ","")
                        float_stscor = float(stscor_line)
                        score_array[count_scoring_functions,count_PDB] = float_stscor
                        count_scoring_functions += 1
                    count_PDB += 1
                    
                stscor = True
            elif line[0][0:6].upper() == "PLTCSV": 
                my_pltcsv_log = open(project_dir+"pltcsv.log","a"  )
                sandres_line = "\n\n################################################# PLTCSV ################################################"
                print(sandres_line)
                my_pltcsv_log.write (sandres_line+"\n")
                input_csv_file_name = project_dir+line[1][0:].replace(" ","")
                root_input_csv_file = line[1].replace(".csv","") # Remove ".csv" to have a root file name
                
                try:
                    # Assigns the content of the input_csv_file_name to my_csv_file
                    my_file_in_csv = open(input_csv_file_name,"r")
                    my_csv_file = csv.reader(my_file_in_csv)
                except IOError:
                    print("\nI can't find file ",input_csv_file_name)
                    print("\nPlease check directory and/or file name.")
                    input("\nPress enter key to exit program.")
                    sys.exit(0)  # Exiting program    
                        
                type_of_plot = line[2][0:].replace(" ","")
                    
                # Enters of plots
                list_of_types_of_plots = ["HISTOGR","SCATTER","PLOT","PLOTMIN","PLOTPDB","PLOTALL"]
                while (type_of_plot.upper() not in list_of_types_of_plots):
                    print("Invalid choice!")
                    type_of_plot = input("\nEnter the plot to be created (HISTOGR for histogram and SCATTER for scatter plot) => ")
                           
                if type_of_plot.upper() == "SCATTER" or type_of_plot.upper() == "PLOT" or type_of_plot.upper() == "PLOTMIN" or type_of_plot.upper() == "PLOTPDB" or type_of_plot.upper() == "PLOTALL":
                    # Looping through to read .csv file, lines are assigned to numpy arrays my_array1 and my_array2 
                    count_lines_plt = 0
                    for line_plt in my_csv_file:
                        if type_of_plot.upper() != "PLOTPDB" and type_of_plot.upper() != "PLOTALL":
                            my_array1[count_lines_plt] = line_plt[0]
                            my_array2[count_lines_plt] = line_plt[1]    
                            count_lines_plt += 1
    
                            # Uses max and min to get maximum and minimum values in the arrays
                            x_min_lim = np.min(my_array1[0:count_lines_plt])
                            x_max_lim = np.max(my_array1[0:count_lines_plt])
                            y_min_lim = np.min(my_array2[0:count_lines_plt]) 
                            y_max_lim = np.max(my_array2[0:count_lines_plt])
        
                            # Read information necessary for the plot
                            x_min   = float(line[3][0:])
                            if x_min == "":
                                x_min = x_min_lim
                            x_max   = float(line[4][0:])
                            if x_max == "":
                                x_max = x_max_lim
                            y_min   = float(line[5][0:])
                            if y_min == "":
                                y_min = y_min_lim 
                            y_max   = float(line[6][0:])
                            if y_max == "":
                                y_max = y_max_lim 
                        
                        x_label = line[7][0:].strip() # get rid of space in the beggining and at the end of the string
                        if x_label == "":
                            x_label = "X-axis" 
                        y_label = line[8][0:].strip() # get rid of space in the beggining and at the end of the string
                        if y_label == "": 
                            y_label = "Y-axis" 
                        plot_title = line[9][0:].strip() # get rid of space in the beggining and at the end of the string
                    my_file_in_csv.close()    
                    # Pre-defined markers
                    # "." Point marker
                    # "," Pixel marker
                    # "o" Circle marker
                    # "v" Triangle down marker
                    # "^" Triangle up marker 
                    # "<" Triangle left marker
                    # ">" Triangle right marker
                    # "1" Tripod down marker
                    # "2" Tripod up marker
                    # "3" Tripod left marker
                    # "4" Tripod right marker 
                    # "s" Square marker
                    # "p" Pentagon marker
                    # "*" Star marker
                    # "h" Hexagon marker
                    # "H" Rotated hexagon marker
                    # "+" Plus marker
                    # "x" Cross marker
                    # "D" Diamond marker
                    # "d" Thin diamond marker
                    # "|" Vertical line marker
                    # "-" Horizontal line marker
                    defined_markers = [".",",","o", "v","^","<",">","1","2","3","4","s","p","*","h","H","+","x","D","d","|","-"]
                    type_of_marker =  line[10][0:].replace(" ","")
                    if type_of_marker in defined_markers:
                        sandres_line = "Selected type of marker => "+type_of_marker 
                        print(sandres_line)
                        my_pltcsv_log.write (sandres_line+"\n")
                    else:
                        sandres_line = "\nI didn't recognize the type of marker you gave. I will use + ."
                        print(sandres_line)
                        my_pltcsv_log.write (sandres_line+"\n")
                        type_of_marker = "+"
                    
                    plt_color = str(  line[11][0:].replace(" ","")   )
                    
                    # Plot output formats:'svgz': 'Scalable Vector Graphics', 'ps': 'Postscript', 'emf': 'Enhanced Metafile', 'rgba': 'Raw RGBA bitmap','raw': 'Raw RGBA bitmap',
                    #                     'pdf': 'Portable Document Format', 'svg': 'Scalable Vector Graphics', 'eps': 'Encapsulated Postscript', 'png': 'Portable Network Graphics'
                    plt_output_format = str(  line[12][0:].replace(" ","")   )
                    # Class StatAnalysis to instantiate an object
                    #csv_info = StatAnalysis(my_array1[0:count_lines_plt],my_array2[0:count_lines_plt]) 
                    if type_of_plot.upper() == "SCATTER":
                        # Class StatAnalysis to instantiate an object
                        csv_info = StatAnalysis(my_array1[0:count_lines_plt],my_array2[0:count_lines_plt])            
                        
                        # Least-squares polynomial fitting 
                        poly_deg = int(line[13])
                        
                        if line[14].upper() == "TEXT":
                            my_var_grid_aux = line[17]
                            my_dpi_var = int(line[18])
                            my_maker_size = float(line[19])
                            
                        else:
                            my_var_grid_aux = line[15]
                            my_dpi_var = int(line[16])
                            my_maker_size = float(line[17])
                        
                        print(my_var_grid_aux)
                        
                        if my_var_grid_aux == "False":
                            my_var_grid = False
                        else:
                            my_var_grid = True
                            
                        # Class StatAnalysis to instantiate an object
                        #csv_info = StatAnalysis(my_array1[0:count_lines_plt],my_array2[0:count_lines_plt])
        
                        # correlation_coefficient is a method applied to the object csv_info
                        ccR_plt,ccP_plt   = csv_info.correlation_coefficient()
                        # Checks if cc1_in is not a number
                        if "nan" in str(ccR_plt):
                            print("Not plotting this one...")
                            return          # Returns without plot
                        if ccR_plt >= 10.0:
                            print("Not plotting this one...")
                            return          # Returns without plot
                        
                        if line[14].upper() == "TEXT":      
                            fig_x = float(line[15])
                            fig_y = float(line[16])
                            # scatter_plot is a method applied to the object csv_info 
                            #scatter_plot(self,x_axis,y_axis,plot_title,x_min,x_max,y_min,y_max,size_markers,point_color,marker_value,plt_format,trans,dpi_value,project_dir_in,poly_deg_in,root_input_csv_file_in,type_of_plot_in,flag_text,fig_x_in,fig_y_in,cc1_in,pvalue1_in):
                            my_polynomial_eq = csv_info.scatter_plot(x_label,y_label,plot_title,x_min,x_max,y_min,y_max,my_maker_size,plt_color[0:1],type_of_marker,plt_output_format,my_var_grid,my_dpi_var,project_dir,poly_deg,root_input_csv_file,type_of_plot,"TEXT",fig_x,fig_y,ccR_plt,ccP_plt)
                        else:
                            fig_x = None
                            fig_y = None
                            # scatter_plot is a method applied to the object csv_info 
                            my_polynomial_eq = csv_info.scatter_plot(x_label,y_label,plot_title,x_min,x_max,y_min,y_max,my_maker_size,plt_color[0:1],type_of_marker,plt_output_format,my_var_grid,my_dpi_var,project_dir,poly_deg,root_input_csv_file,type_of_plot,"NOTEXT",fig_x,fig_y,ccR_plt,ccP_plt)
                    
                    # Takes care of plotting second column of pre-docking analysis
                    elif type_of_plot.upper() == "PLOTPDB":
                        
                        try:
                            # Assigns the content of the input_csv_file_name to my_csv_file
                            my_file_in_csv = open(input_csv_file_name,"r")
                            my_csv_file = csv.reader(my_file_in_csv)
                        except IOError:
                            print("\nI can't find file ",input_csv_file_name)
                            print("\nPlease check directory and/or file name.")
                            input("\nPress enter key to exit program.")
                            sys.exit(0)  # Exiting program    
                            
                        # Looping through csv_file for option PLOTPDB
                        count_lines_plt = 0
                        for line_plt in my_csv_file:
                            my_array1[count_lines_plt] = count_lines_plt
                            my_array2[count_lines_plt] = line_plt[1]   
                            count_lines_plt += 1
                        
                        x_max   = float(line[4][0:])
                        y_min   = float(line[5][0:])
                        y_max   = float(line[6][0:])
                        plt_color = str(  line[11][0:].replace(" ","")   )
                        type_of_marker =  line[10][0:].replace(" ","")
                        plt_output_format = str(  line[12][0:].replace(" ","")   )
                        csv_info = StatAnalysis(my_array1[0:count_lines_plt],my_array2[0:count_lines_plt]) 
                         
                        poly_deg = 0
                        
                        if line[14].upper() == "TEXT":      
                            print("SAnDReS Error! TEXT option Not valid for pltcsv1A.in! Please change to NOTEXT in pltcsv1A.csv!")
                        else:
                            fig_x = None
                            fig_y = None
                            ccR_plt = 0.0
                            ccP_plt = 0.0
                            # scatter_plot is a method applied to the object csv_info 
                            #my_polynomial_eq = csv_info.scatter_plot(x_label,y_label,plot_title,x_min,x_max,y_min,y_max,50,plt_color[0:1],type_of_marker,plt_output_format,True,1000,project_dir,poly_deg,root_input_csv_file,type_of_plot,"NOTEXT",fig_x,fig_y,ccR_plt,ccP_plt)
                            # scatter_plot is a method applied to the object csv_info 
                            my_polynomial_eq = csv_info.scatter_plot(x_label,y_label,plot_title,0,x_max,y_min,y_max,50,plt_color[0:1],type_of_marker,plt_output_format,True,1000,project_dir,0,root_input_csv_file,type_of_plot,"NOTEXT",fig_x,fig_y,ccR_plt,ccP_plt)
                       
                    # Takes care of multiple different plots without legends
                    elif type_of_plot.upper() == "PLOTALL":
                        
                        try:
                            # Assigns the content of the input_csv_file_name to my_csv_file
                            my_file_in_csv = open(input_csv_file_name,"r")
                            my_csv_file = csv.reader(my_file_in_csv)
                        except IOError:
                            print("\nI can't find file ",input_csv_file_name)
                            print("\nPlease check directory and/or file name.")
                            input("\nPress enter key to exit program.")
                            sys.exit(0)  # Exiting program    
                            
                        # Looping through csv_file for option PLOTALL to read first line to get number of columns
                        for line_plt in my_csv_file:
                            my_number_of_columns = len(line_plt)
                            print("My Number of columns ",my_number_of_columns)
                            break   
                        
                        my_file_in_csv.close()
                        
                        # Assigns the content of the input_csv_file_name to my_csv_file
                        my_file_in_csv = open(input_csv_file_name,"r")
                        my_csv_file = csv.reader(my_file_in_csv) 
                        
                        # Looping through csv_file for option PLOTALL to read first line to get number of columns
                        count_lines_plt = 0
                        for line_plt in my_csv_file:
                            for my_col in range(my_number_of_columns):
                                my_mult_array[my_col,count_lines_plt] = line_plt[my_col]
                            count_lines_plt += 1
                        
                        for my_col in range(my_number_of_columns):
                            for my_line in range(count_lines_plt):
                                print(my_mult_array[my_col,my_line])
                                
                        x_min   = float(line[3][0:])
                        x_max   = float(line[4][0:])
                        y_min   = float(line[5][0:])
                        y_max   = float(line[6][0:])
                        plt_color = str(  line[11][0:].replace(" ","")   )
                        type_of_marker =  line[10][0:].replace(" ","")
                        plt_output_format = str(  line[12][0:].replace(" ","")   )
                         
                         
                        poly_deg = 0
                        # scatter_plot is a method applied to the object csv_info 
                        #my_polynomial_eq = csv_info.scatter_plot(x_label,y_label,plot_title,0,x_max,y_min,y_max,50,plt_color[0:1],type_of_marker,plt_output_format,True,1000,project_dir,0,root_input_csv_file,type_of_plot)
                        
                        csv_info = MultStatAnalysis(my_mult_array[0][0:count_lines_plt],my_mult_array[1][0:count_lines_plt],my_mult_array[2][0:count_lines_plt],my_mult_array[3][0:count_lines_plt],
                                                    my_mult_array[4][0:count_lines_plt],my_mult_array[5][0:count_lines_plt],my_mult_array[6][0:count_lines_plt],my_mult_array[7][0:count_lines_plt],
                                                    my_mult_array[8][0:count_lines_plt],my_mult_array[9][0:count_lines_plt],my_number_of_columns   )      
                            
                        # Defines an empty legend_list since MPLTCSV takes care of multiple curves in one plot
                        legend_list = []
                        csv_info.mult_scatter_plot(x_label,y_label,plot_title,x_min,x_max,y_min,y_max,50,plt_color[0:1],type_of_marker,plt_output_format,True,1000,project_dir,poly_deg,root_input_csv_file,type_of_plot,False,legend_list)                                                                
                    else:
                        # Class StatAnalysis to instantiate an object
                        csv_info = StatAnalysis(my_array1[0:count_lines_plt],my_array2[0:count_lines_plt])
                        poly_deg = 0
                        # scatter_plot is a method applied to the object csv_info 
                        my_polynomial_eq = csv_info.scatter_plot(x_label,y_label,plot_title,x_min,x_max,y_min,y_max,50,plt_color[0:1],type_of_marker,plt_output_format,True,1000,project_dir,poly_deg,root_input_csv_file,type_of_plot)
                        
                    sandres_line = "\nGenerating plot "+project_dir+root_input_csv_file+"."+plt_output_format.lower()
                    print(sandres_line)
                    my_pltcsv_log.write (sandres_line+"\n")
                           
                    # Shows results after plotting
                    if poly_deg > 0 and type_of_plot == "SCATTER":
                        sandres_line = "\nLeast-squares polynomial equation: "+str(my_polynomial_eq)
                        print(sandres_line)
                        my_pltcsv_log.write (sandres_line+"\n")
                        
                elif type_of_plot.upper() == "HISTOGR":
            
                    # Checks which column to plot
                    column = int(line[3][0:])
            
                    # Looping through to read .csv file, lines are assigned to numpy array my_array 
                    count_lines_plt = 0
                    for line_plt in my_csv_file: 
                        my_array2[count_lines_plt] = line_plt[column-1] 
                        count_lines_plt += 1
                        
                    # Uses max and min to get maximum and minimum values in the arrays
                    x_min_lim = np.min(my_array2[0:count_lines_plt])
                    x_max_lim = np.max(my_array2[0:count_lines_plt])
                    y_min_lim = 0 
                    y_max_lim = int(len(my_array2)/10)
                        
                    # Shows overall information read from .csv file
                    sandres_line = "\nI read "+str(count_lines_plt)+" lines from "+input_csv_file_name
                    print(sandres_line)
                    my_pltcsv_log.write (sandres_line+"\n")
                        
                    # Read information necessary for the plot
                    x_min   = float(line[4][0:])
                    if x_min == "":
                        x_min = x_min_lim
                    else:
                        x_min = float(x_min)
                    x_max   = float(line[5][0:])
                    if x_max == "":
                        x_max = x_max_lim
                    else:
                        x_max = float(x_max)
            
                    y_min = 0   # Only to have a value
                    y_max = 1   # Only to have a value
            
                    x_label = line[6][0:]
                    if x_label == "":
                        x_label = "X-axis" 
                    y_label = line[7][0:]
                    if y_label == "":
                        y_label = "Y-axis" 
                    plt_title = line[8][0:]
                    number_of_bins = int(line[9][0:])
                    plt_color = str(  line[10][0:].replace(" ","")   )
                    type_of_marker = "+"
                    
                    # Plot output formats:'svgz': 'Scalable Vector Graphics', 'ps': 'Postscript', 'emf': 'Enhanced Metafile', 'rgba': 'Raw RGBA bitmap','raw': 'Raw RGBA bitmap',
                    #                     'pdf': 'Portable Document Format', 'svg': 'Scalable Vector Graphics', 'eps': 'Encapsulated Postscript', 'png': 'Portable Network Graphics'
                    plt_output_format = str(  line[11][0:].replace(" ","")   )
                    
                    # Get dpi
                    my_dpi_histo = line[13]
                        
                    sandres_line = "\nGenerating plot "+project_dir+root_input_csv_file+"."+plt_output_format.lower()
                    print(sandres_line)
                    my_pltcsv_log.write (sandres_line+"\n")
            
                    # Class StatAnalysis to instantiate an object
                    csv_info = StatAnalysis(my_array2[0:count_lines_plt],my_array2[0:count_lines_plt])
            
                    # hist_plot is a method applied to the object csv_info
                    csv_info.hist_plot(x_label,y_label,my_array1,my_array2,type_of_plot,number_of_bins,plt_title,x_min,x_max,y_min,y_max,50,"r",type_of_marker,plt_output_format,False,int(my_dpi_histo),plt_color,project_dir,root_input_csv_file)
                
                else:
                    sandres_line = "I didn't recognize the type of plot! \nFinishing running PLTCSV task!"
                    print(sandres_line)
                    my_pltcsv_log.write (sandres_line+"\n")
                    sys.exit()
                
                sandres_line = "\n\nAnalysis finished here for PLTCSV request!"
                print(sandres_line)
                my_pltcsv_log.write (sandres_line+"\n")
                my_pltcsv_log.close()
                
            elif line[0][0:7].upper() == "MPLTCSV": 
                my_mpltcsv_log = open(project_dir+"mpltcsv.log","a"  )
                sandres_line = "\n\n################################################# MPLTCSV ###############################################"
                print(sandres_line)
                my_mpltcsv_log.write (sandres_line+"\n")
                input_csv_file_name = project_dir+line[1][0:].replace(" ","")
                root_input_csv_file = line[1].replace(".csv","") # Remove ".csv" to have a root file name
                
                try:
                    # Assigns the content of the input_csv_file_name to my_csv_file
                    my_file_in_csv = open(input_csv_file_name,"r")
                    my_csv_file = csv.reader(my_file_in_csv)
                except IOError:
                    print("\nI can't find file ",input_csv_file_name)
                    print("\nPlease check directory and/or file name.")
                    input("\nPress enter key to exit program.")
                    sys.exit(0)  # Exiting program    
                        
                type_of_plot = line[2][0:].replace(" ","")
                    
                # Enters of plots
                list_of_types_of_plots = ["PLOTALLLEGEND","PLOTALL"]
                while (type_of_plot.upper() not in list_of_types_of_plots):
                    print("Invalid choice!")
                    type_of_plot = input("\nEnter the plot to be created (PLOT or PLOTALLLEGEND) => ")
        
                if type_of_plot.upper() == "PLOTALLLEGEND" or type_of_plot.upper() == "PLOTALL":
                    # Looping through to read .csv file, lines are assigned to numpy arrays my_array1 and my_array2 
                    count_lines_plt = 0
                    for line_plt in my_csv_file:
                        if type_of_plot.upper() != "PLOTPDB":
                            my_array1[count_lines_plt] = line_plt[0]
                            my_array2[count_lines_plt] = line_plt[1]    
                            count_lines_plt += 1
    
                            # Uses max and min to get maximum and minimum values in the arrays
                            x_min_lim = np.min(my_array1[0:count_lines_plt])
                            x_max_lim = np.max(my_array1[0:count_lines_plt])
                            y_min_lim = np.min(my_array2[0:count_lines_plt]) 
                            y_max_lim = np.max(my_array2[0:count_lines_plt])
        
                            # Shows overall information read from .csv file
                            sandres_line = "\nI read "+str(count_lines_plt)+" lines from "+input_csv_file_name 
                            print(sandres_line)
                            my_mpltcsv_log.write (sandres_line+"\n")
                            
                            # Read information necessary for the plot
                            x_min   = float(line[3][0:])
                            if x_min == "":
                                x_min = x_min_lim
                            x_max   = float(line[4][0:])
                            if x_max == "":
                                x_max = x_max_lim
                            y_min   = float(line[5][0:])
                            if y_min == "":
                                y_min = y_min_lim 
                            y_max   = float(line[6][0:])
                            if y_max == "":
                                y_max = y_max_lim 
                        
                        x_label = line[7][0:]
                        if x_label == "":
                            x_label = "X-axis" 
                        y_label = line[8][0:]
                        if y_label == "": 
                            y_label = "Y-axis" 
                        plot_title = line[9][0:]
                    my_file_in_csv.close()    
                    # Pre-defined markers
                    # "." Point marker
                    # "," Pixel marker
                    # "o" Circle marker
                    # "v" Triangle down marker
                    # "^" Triangle up marker 
                    # "<" Triangle left marker
                    # ">" Triangle right marker
                    # "1" Tripod down marker
                    # "2" Tripod up marker
                    # "3" Tripod left marker
                    # "4" Tripod right marker 
                    # "s" Square marker
                    # "p" Pentagon marker
                    # "*" Star marker
                    # "h" Hexagon marker
                    # "H" Rotated hexagon marker
                    # "+" Plus marker
                    # "x" Cross marker
                    # "D" Diamond marker
                    # "d" Thin diamond marker
                    # "|" Vertical line marker
                    # "-" Horizontal line marker
                    defined_markers = [".",",","o", "v","^","<",">","1","2","3","4","s","p","*","h","H","+","x","D","d","|","-"]
                    type_of_marker =  line[10][0:].replace(" ","")
                    if type_of_marker in defined_markers:
                        sandres_line = "Selected type of marker => "+type_of_marker 
                        print(sandres_line)
                        my_mpltcsv_log.write (sandres_line+"\n")
                    else:
                        sandres_line = "\nI didn't recognize the type of marker you gave. I will use + ."
                        print(sandres_line)
                        my_mpltcsv_log.write (sandres_line+"\n")
                        type_of_marker = "+"
                    
                    plt_color = str(  line[11][0:].replace(" ","")   )
                    
                    # Plot output formats:'svgz': 'Scalable Vector Graphics', 'ps': 'Postscript', 'emf': 'Enhanced Metafile', 'rgba': 'Raw RGBA bitmap','raw': 'Raw RGBA bitmap',
                    #                     'pdf': 'Portable Document Format', 'svg': 'Scalable Vector Graphics', 'eps': 'Encapsulated Postscript', 'png': 'Portable Network Graphics'
                    plt_output_format = str(  line[12][0:].replace(" ","")   )
                    # Class StatAnalysis to instantiate an object
                    #csv_info = StatAnalysis(my_array1[0:count_lines_plt],my_array2[0:count_lines_plt]) 
                    
                    # Loop while to identify legends for plot
                    my_index_mpltcsv = 14
                    legend_list = []
                    while line[my_index_mpltcsv] != "END":
                        legend_list.append(str(line[my_index_mpltcsv]))
                        my_index_mpltcsv += 1
                        
                    if type_of_plot.upper() == "PLOTALL" or type_of_plot.upper() == "PLOTALLLEGEND":
                        
                        try:
                            # Assigns the content of the input_csv_file_name to my_csv_file
                            my_file_in_csv = open(input_csv_file_name,"r")
                            my_csv_file = csv.reader(my_file_in_csv)
                        except IOError:
                            print("\nI can't find file ",input_csv_file_name)
                            print("\nPlease check directory and/or file name.")
                            input("\nPress enter key to exit program.")
                            sys.exit(0)  # Exiting program    
                            
                        # Looping through csv_file for option PLOTALL to read first line to get number of columns
                        for line_plt in my_csv_file:
                            my_number_of_columns = len(line_plt)
                            print("Number of columns in the file ",input_csv_file_name,":",my_number_of_columns)
                            break   
                        
                        my_file_in_csv.close()
                        
                        # Assigns the content of the input_csv_file_name to my_csv_file
                        my_file_in_csv = open(input_csv_file_name,"r")
                        my_csv_file = csv.reader(my_file_in_csv) 
                        
                        # Looping through csv_file for option PLOTALL to read first line to get number of columns
                        count_lines_plt = 0
                        for line_plt in my_csv_file:
                            for my_col in range(my_number_of_columns):
                                my_mult_array[my_col,count_lines_plt] = line_plt[my_col]
                            count_lines_plt += 1
                        
                        for my_col in range(my_number_of_columns):
                            for my_line in range(count_lines_plt):
                                print(my_mult_array[my_col,my_line])
                                
                        x_min   = float(line[3][0:])
                        x_max   = float(line[4][0:])
                        y_min   = float(line[5][0:])
                        y_max   = float(line[6][0:])
                        plt_color = str(  line[11][0:].replace(" ","")   )
                        type_of_marker =  line[10][0:].replace(" ","")
                        plt_output_format = str(  line[12][0:].replace(" ","")   )
                         
                         
                        poly_deg = 0
                        # scatter_plot is a method applied to the object csv_info 
                        #my_polynomial_eq = csv_info.scatter_plot(x_label,y_label,plot_title,0,x_max,y_min,y_max,50,plt_color[0:1],type_of_marker,plt_output_format,True,1000,project_dir,0,root_input_csv_file,type_of_plot)
                        
                        csv_info = MultStatAnalysis(my_mult_array[0][0:count_lines_plt],my_mult_array[1][0:count_lines_plt],my_mult_array[2][0:count_lines_plt],my_mult_array[3][0:count_lines_plt],
                                                    my_mult_array[4][0:count_lines_plt],my_mult_array[5][0:count_lines_plt],my_mult_array[6][0:count_lines_plt],my_mult_array[7][0:count_lines_plt],
                                                    my_mult_array[8][0:count_lines_plt],my_mult_array[9][0:count_lines_plt],my_number_of_columns   )      
                            
                        if type_of_plot.upper() == "PLOTALLLEGEND":                        
                            csv_info.mult_scatter_plot(x_label,y_label,plot_title,x_min,x_max,y_min,y_max,50,plt_color[0:1],type_of_marker,plt_output_format,True,1000,project_dir,poly_deg,root_input_csv_file,type_of_plot,True,legend_list)
                        else:
                            csv_info.mult_scatter_plot(x_label,y_label,plot_title,x_min,x_max,y_min,y_max,50,plt_color[0:1],type_of_marker,plt_output_format,True,1000,project_dir,poly_deg,root_input_csv_file,type_of_plot,False,legend_list)
                                                                
                    else:
                        # Class StatAnalysis to instantiate an object
                        csv_info = StatAnalysis(my_array1[0:count_lines_plt],my_array2[0:count_lines_plt])
                        poly_deg = 0
                        # scatter_plot is a method applied to the object csv_info 
                        my_polynomial_eq = csv_info.scatter_plot(x_label,y_label,plot_title,x_min,x_max,y_min,y_max,50,plt_color[0:1],type_of_marker,plt_output_format,True,1000,project_dir,poly_deg,root_input_csv_file,type_of_plot)
                        
                    sandres_line = "\nGenerating plot "+project_dir+root_input_csv_file+"."+plt_output_format.lower()
                    print(sandres_line)
                    my_mpltcsv_log.write (sandres_line+"\n")
                            
                else:
                    sandres_line = "I didn't recognize the type of plot"
                    print(sandres_line)
                    my_mpltcsv_log.write (sandres_line+"\n")
                    sys.exit()
                
                sandres_line = "\n\nAnalysis finished here for MPLTCSV request!"
                print(sandres_line)
                my_mpltcsv_log.write (sandres_line+"\n")
                my_mpltcsv_log.close()
                #sys.exit()
             
            elif line[0][0:1] == "#":
                print(line)
            else:
                sandres_line = "Unrecognizible command"
                print(sandres_line)
                #sandres_log_file.write (sandres_line+"\n")
                print(line)
                water_dir = None
                project_dir = None
                #sandres_log_file.close()
                sys.exit()
        
        # To clear info_in1
        info_in1 = []     
        my_input_csv_file.close()
        
        # STENSEMBLEDOCK (STatistical analysys of ENSEMBLEDOCKing results): 
        # This task calculates Spearman's rank correlation coefficient between 
        # RMSD and scoring function
        if stensembledock:
            print("List of scoring functions:",my_list_scoring_functions) 
            index_here = 0
            # Open csv file for statistical analysis 
            sandres_tab = open(project_dir+"stensembledock.csv","w")
            sandres_line = "\nOpening csv file: "+"stensembledock.csv"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            root_file_name = "stensembledock"   # For STENSEMBLEDOCK
            
            print("\n\n######################################### Statistical Analysis ##########################################")
            sandres_log_file.write ("\n\n######################################### Statistical Analysis ##########################################\n")
            
            sandres_log_file.write ("\nCorrelation between docking RMSD and the following scoring functions\n")
            sandres_log_file.write("\nAll data are stored in stensembledock###.csv files\n")
            #print("Scoring function    RMSD(A)\t rho\tp-value1\tStd Dev\t R2\tp-value2\tFile")
            print("Scoring function    RMSD(A)\t Mean(SF)\tStd Dev\t\t rho\tp-value1\t R2\tp-value2")
            #sandres_log_file.write ("Scoring function\t\t  RMSD(A)\t  rho\t\tp-value1 \t\tStd Dev\t R2\tp-value2\t\tFile\n")   
            sandres_log_file.write ("Scoring function\t\t  RMSD(A)\t Mean(SF)\t  Std Dev\t\t  rho\t p-value1\t\t R2\tp-value2\t CSV File Number\n")   
            # Loopung through scoring functions    
            for my_score in range(count_scoring_functions):
                # Fix the number of characters in the output file name
                my_str = str(my_score)
                if len(my_str)< 4:
                    my_str = str((3-len(my_str) )*"0")+my_str
                
                # Gets the RMSD for minimum scoring function value
                #my_min_value_4_array = np.min(score_array[my_score,0:count_PDB ])
                #my_array_2_list = list(score_array[my_score,0:count_PDB ])
                #my_min_value_4_array_index = my_array_2_list.index(my_min_value_4_array)
                
                # Calculate Spearman correlation coefficiente
                stat_info = Spearman(  list(new_rmsd_array[0:count_PDB])  ,list(score_array[my_score,0:count_PDB ]  )    )
                stat_info.make_csv_file(2,project_dir+root_file_name+my_str+".csv",  list(new_rmsd_array[0:count_PDB])  ,list(score_array[my_score,0:count_PDB ]  )    )
          
                min_rmsd_in,ccR[my_score],ccP[my_score],my_std_dev,my_pearson,my_pearson_p,my_mean_in = stat_info.correlation_coefficient()
                my_pearson_2 = my_pearson*my_pearson
                
                if ccR[my_score] < 10.0:
                    my_str_info2 = my_list_scoring_functions[index_here]
                    my_st_file2 = root_file_name+my_str+".csv"
                    #sandres_line_out_000 = my_str_info2+str( "%6.3f\t%6.3f\t%6.3e\t%6.3f\t%6.3f\t%6.3e\t%s"%( min_rmsd_in,ccR[my_score],ccP[my_score],my_std_dev,my_pearson_2,my_pearson_p,my_st_file2 ))
                    sandres_line_out_000 = my_str_info2+str( "%6.3f\t%6.3e\t%6.3e\t%6.3f\t%6.3e\t%6.3f\t%6.3e"%( min_rmsd_in,my_mean_in,my_std_dev,ccR[my_score],ccP[my_score],my_pearson_2,my_pearson_p ))
                    #sandres_line_out_001 = my_str_info2+str( "%6.3f\t\t  %6.3f\t\t\t%6.3e\t\t%6.3f\t%6.3f\t%6.3e\t\t%s"%( min_rmsd_in,ccR[my_score],ccP[my_score],my_std_dev,my_pearson_2,my_pearson_p,my_st_file2 )+"\n")
                    sandres_line_out_001 = my_str_info2+str( "%6.3f\t\t\t%6.3e\t\t%6.3e\t%6.3f\t%6.3e\t\t%6.3f\t%6.3e\t\t%s"%( min_rmsd_in,my_mean_in,my_std_dev,ccR[my_score],ccP[my_score],my_pearson_2,my_pearson_p,my_st_file2[14:len(my_st_file2)-4] )+"\n")
                    sandres_line_out_002 = my_str_info2+str( ",\t%3d,\t%6.3f,\t%6.3e,\t%6.3f,\t%6.3e"%( count_PDB,ccR[my_score],ccP[my_score],my_pearson_2,my_pearson_p )+",\t"+my_st_file2+"\n")
                    print(sandres_line_out_000)
                    sandres_log_file.write (sandres_line_out_001)
                    sandres_tab.write(sandres_line_out_002)
                #else:
                #    # Write formatted text with ND
                #    sandres_line_out_000 = my_str_info2+str( "  ND  \t  ND  \t\t ND\t\t  ND  \t  ND  \t\t  ND \t ND")
                #    sandres_line_out_001 = my_str_info2+str( "  ND  \t\t    ND  \t\t\t  ND       \tND  \t  ND  \t\t  ND  \t ND \t\t%s"%( my_st_file2[0:len(my_st_file2)-4] )+"\n")
                #    sandres_line_out_002 = my_str_info2+str( ",\t%3d,\t  ND  ,\t  ND  ,\t  ND  ,\t  ND  ,\t"%(count_PDB)+"\n")
                #    print(sandres_line_out_000)
                #    sandres_log_file.write (sandres_line_out_001)
                #    sandres_tab.write(sandres_line_out_002)
                index_here += 1        
            print("\n\n#########################################################################################################")
            sandres_log_file.write ("\n\n#########################################################################################################\n")
            print("\nND: Not determined when the number of PDB files for which the information is available is less than 3, or all elements in the list are the same.")
            sandres_log_file.write ("\nND: Not determined if number of PDB files for which the information is available is less than 3, \nor all elements in the list are the same.\n")
            
            sandres_line =  "\nNumber of structures in the dataset: "+str(count_PDB)
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            
            # Calculate docking accuracy
            rmsd_list = list(new_rmsd_array[0:count_PDB])
            count_rmsd_less_than_4 = 0
            count_rmsd_less_than_3 = 0
            count_rmsd_less_than_2 = 0
            count_total_rmsd = len(rmsd_list)
        
            # Looping through rmsd_list (RMSD)
            for rmsd_value in rmsd_list:
                if (rmsd_value<2.0):
                    count_rmsd_less_than_2 += 1
                    count_rmsd_less_than_3 += 1
                    count_rmsd_less_than_4 += 1
                elif (rmsd_value<3.0):
                    count_rmsd_less_than_3 += 1
                    count_rmsd_less_than_4 += 1
                elif (rmsd_value<4.0):
                    count_rmsd_less_than_4 += 1
        
            # Check if count_total_rmsd > 0
            if count_total_rmsd > 0:
                f_rmsd_a =  count_rmsd_less_than_2/count_total_rmsd
                f_rmsd_b =  count_rmsd_less_than_3/count_total_rmsd
                f_rmsd_c =  count_rmsd_less_than_4/count_total_rmsd
                da1 = f_rmsd_a + 0.5*(f_rmsd_b - f_rmsd_a)
                extda1 = da1+ 0.25*(f_rmsd_c - f_rmsd_b)
                    
                perc_extda1 = 100*extda1
                perc_da1 = 100*da1
                
                # Show mean RMSD for the ensemble
                my_mean_RMSD =  np.mean(new_rmsd_array[0:count_PDB]) 
                sandres_line = str("\nMean docking RMSD for the dataset: %6.3f "%(my_mean_RMSD)+" A")
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                # Show Median for RMSD
                sandres_line = str("Median for RMSD: %6.3f"%(np.median( new_rmsd_array[0:count_PDB])))+" A"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                # Show standard deviation for  RMSD for the ensemble
                my_std_RMSD = np.std(new_rmsd_array[0:count_PDB])
                sandres_line = str("Standard deviation for docking RMSD: %6.3f "%(my_std_RMSD)+" A")
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                # Show range for RMSD for the ensemble
                my_minimum_RMSD =  np.min(new_rmsd_array[0:count_PDB]) 
                my_maximum_RMSD =  np.max(new_rmsd_array[0:count_PDB]) 
                sandres_line = str("Docking RMSD ranges from: %6.3f "%(my_minimum_RMSD)+" to %6.3f"%(my_maximum_RMSD)+" A")
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                # Show Docking Accuracy
                sandres_line = str("\nDA1(2,3): %6.3f"%(perc_da1))+" %"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                # Show Extended Docking Accuracy
                sandres_line = str("DA2(2,3,4): %6.3f"%(perc_extda1))+" %"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                    
                sandres_line = "\nDA1(2,3) = f_a + 0.5(f_b - f_a)"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                sandres_line = "where DA1(2,3) is the docking accuracy, \nf_a is the fraction of poses for which the docking RMSD is less than  2 A,"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                sandres_line = "and f_b is the fraction of poses for which the docking RMSD is less than  3 A."
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                    
                sandres_line = "\nDA2(2,3,4) = DA1(2,3) + 0.25(f_c - f_b)"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                sandres_line = "where DA2(2,3,4) is the extended docking accuracy and"
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                sandres_line = "and f_c is the fraction of poses for which the docking RMSD is less than  4 A."
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                    
            sandres_line = "\nRMSD is the RMSD for the lowest scoring function value"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            
            sandres_line = "Mean(SF) is the mean value for the scoring function values"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
                
            sandres_line = "Std Def is the standard deviation for the scoring function values"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            
            sandres_line = "rho is Spearman rank-order correlation coefficient"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
                
            sandres_line = "p-value1 is for rho"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
                
            sandres_line = "R2 is the squared Pearson correlation coefficient"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
                
            sandres_line = "p-value2 is for R2"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
                
            sandres_log_file.close() 
            sandres_tab.close()
            
        # STSCOR (STatistical analysis of SCOre functions and binding affinity): 
        # This task calculates Spearman's rank correlation coefficient between 
        # Log10(experimental binding) and scoring function
        if stscor: 
            # Open csv file for statistical analysis 
            sandres_tab = open(project_dir+"stscor.csv","w")
            sandres_line = "\nOpening csv file: "+"stscor.csv"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            root_file_name = "stscor"   # For STSCOR
            
            print("\n\n######################################### Statistical Analysis ##########################################")
            sandres_log_file.write ("\n\n######################################### Statistical Analysis ##########################################\n")
            
            sandres_log_file.write ("\nCorrelation between docking RMSD and the following scoring functions\n")
            print("Scoring function    rho\t\tp-value1\tStd Dev\t R2\tp-value2\tFile")
            sandres_log_file.write ("Scoring function\t\t  rho\t    p-value1\t\tStd Dev\t R2\tp-value2\t\tFile\n")   
              
            index_here = 0
            for my_score in range(count_scoring_functions): 
                # Fix the number of characters in the output file name
                my_str = str(my_score)
                if len(my_str)< 4:
                    my_str = str((3-len(my_str) )*"0")+my_str
                
                stat_info = Spearman(  list(expBindingArray[0:count_PDB])  ,list(score_array[my_score,0:count_PDB ]  )    )
                stat_info.make_csv_file(2,project_dir+root_file_name+my_str+".csv",  list(expBindingArray[0:count_PDB])  ,list(score_array[my_score,0:count_PDB ]  )    )
      
                #ccR[my_score],ccP[my_score]                       = stat_info.correlation_coefficient()  
                min_rmsd_in,ccR[my_score],ccP[my_score],my_std_dev,my_pearson,my_pearson_p,my_mean_in  = stat_info.correlation_coefficient()
                    
                my_pearson_2 = my_pearson*my_pearson
                
                if ccR[my_score] < 10.0:
                    my_str_info2 = my_list_scoring_functions[index_here]
                    my_st_file2 = root_file_name+my_str+".csv"
                    my_str_info2 = my_list_scoring_functions[index_here]
                    sandres_line_out_000 = my_str_info2+str( "%6.3f\t%6.3e\t%6.3f\t%6.3f\t%6.3e\t%s"%( ccR[my_score],ccP[my_score],my_std_dev,my_pearson_2,my_pearson_p,my_st_file2 ))
                    sandres_line_out_001 = my_str_info2+str( "%6.3f\t\t\t%6.3e\t\t%6.3f\t%6.3f\t%6.3e\t\t%s"%( ccR[my_score],ccP[my_score],my_std_dev,my_pearson_2,my_pearson_p,my_st_file2 )+"\n")
                    sandres_line_out_002 = my_str_info2+str( ",\t%3d,\t%6.3f,\t%6.3e,\t%6.3f,\t%6.3e"%( count_PDB,ccR[my_score],ccP[my_score],my_pearson_2,my_pearson_p )+",\t"+my_st_file2+"\n")
                    print(sandres_line_out_000)
                    sandres_log_file.write (sandres_line_out_001)
                    sandres_tab.write(sandres_line_out_002)
                else:
                    my_str_info2 = my_list_scoring_functions[index_here]
                    my_st_file2 = root_file_name+my_str+".csv"
                    sandres_line_out_000 = my_str_info2+str( "  ND  \t  ND  \t\t  ND  \t  ND  \t  ND  \t\t%s"%( my_st_file2 ))
                    sandres_line_out_001 = my_str_info2+str( "  ND  \t  ND  \t\t\t\t  ND  \t  ND  \t  ND  \t\t%s"%( my_st_file2 )+"\n")
                    print(sandres_line_out_000)
                    sandres_log_file.write (sandres_line_out_001)
                
                index_here += 1
            print("\n\n#########################################################################################################")
            sandres_log_file.write ("\n\n#########################################################################################################\n")
            print("\nND: Not determined when the number of PDB files for which the information is available is less than 3! or all elements in the list are the same.")
            sandres_log_file.write ("\nND: Not determined if number of PDB files for which the information is available is less than 3!\n")
            
            sandres_line =  "\nNumber of structures in the dataset: "+str(count_PDB)
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
                
            sandres_line = "rho is Spearman rank-order correlation coefficient"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
                
            sandres_line = "p-value1 is for rho"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
                
            sandres_line = "R2 is the squared Pearson correlation coefficient"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
                
            sandres_line = "p-value2 is for R2"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            sandres_log_file.close() 
            sandres_tab.close()
              
        # CHKSTR (CHecK STRucture):
        # This task checks if all structure files are in the structure directory. The main goal of this task is to verify 
        # if an update version of downloaded files brings new structures to be added to a data set.
        if chkstr:
            print("Warning! If you need to download more that 30 structures, you may need to split your input file!\n\n")
            chkstr_line_out = "\nThe following access codes have been found in the structure directory:\n"
            print(chkstr_line_out)
            sandres_log_file.write (chkstr_line_out)
            for chkstr_file in name_PDB:
                print(chkstr_file)
                sandres_log_file.write (chkstr_file+"\n")
            if len(name_no_PDB) > 0:
                chkstr_line_out = "\nThe following access codes have NOT been found in the structure directory:\n"
                print(chkstr_line_out)
                sandres_log_file.write (chkstr_line_out)
                for chkstr_file in name_no_PDB:
                    print(chkstr_file)
                    sandres_log_file.write (chkstr_file+"\n")
            if len(no_binding_list) > 0:
                chkstr_line_out = "\nThe following access codes have NO information about binding affinity ("+format_in+"):\n"
                print(chkstr_line_out)
                sandres_log_file.write (chkstr_line_out)
                for chkstr_bind in no_binding_list:
                    print(chkstr_bind)
                    sandres_log_file.write (chkstr_bind+"\n")
                
            sandres_line = "\n######################################################################" 
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "\nSummary of results for CHKSTR:\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line) 
            sandres_line = "Structure directory: "+project_dir+"\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "Total number of files: "+str(count_chkstr )+"\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line)          
            sandres_line = "Total number of files for which there is no binding information: "+str(count_no_binding_info )+" \n"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "Total number of files not found in the structure directory: "+str(count_no_structure)+" \n"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            
            sandres_line = "######################################################################"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "\n\nAnalysis finished here for CHKSTR request!"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            sandres_log_file.close()
              
        # GETSTR (GET STRucture):
        # This task downloads structure files from: http://www.rcsb.org/pdb/files/. 
        # All structure files will be downloaded at the structure directory (STRDIR)
        if getstr:
            print("\n\nThe following access codes have been downloaded:\n")
            sandres_log_file.write ("\n\nThe following access codes have been downloaded:\n\n")
            for getstr_file in name_PDB:
                print(getstr_file)
                sandres_log_file.write (getstr_file+"\n")
            if len(name_no_PDB) > 0:
                print("\nThe following access codes have NOT been found:\n")
                sandres_log_file.write ("\nThe following access codes have NOT been found:\n\n")
                for getstr_file in name_no_PDB:
                    print(getstr_file)
                    sandres_log_file.write (getstr_file+"\n")
            
            sandres_line = "\n######################################################################" 
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "\nSummary of results for GETSTR:\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line) 
            sandres_line = "All files downloaded in the directory: "+project_dir+"\n" 
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "Total number of files: "+str(len(name_PDB))+"\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "Total number of files found in www.rcsb.org: "+str( len(name_PDB) - len(name_no_PDB) )+"\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "Total number of files NOT found in www.rcsb.org: "+str(len(name_no_PDB))+"\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "######################################################################"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "\n\nAnalysis finished here for GETSTR request!"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            
            # Close log file
            sandres_log_file.close()
            
        # BIOMAT (BIO-MATrix):
        # Generates PDB for Biological Assembly using BIOMAT information
        if biomat: 
            if count_bio_assemblies > 1:
                biomat_line_out = "\n\nList of PDB files where BIOMAT were found"
                print(biomat_line_out)
                sandres_log_file.write (biomat_line_out+"\n")
                biomat_line_out ="Output PDB"
                print(biomat_line_out)
                sandres_log_file.write (biomat_line_out+"\n")
                for line in name_PDB:
                    new_length = len(line) - 4
                    biomat_line_out = str(line[0:new_length])+".pdb"
                    print(biomat_line_out)
                    sandres_log_file.write (biomat_line_out+"\n")
            
            sandres_line = "\n######################################################################"   
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "\nSummary of results for BIOMAT:\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line) 
            sandres_line = "Structure directory: "+project_dir+"\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "Total number of PDB files: "+str(count_BIOMAT_lines )+"\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "Total number of generated biological assembly(ies) : "+str( count_bio_assemblies )+"\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "Total number of PDB files for which biological assemblies were NOT generated : "+str(count_BIOMAT_lines - count_bio_assemblies )+"\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "######################################################################"
            print(sandres_line)
            sandres_log_file.write (sandres_line) 
            sandres_line = "\n\nAnalysis finished here for BIOMAT request!"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            sandres_log_file.close()
            #sys.exit()
            
        # CHKLIG (CHecK LIGands):
        # Checks if the ligands are in the structures
        if chklig:
            if count_no_atoms_chklig > 0:
                line_chklig = "\n\nA total of "+str(count_no_atoms_chklig)+" ligand(s) were(was) not found in PDB files\n"
                print(line_chklig)
                sandres_log_file.write (line_chklig)
                line_chklig = "List of ligands not found in the PDB files\n\n" 
                print(line_chklig)
                sandres_log_file.write (line_chklig)
                line_chklig = "Ligand\tChain\tNumber\tPDB file\n"
                print(line_chklig)
                sandres_log_file.write (line_chklig)
                
                for i in range(count_no_atoms_chklig):
                    line_chklig = str(name_LIG[i])+"\t"+str(chain_LIG[i])+"\t"+str(number_LIG[i])+"\t"+str(name_PDB[i][len(name_PDB[i])-8:len(name_PDB[i])])+"\n"
                    print(line_chklig)  
                    sandres_log_file.write (line_chklig+"\n")
                line_chklig = "\nPlease check ligand information for the above PDB files\n"
                print(line_chklig)
                sandres_log_file.write (line_chklig)
            else:
                line_chklig = "\nAll ligands found in the PDB files\n"
                print(line_chklig)
                sandres_log_file.write (line_chklig)
            
            sandres_line = "\n######################################################################"   
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "\nSummary of results for CHKLIG:\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line) 
            sandres_line = "Structure directory: "+project_dir+"\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "Total number of ligands: "+str(count_PDB )+"\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "Total number of ligands found in the structure directory: "+str( count_PDB - count_no_atoms_chklig )+"\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "Total number of ligands NOT found in the structure directory: "+str(count_no_atoms_chklig )+"\n"
            print(sandres_line)
            sandres_log_file.write (sandres_line)
            sandres_line = "######################################################################"
            print(sandres_line)
            sandres_log_file.write (sandres_line)    
            sandres_line = "\n\nAnalysis finished here for CHKLIG request!"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            print("\a")
            
            # Update chklig.in, fndwat.in, ststru.in, biomat.in 
            my_list_out = []
            if count_no_atoms_chklig > 0:
                
                print("\nDeleting the following PDB access codes: ")
                for line000 in name_PDB:
                    my_aux_var000 = line000[len(line000)-8:len(line000)]
                    my_aux_var001 = my_aux_var000[:4]
                    print(my_aux_var001)
                    my_list_out.append(my_aux_var001)
                
                # Call update_pdb_codes_chklig()
                update_pdb_codes_chklig(project_dir,my_list_out)
                
                # Call update_pdb_codes_chklig()
                update_pdb_codes_ststru(project_dir,my_list_out)
                
                print("\nFinished updating chklig.in, ststru.in")
    
        # STSTRU (STatistical analysis of STRUCtures):
        # This task shows statistical information about resolution, rfactor, rfree, completeness, 
        # RMSD deviation from ideal geometry, missing residues, B-value, and occupancy and selects 
        # the PDB files that show the highest and the lowest for each of the metioned parameters.
        # This information may be used to select PDB files that show more adequate structural parameters 
        # for protein-ligand docking simulations, for instance no missing residues in the structure   
        if ststru:
            # Looping through PDB file to analyze data
            for i in range(count_PDB):
                print("\n######################################################################")
                print("\nParsing PDB file: ",name_PDB[i])
                print("Structure ",i+1," out of ",count_PDB)
                # Instantiates a protein object
                my_protein = ProteinStructure(name_PDB[i])
            
                # Calls make_list_4_prot_atoms() method
                number_prot_atm_in,number_lig_atm_in,number_water_atm_in,number_all_atm_in,number_active_atm_in = my_protein.make_list_of_atoms(name_LIG[i],chain_LIG[i],number_LIG[i])
                    
                # Calls read_resolution method
                if my_protein.read_resolution() == None:        # If None we don't have to read attribute from the object my_protein
                    no_pdb_remark_info[0,i] = i
                    missing_pdb_remark_info[0] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[0,count_aux_PDB[0]] = my_protein.read_resolution()
                    count_aux_PDB[0] += 1           # We used index count_aux_PDB because we may have the attribute missing from the object my_proteu
                                                # This also garantees that all attribute values will occupy the first positions of the array
                
                # Calls read_low_reso method
                if my_protein.read_low_resol() == None:        # If None we don't have to read attribute from the object my_protein
                    no_pdb_remark_info[1,i] = i
                    missing_pdb_remark_info[1] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[1,count_aux_PDB[1]] = my_protein.read_low_resol()
                    count_aux_PDB[1] += 1           # We used index count_aux_PDB because we may have the attribute missing from the object my_proteu
                                                # This also garantees that all attribute values will occupy the first positions of the array
                
                # Calls read_rfactor method
                if my_protein.read_rfactor() == None:        # If None we don't have to read attribute from the object my_protein
                    no_pdb_remark_info[2,i] = i
                    missing_pdb_remark_info[2] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[2,count_aux_PDB[2]] = my_protein.read_rfactor()
                    count_aux_PDB[2] += 1           # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                # This also garantees that all attribute values will occupy the first positions of the array
                   
                # Calls read_rfree() method
                if my_protein.read_rfree() == None:
                    no_pdb_remark_info[3,i] = i
                    missing_pdb_remark_info[3] = 1
                else:               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[3,count_aux_PDB[3]] = my_protein.read_rfree()
                    count_aux_PDB[3] += 1           # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                # This also garantees that all attribute values will occupy the first positions of the array
            
                # Calls read_completeness() method
                if my_protein.read_completeness() == None:
                    no_pdb_remark_info[4,i] = i
                    missing_pdb_remark_info[4] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[4,count_aux_PDB[4]] = my_protein.read_completeness()
                    count_aux_PDB[4] += 1           # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_bond_length() method
                if my_protein.read_bond_length() == None:
                    no_pdb_remark_info[5,i] = i
                    missing_pdb_remark_info[5] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[5,count_aux_PDB[5]] = my_protein.read_bond_length()
                    count_aux_PDB[5] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                # This also garantees that all attribute values will occupy the first positions of the array         
            
                # Calls read_bond_angle() method
                if my_protein.read_bond_angle() == None:
                    no_pdb_remark_info[6,i] = i
                    missing_pdb_remark_info[6] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[6,count_aux_PDB[6]] = my_protein.read_bond_angle()
                    count_aux_PDB[6] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                # This also garantees that all attribute values will occupy the first positions of the array         
    
                # Calls read_torsion1() method
                if my_protein.read_torsion1() == None:
                    no_pdb_remark_info[7,i] = i
                    missing_pdb_remark_info[7] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[7,count_aux_PDB[7]] = my_protein.read_torsion1()
                    count_aux_PDB[7] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                # This also garantees that all attribute values will occupy the first positions of the array         
                  
                # Calls read_torsion2() method
                if my_protein.read_torsion2() == None:
                    no_pdb_remark_info[8,i] = i
                    missing_pdb_remark_info[8] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[8,count_aux_PDB[8]] = my_protein.read_torsion2()
                    count_aux_PDB[8] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                # This also garantees that all attribute values will occupy the first positions of the array         
            
                # Calls read_torsion3() method
                if my_protein.read_torsion3() == None:
                    no_pdb_remark_info[9,i] = i
                    missing_pdb_remark_info[9] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[9,count_aux_PDB[9]] = my_protein.read_torsion3()
                    count_aux_PDB[9] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                # This also garantees that all attribute values will occupy the first positions of the array         
                  
                # Calls read_torsion4() method
                if my_protein.read_torsion4() == None:
                    no_pdb_remark_info[10,i] = i
                    missing_pdb_remark_info[10] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[10,count_aux_PDB[10]] = my_protein.read_torsion4()
                    count_aux_PDB[10] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                # This also garantees that all attribute values will occupy the first positions of the array         
                
                
                # Calls read_missing_res() method
                if my_protein.read_missing_res() == 0:
                    no_pdb_remark_info[11,i] = i
                    missing_pdb_remark_info[11] = 1
                    print("No missing residues in the structure.")
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[11,count_aux_PDB[11]] = my_protein.read_missing_res()
                    count_aux_PDB[11] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                # This also garantees that all attribute values will occupy the first positions of the array 
            
                # Calls calculate_B_value_Occupancy() method for active ligand atoms
                b_value_ligand_in, occupancy_ligand_in = my_protein.calculate_B_value_Occupancy("Ligand")
                # For b_value_ligand_in, occupancy_ligand_in
                if b_value_ligand_in == 0.0 or occupancy_ligand_in == 0.0:
                    no_pdb_remark_info[12,i] = i
                    no_pdb_remark_info[13,i] = i
                    missing_pdb_remark_info[12] = 1
                    missing_pdb_remark_info[13] = 1
                else:                               
                    pdb_remark_info[12,count_aux_PDB[12]] = b_value_ligand_in
                    pdb_remark_info[13,count_aux_PDB[13]] = occupancy_ligand_in
                    count_aux_PDB[12] += 1 
                    count_aux_PDB[13] += 1     
                
                # Calls calculate_B_value_Occupancy() method for whole structure
                b_value_whole_in, occupancy_whole_in = my_protein.calculate_B_value_Occupancy("Whole")
                # For b_value_whole_in, occupancy_whole_in
                if b_value_whole_in == None or occupancy_whole_in == None:
                    no_pdb_remark_info[14,i] = i
                    no_pdb_remark_info[15,i] = i
                    missing_pdb_remark_info[14] = 1
                    missing_pdb_remark_info[15] = 1
                else:                               
                    pdb_remark_info[14,count_aux_PDB[14]] = b_value_whole_in
                    pdb_remark_info[15,count_aux_PDB[15]] = occupancy_whole_in
                    count_aux_PDB[14] += 1 
                    count_aux_PDB[15] += 1 
                
                # Calls calculate_B_value_Occupancy() method for water molecules
                b_value_water_in, occupancy_water_in = my_protein.calculate_B_value_Occupancy("Water")
                # For b_value_water_in, occupancy_water_in
                if b_value_water_in == None or occupancy_water_in == None:
                    no_pdb_remark_info[16,i] = i
                    no_pdb_remark_info[17,i] = i
                    missing_pdb_remark_info[16] = 1
                    missing_pdb_remark_info[17] = 1
                else:                               
                    pdb_remark_info[16,count_aux_PDB[16]] = b_value_water_in
                    pdb_remark_info[17,count_aux_PDB[17]] = occupancy_water_in
                    count_aux_PDB[16] += 1 
                    count_aux_PDB[17] += 1 
                
                # Calls calculate_B_value_Occupancy() method for protein main-chain atoms
                b_value_proteinMC_in, occupancy_proteinMC_in = my_protein.calculate_B_value_Occupancy("ProteinMC")
                # For b_value_water_in, occupancy_water_in
                if b_value_proteinMC_in == None or occupancy_proteinMC_in == None:
                    no_pdb_remark_info[18,i] = i
                    no_pdb_remark_info[19,i] = i
                    missing_pdb_remark_info[18] = 1
                    missing_pdb_remark_info[19] = 1
                else:                               
                    pdb_remark_info[18,count_aux_PDB[18]] = b_value_proteinMC_in
                    pdb_remark_info[19,count_aux_PDB[19]] = occupancy_proteinMC_in
                    count_aux_PDB[18] += 1 
                    count_aux_PDB[19] += 1 
                
                #Calls calculate_B_value_Occupancy() method for protein side-chain atoms
                b_value_proteinSC_in, occupancy_proteinSC_in = my_protein.calculate_B_value_Occupancy("ProteinSC")
                # For b_value_water_in, occupancy_water_in
                if b_value_proteinSC_in == None or occupancy_proteinSC_in == None:
                    no_pdb_remark_info[20,i] = i
                    no_pdb_remark_info[21,i] = i
                    missing_pdb_remark_info[20] = 1
                    missing_pdb_remark_info[21] = 1
                else:                               
                    pdb_remark_info[20,count_aux_PDB[20]] = b_value_proteinSC_in
                    pdb_remark_info[21,count_aux_PDB[21]] = occupancy_proteinSC_in
                    count_aux_PDB[20] += 1 
                    count_aux_PDB[21] += 1 
                
                # Calls radius_of_gyration() method
                #if my_protein.radius_of_gyration() == 0:
                #    no_pdb_remark_info[22,i] = i
                #    missing_pdb_remark_info[22] = 1
                #else:                               # In this case we have to read attribute from the object my_protein
                #    pdb_remark_info[22,count_aux_PDB[22]] = my_protein.radius_of_gyration()
                #    count_aux_PDB[22] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                # This also garantees that all attribute values will occupy the first positions of the array 
            
            sandres_line = "\nResults for STSTRU"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            root_file_name = "ststru"
            line_ststru ="\n\nVariable\t\t\t\t\t N   \tMeadian\t Mean\tStd Dev\tMinimum\tPDB\tMaximum\tPDB\tFile"
            print(line_ststru)
            line_ststru1 ="\n\nVariable\t\t\t\t\t\tN    Median\t Mean\t  Std Dev\tMinimum\tPDB\t Maximum\tPDB"
            sandres_log_file.write(line_ststru1+"\n")
            line_ststru2 ="Variable,N,Median,Mean,Std Dev,Minimum,PDB,Maximum,PDB"
            sandres_big_csv_file.write(line_ststru2+"\n")
            for j in range(22): # Number of structural parameters to be analyzed 22
            
                # Fix the number of characters in the output file name
                my_str = str(j)
                if len(my_str)< 4:
                    my_str = str((3-len(my_str) )*"0")+my_str
                    ststru_file = root_file_name+my_str+".csv"
                
                # To avoid list with less than 4
                if count_aux_PDB[j] < 4:
                    continue
                
                # Handles missing information    
                if missing_pdb_remark_info[j]:
                    count_loop_lines = count_aux_PDB[j] 
                    stat_info = Spearman(  code_PDB[0:count_aux_PDB[j]] ,list(pdb_remark_info[j,0:count_aux_PDB[j]]))
                    try:
                        my_median,my_mean,my_std,my_min,my_min_pdb,my_max,my_max_pdb = stat_info.calculateStats4List(code_PDB[0:count_aux_PDB[j]],list(pdb_remark_info[j,0:count_aux_PDB[j]]))
                        stat_info.make_csv_file(2,project_dir+root_file_name+my_str+".csv",code_PDB[0:count_aux_PDB[j]], list(pdb_remark_info[j,0:count_aux_PDB[j]]))
                        line_ststru = remark_ststru_info[j]+str("\t%3d\t%6.3f\t%6.3f\t%6.3f\t%6.3f\t%s\t%6.3f\t%s\t%s"%(count_aux_PDB[j],my_median,my_mean,my_std,my_min,my_min_pdb,my_max,my_max_pdb,ststru_file ) )
                        line_ststru1 = remark_ststru_info[j]+str("\t%3d\t\t\t%6.3f\t%6.3f\t\t%6.3f\t%6.3f\t\t %s\t%6.3f\t%s"%(count_aux_PDB[j],my_median,my_mean,my_std,my_min,my_min_pdb,my_max,my_max_pdb ) )
                        print(line_ststru)
                        sandres_log_file.write (line_ststru1+"\n")
                        line_ststru2 = remark_ststru_info[j]+str(",%3d,%6.3f,%6.3f,%6.3f,%6.3f,%s,%6.3f,%s"%(count_aux_PDB[j],my_median,my_mean,my_std,my_min,my_min_pdb,my_max,my_max_pdb ) )
                        sandres_big_csv_file.write(line_ststru2+"\n")
                    except UnboundLocalError:
                        undetermined_remark_ststru_info.append(remark_ststru_info[j])
                else:
                    count_loop_lines = len(rmsd)
                    stat_info = Spearman(code_PDB[0:count_PDB],list(pdb_remark_info[j,0:count_PDB]))
                    try:
                        my_median,my_mean,my_std,my_min,my_min_pdb,my_max,my_max_pdb = stat_info.calculateStats4List(code_PDB[0:count_PDB],list(pdb_remark_info[j,0:count_PDB]))
                        stat_info.make_csv_file(2,project_dir+root_file_name+my_str+".csv",code_PDB[0:count_PDB],list(pdb_remark_info[j,0:count_PDB ]))
                        line_ststru = remark_ststru_info[j]+str("\t%3d\t%6.3f\t%6.3f\t%6.3f\t%6.3f\t%s\t%6.3f\t%s\t%s"%(count_aux_PDB[j],my_median,my_mean,my_std,my_min,my_min_pdb,my_max,my_max_pdb,ststru_file ) )
                        line_ststru1 = remark_ststru_info[j]+str("\t%3d\t\t\t%6.3f\t%6.3f\t\t%6.3f\t%6.3f\t\t %s\t%6.3f\t%s"%(count_aux_PDB[j],my_median,my_mean,my_std,my_min,my_min_pdb,my_max,my_max_pdb ) )
                        print(line_ststru)
                        sandres_log_file.write (line_ststru1+"\n")
                        line_ststru2 = remark_ststru_info[j]+str(",%3d,%6.3f,%6.3f,%6.3f,%6.3f,%s,%6.3f,%s"%(count_aux_PDB[j],my_median,my_mean,my_std,my_min,my_min_pdb,my_max,my_max_pdb ) )
                        sandres_big_csv_file.write(line_ststru2+"\n")
                    except UnboundLocalError:
                        undetermined_remark_ststru_info.append(remark_ststru_info[j])
                        
            sandres_line = "\nN is the number of structures used in the statistical analysis for each parameter"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            
            sandres_line = "Std Dev is the standard deviation for each parameter"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            
            sandres_line = "\n\nAnalysis finished here for STSTRU request!"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            
            # Close ststru.log and ststru.csv files
            sandres_log_file.close()
            sandres_big_csv_file.close()
            
            # To show undetermined parameters if any
            if len(undetermined_remark_ststru_info):
                print("The following parameters have not been determined:")
                print(undetermined_remark_ststru_info)
                
        # If SPHERE is present, it calculates the volume for each sphere
        if count_spheres > 0:
            # Looping through spheres to calculate sphere volume
            for i in range(count_spheres):
                volume.append( (4/3)*math.pi*radius[i]**3 )
            
    ##################################################################################################
    # Start looping to gather PDB information from REMARKs and related methods                      #
    ##################################################################################################
        # STDOCK (STatistical Analysis of DOCK results):
        # This task carries out calculates the Spearman's correlation coefficient between docking RMSD
        # and structural parameters identified in PDB files
        if stdock:
            # Open csv file for statistical analysis
            sandres_tab = open(project_dir+"stdock.csv","w")
            # Looping to analyze each PDB file
            for i in range(count_PDB):
                complete_name_PDB = project_dir+name_PDB[i]
                print("\n######################################################################")
                print("\nParsing PDB file: ",complete_name_PDB)
                print("Structure ",i+1," out of ",count_PDB)
                # Instantiates a protein object
                my_protein = ProteinStructure(complete_name_PDB)
                
                # Calls make_list_4_prot_atoms() method
                number_prot_atm_in,number_lig_atm_in,number_water_atm_in,number_all_atm_in,number_active_atm_in = my_protein.make_list_of_atoms(name_LIG[i],chain_LIG[i],number_LIG[i])
                    
                # Calls read_resolution method
                if my_protein.read_resolution() == None:        # If None we don't have to read attribute from the object my_protein
                    no_pdb_remark_info[0,i] = i
                    missing_pdb_remark_info[0] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[0,count_aux_PDB[0]] = my_protein.read_resolution()
                    rmsd_array[0,count_aux_PDB[0]] =  rmsd[i]
                    count_aux_PDB[0] += 1           # We used index count_aux_PDB because we may have the attribute missing from the object my_proteu
                                                    # This also garantees that all attribute values will occupy the first positions of the array
                
                # Calls read_low_resol method
                if my_protein.read_low_resol() == None:        # If None we don't have to read attribute from the object my_protein
                    no_pdb_remark_info[1,i] = i
                    missing_pdb_remark_info[1] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[1,count_aux_PDB[1]] = my_protein.read_low_resol()
                    rmsd_array[1,count_aux_PDB[1]] =  rmsd[i]
                    count_aux_PDB[1] += 1           # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array
                   
                # Calls read_rfactor method
                if my_protein.read_rfactor() == None:        # If None we don't have to read attribute from the object my_protein
                    no_pdb_remark_info[2,i] = i
                    missing_pdb_remark_info[2] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[2,count_aux_PDB[2]] = my_protein.read_rfactor()
                    rmsd_array[2,count_aux_PDB[2]] =  rmsd[i]
                    count_aux_PDB[2] += 1           # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array
                       
                # Calls read_rfree() method
                if my_protein.read_rfree() == None:
                    no_pdb_remark_info[3,i] = i
                    missing_pdb_remark_info[3] = 1
                else:               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[3,count_aux_PDB[3]] = my_protein.read_rfree()
                    rmsd_array[3,count_aux_PDB[3]] =  rmsd[i]
                    count_aux_PDB[3] += 1           # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array
                
                # Calls read_error_rfree method
                if my_protein.read_error_rfree() == None:        # If None we don't have to read attribute from the object my_protein
                    no_pdb_remark_info[4,i] = i
                    missing_pdb_remark_info[4] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[4,count_aux_PDB[4]] = my_protein.read_error_rfree()
                    rmsd_array[4,count_aux_PDB[4]] =  rmsd[i]
                    count_aux_PDB[4] += 1           # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array
                      
                # Calls read_min_fobs_sigma method
                if my_protein.read_min_fobs_sigma() == None :        # If None we don't have to read attribute from the object my_protein
                    no_pdb_remark_info[5,i] = i
                    missing_pdb_remark_info[5] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[5,count_aux_PDB[5]] = my_protein.read_min_fobs_sigma()
                    rmsd_array[5,count_aux_PDB[5]] =  rmsd[i]
                    count_aux_PDB[5] += 1           # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array
                
                # Calls read_number_of_reflections() method
                if my_protein.read_number_of_reflections() == None:
                    no_pdb_remark_info[6,i] = i
                    missing_pdb_remark_info[6] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[6,count_aux_PDB[6]] = my_protein.read_number_of_reflections()
                    rmsd_array[6,count_aux_PDB[6]] =  rmsd[i]
                    count_aux_PDB[6] += 1           # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                        
                # Calls read_completeness() method
                if my_protein.read_completeness() == None:
                    no_pdb_remark_info[7,i] = i
                    missing_pdb_remark_info[7] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[7,count_aux_PDB[7]] = my_protein.read_completeness()
                    rmsd_array[7,count_aux_PDB[7]] =  rmsd[i]
                    count_aux_PDB[7] += 1           # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_b_value_Wilson_plot() method
                if my_protein.read_b_value_Wilson_plot() == None:
                    no_pdb_remark_info[8,i] = i
                    missing_pdb_remark_info[8] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[8,count_aux_PDB[8]] = my_protein.read_b_value_Wilson_plot()
                    rmsd_array[8,count_aux_PDB[8]] =  rmsd[i]
                    count_aux_PDB[8] += 1           # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
              
                # Calls read_esd_Luzzati_plot() method
                if my_protein.read_esd_Luzzati_plot() == None:
                    no_pdb_remark_info[9,i] = i
                    missing_pdb_remark_info[9] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[9,count_aux_PDB[9]] = my_protein.read_esd_Luzzati_plot()
                    rmsd_array[9,count_aux_PDB[9]] =  rmsd[i]
                    count_aux_PDB[9] += 1           # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                                                    
                # Calls read_esd_sigmaa_plot() method
                if my_protein.read_esd_sigmaa_plot() == None:
                    no_pdb_remark_info[10,i] = i
                    missing_pdb_remark_info[10] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[10,count_aux_PDB[10]] = my_protein.read_esd_sigmaa_plot()
                    rmsd_array[10,count_aux_PDB[10]] =  rmsd[i]
                    count_aux_PDB[10] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                    
                # Calls read_cv_esd_Luzzati_plot() method
                if my_protein.read_cv_esd_Luzzati_plot() == None:
                    no_pdb_remark_info[11,i] = i
                    missing_pdb_remark_info[11] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[11,count_aux_PDB[11]] = my_protein.read_cv_esd_Luzzati_plot()
                    rmsd_array[11,count_aux_PDB[11]] =  rmsd[i]
                    count_aux_PDB[11] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                 
                # Calls read_cv_esd_sigmaa_plot() method
                if my_protein.read_cv_esd_sigmaa_plot() == None:
                    no_pdb_remark_info[12,i] = i
                    missing_pdb_remark_info[12] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[12,count_aux_PDB[12]] = my_protein.read_cv_esd_sigmaa_plot()
                    rmsd_array[12,count_aux_PDB[12]] =  rmsd[i]
                    count_aux_PDB[12] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                    
                # Calls read_esu_based_r_value() method
                if my_protein.read_esu_based_r_value() == None:
                    no_pdb_remark_info[13,i] = i
                    missing_pdb_remark_info[13] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[13,count_aux_PDB[13]] = my_protein.read_esu_based_r_value()
                    rmsd_array[13,count_aux_PDB[13]] =  rmsd[i]
                    count_aux_PDB[13] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                    
                # Calls read_esu_based_r_free() method
                if my_protein.read_esu_based_r_free() == None:
                    no_pdb_remark_info[14,i] = i
                    missing_pdb_remark_info[14] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[14,count_aux_PDB[14]] = my_protein.read_esu_based_r_free()
                    rmsd_array[14,count_aux_PDB[14]] =  rmsd[i]
                    count_aux_PDB[14] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_esu_based_max_like() method
                if my_protein.read_esu_based_max_like() == None:
                    no_pdb_remark_info[15,i] = i
                    missing_pdb_remark_info[15] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[15,count_aux_PDB[15]] = my_protein.read_esu_based_max_like()
                    rmsd_array[15,count_aux_PDB[15]] =  rmsd[i]
                    count_aux_PDB[15] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_esu_b_based_max_like()method
                if my_protein.read_esu_b_based_max_like() == None:
                    no_pdb_remark_info[16,i] = i
                    missing_pdb_remark_info[16] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[16,count_aux_PDB[16]] = my_protein.read_esu_b_based_max_like()
                    rmsd_array[16,count_aux_PDB[16]] =  rmsd[i]
                    count_aux_PDB[16] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_corr_coef_fo_fc() method
                if my_protein.read_corr_coef_fo_fc() == None:
                    no_pdb_remark_info[17,i] = i
                    missing_pdb_remark_info[17] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[17,count_aux_PDB[17]] = my_protein.read_corr_coef_fo_fc()
                    rmsd_array[17,count_aux_PDB[17]] =  rmsd[i]
                    count_aux_PDB[17] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_corr_coef_fo_fc_free() method
                if my_protein.read_corr_coef_fo_fc_free() == None:
                    no_pdb_remark_info[18,i] = i
                    missing_pdb_remark_info[18] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[18,count_aux_PDB[18]] = my_protein.read_corr_coef_fo_fc_free()
                    rmsd_array[18,count_aux_PDB[18]] =  rmsd[i]
                    count_aux_PDB[18] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                   
                # Calls read_bond_length() method
                if my_protein.read_bond_length() == None:
                    no_pdb_remark_info[19,i] = i
                    missing_pdb_remark_info[19] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[19,count_aux_PDB[19]] = my_protein.read_bond_length()
                    rmsd_array[19,count_aux_PDB[19]] =  rmsd[i]
                    count_aux_PDB[19] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_bond_length_o() method
                if my_protein.read_bond_length_o() == None:
                    no_pdb_remark_info[20,i] = i
                    missing_pdb_remark_info[20] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[20,count_aux_PDB[20]] = my_protein.read_bond_length_o()
                    rmsd_array[20,count_aux_PDB[20]] =  rmsd[i]
                    count_aux_PDB[20] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                      
                # Calls read_bond_angle() method
                if my_protein.read_bond_angle() == None:
                    no_pdb_remark_info[21,i] = i
                    missing_pdb_remark_info[21] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[21,count_aux_PDB[21]] = my_protein.read_bond_angle()
                    rmsd_array[21,count_aux_PDB[21]] =  rmsd[i]
                    count_aux_PDB[21] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_bond_angle_o() method
                if my_protein.read_bond_angle_o() == None:
                    no_pdb_remark_info[22,i] = i
                    missing_pdb_remark_info[22] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[22,count_aux_PDB[22]] = my_protein.read_bond_angle_o()
                    rmsd_array[22,count_aux_PDB[22]] =  rmsd[i]
                    count_aux_PDB[22] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                      
                # Calls read_angle_distance() method
                if my_protein.read_angle_distance() == None:
                    no_pdb_remark_info[23,i] = i
                    missing_pdb_remark_info[23] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[23,count_aux_PDB[23]] = my_protein.read_angle_distance()
                    rmsd_array[23,count_aux_PDB[23]] =  rmsd[i]
                    count_aux_PDB[23] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                      
                # Calls read_restraint_plane() method
                if my_protein.read_restraint_plane() == None:
                    no_pdb_remark_info[24,i] = i
                    missing_pdb_remark_info[24] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[24,count_aux_PDB[24]] = my_protein.read_restraint_plane()
                    rmsd_array[24,count_aux_PDB[24]] =  rmsd[i]
                    count_aux_PDB[24] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                      
                # Calls read_zero_chiral_volume() method
                if my_protein.read_zero_chiral_volume() == None:
                    no_pdb_remark_info[25,i] = i
                    missing_pdb_remark_info[25] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[25,count_aux_PDB[25]] = my_protein.read_zero_chiral_volume()
                    rmsd_array[25,count_aux_PDB[25]] =  rmsd[i]
                    count_aux_PDB[25] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_non_zero_chiral_volume() method
                if my_protein.read_non_zero_chiral_volume() == None:
                    no_pdb_remark_info[26,i] = i
                    missing_pdb_remark_info[26] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[26,count_aux_PDB[26]] = my_protein.read_non_zero_chiral_volume()
                    rmsd_array[26,count_aux_PDB[26]] =  rmsd[i]
                    count_aux_PDB[26] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                      
                # Calls read_anti_bumping() method
                if my_protein.read_anti_bumping() == None:
                    no_pdb_remark_info[27,i] = i
                    missing_pdb_remark_info[27] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[27,count_aux_PDB[27]] = my_protein.read_anti_bumping()
                    rmsd_array[27,count_aux_PDB[27]] =  rmsd[i]
                    count_aux_PDB[27] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_torsion1() method
                if my_protein.read_torsion1() == None:
                    no_pdb_remark_info[28,i] = i
                    missing_pdb_remark_info[28] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[28,count_aux_PDB[28]] = my_protein.read_torsion1()
                    rmsd_array[28,count_aux_PDB[28]] =  rmsd[i]
                    count_aux_PDB[28] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                      
                # Calls read_torsion2() method
                if my_protein.read_torsion2() == None:
                    no_pdb_remark_info[29,i] = i
                    missing_pdb_remark_info[29] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[29,count_aux_PDB[29]] = my_protein.read_torsion2()
                    rmsd_array[29,count_aux_PDB[29]] =  rmsd[i]
                    count_aux_PDB[29] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_torsion3() method
                if my_protein.read_torsion3() == None:
                    no_pdb_remark_info[30,i] = i
                    missing_pdb_remark_info[30] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[30,count_aux_PDB[30]] = my_protein.read_torsion3()
                    rmsd_array[30,count_aux_PDB[30]] =  rmsd[i]
                    count_aux_PDB[30] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                      
                # Calls read_torsion4() method
                if my_protein.read_torsion4() == None:
                    no_pdb_remark_info[31,i] = i
                    missing_pdb_remark_info[31] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[31,count_aux_PDB[31]] = my_protein.read_torsion4()
                    rmsd_array[31,count_aux_PDB[31]] =  rmsd[i]
                    count_aux_PDB[31] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_torsion_angle_buster_tnt() method
                if my_protein.read_torsion_angle_buster_tnt() == None:
                    no_pdb_remark_info[32,i] = i
                    missing_pdb_remark_info[32] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[32,count_aux_PDB[32]] = my_protein.read_torsion_angle_buster_tnt()
                    rmsd_array[32,count_aux_PDB[32]] =  rmsd[i]
                    count_aux_PDB[32] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_trigonal_carbon_planes_buster_tnt()
                if my_protein.read_trigonal_carbon_planes_buster_tnt() == None:
                    no_pdb_remark_info[33,i] = i
                    missing_pdb_remark_info[33] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[33,count_aux_PDB[33]] = my_protein.read_trigonal_carbon_planes_buster_tnt()
                    rmsd_array[33,count_aux_PDB[33]] =  rmsd[i]
                    count_aux_PDB[33] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_general_planes_buster_tnt()
                if my_protein.read_general_planes_buster_tnt() == None:
                    no_pdb_remark_info[34,i] = i
                    missing_pdb_remark_info[34] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[34,count_aux_PDB[34]] = my_protein.read_general_planes_buster_tnt()
                    rmsd_array[34,count_aux_PDB[34]] =  rmsd[i]
                    count_aux_PDB[34] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_isotropic_thermal_factor_buster_tnt()
                if my_protein.read_isotropic_thermal_factor_buster_tnt() == None:
                    no_pdb_remark_info[35,i] = i
                    missing_pdb_remark_info[35] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[35,count_aux_PDB[35]] = my_protein.read_isotropic_thermal_factor_buster_tnt()
                    rmsd_array[35,count_aux_PDB[35]] =  rmsd[i]
                    count_aux_PDB[35] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_non_bonded_contacts_buster_tnt()
                if my_protein.read_non_bonded_contacts_buster_tnt() == None:
                    no_pdb_remark_info[36,i] = i
                    missing_pdb_remark_info[36] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[36,count_aux_PDB[36]] = my_protein.read_non_bonded_contacts_buster_tnt()
                    rmsd_array[36,count_aux_PDB[36]] =  rmsd[i]
                    count_aux_PDB[36] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_omega_peptide_buster_tnt()
                if my_protein.read_omega_peptide_buster_tnt() == None:
                    no_pdb_remark_info[37,i] = i
                    missing_pdb_remark_info[37] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[37,count_aux_PDB[37]] = my_protein.read_omega_peptide_buster_tnt()
                    rmsd_array[37,count_aux_PDB[37]] =  rmsd[i]
                    count_aux_PDB[37] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_coordinate_error_phenix() method
                if my_protein.read_coordinate_error_phenix() == None:
                    no_pdb_remark_info[38,i] = i
                    missing_pdb_remark_info[38] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[38,count_aux_PDB[38]] = my_protein.read_coordinate_error_phenix()
                    rmsd_array[38,count_aux_PDB[38]] =  rmsd[i]
                    count_aux_PDB[38] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_phase_error_phenix() method
                if my_protein.read_phase_error_phenix() == None:
                    no_pdb_remark_info[39,i] = i
                    missing_pdb_remark_info[39] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[39,count_aux_PDB[39]] = my_protein.read_phase_error_phenix()
                    rmsd_array[39,count_aux_PDB[39]] =  rmsd[i]
                    count_aux_PDB[39] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_chirality_phenix() method
                if my_protein.read_chirality_phenix() == None:
                    no_pdb_remark_info[40,i] = i
                    missing_pdb_remark_info[40] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[40,count_aux_PDB[40]] = my_protein.read_chirality_phenix()
                    rmsd_array[40,count_aux_PDB[40]] =  rmsd[i]
                    count_aux_PDB[40] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_planarity_phenix() method
                if my_protein.read_planarity_phenix() == None:
                    no_pdb_remark_info[41,i] = i
                    missing_pdb_remark_info[41] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[41,count_aux_PDB[41]] = my_protein.read_planarity_phenix()
                    rmsd_array[41,count_aux_PDB[41]] =  rmsd[i]
                    count_aux_PDB[41] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_dihedral_phenix() method
                if my_protein.read_dihedral_phenix() == None:
                    no_pdb_remark_info[42,i] = i
                    missing_pdb_remark_info[42] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[42,count_aux_PDB[42]] = my_protein.read_dihedral_phenix()
                    rmsd_array[42,count_aux_PDB[42]] =  rmsd[i]
                    count_aux_PDB[42] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_chiral_center_restraint()
                if my_protein.read_chiral_center_restraint() == None:
                    no_pdb_remark_info[43,i] = i
                    missing_pdb_remark_info[43] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[43,count_aux_PDB[43]] = my_protein.read_chiral_center_restraint()
                    rmsd_array[43,count_aux_PDB[43]] =  rmsd[i]
                    count_aux_PDB[43] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_general_planes() method
                if my_protein.read_general_planes() == None:
                    no_pdb_remark_info[44,i] = i
                    missing_pdb_remark_info[44] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[44,count_aux_PDB[44]] = my_protein.read_general_planes()
                    rmsd_array[44,count_aux_PDB[44]] =  rmsd[i]
                    count_aux_PDB[44] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_general_planes_o() method
                if my_protein.read_general_planes_o() == None:
                    no_pdb_remark_info[45,i] = i
                    missing_pdb_remark_info[45] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[45,count_aux_PDB[45]] = my_protein.read_general_planes_o()
                    rmsd_array[45,count_aux_PDB[45]] =  rmsd[i]
                    count_aux_PDB[45] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_non_bonded_contacts() method
                if my_protein.read_non_bonded_contacts() == None:
                    no_pdb_remark_info[46,i] = i
                    missing_pdb_remark_info[46] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[46,count_aux_PDB[46]] = my_protein.read_non_bonded_contacts()
                    rmsd_array[46,count_aux_PDB[46]] =  rmsd[i]
                    count_aux_PDB[46] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_non_bonded_contacts_o() method
                if my_protein.read_non_bonded_contacts_o() == None:
                    no_pdb_remark_info[47,i] = i
                    missing_pdb_remark_info[47] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[47,count_aux_PDB[47]] = my_protein.read_non_bonded_contacts_o()
                    rmsd_array[47,count_aux_PDB[47]] =  rmsd[i]
                    count_aux_PDB[47] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_non_bonded_torsion() method
                if my_protein.read_non_bonded_torsion() == None:
                    no_pdb_remark_info[48,i] = i
                    missing_pdb_remark_info[48] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[48,count_aux_PDB[48]] = my_protein.read_non_bonded_torsion()
                    rmsd_array[48,count_aux_PDB[48]] =  rmsd[i]
                    count_aux_PDB[48] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_non_bonded_torsion_o() method
                if my_protein.read_non_bonded_torsion_o() == None:
                    no_pdb_remark_info[49,i] = i
                    missing_pdb_remark_info[49] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[49,count_aux_PDB[49]] = my_protein.read_non_bonded_torsion_o()
                    rmsd_array[49,count_aux_PDB[49]] =  rmsd[i]
                    count_aux_PDB[49] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_h_bond() method
                if my_protein.read_h_bond() == None:
                    no_pdb_remark_info[50,i] = i
                    missing_pdb_remark_info[50] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[50,count_aux_PDB[50]] = my_protein.read_h_bond()
                    rmsd_array[50,count_aux_PDB[50]] =  rmsd[i]
                    count_aux_PDB[50] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_h_bond_o() method
                if my_protein.read_h_bond_o() == None:
                    no_pdb_remark_info[51,i] = i
                    missing_pdb_remark_info[51] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[51,count_aux_PDB[51]] = my_protein.read_h_bond_o()
                    rmsd_array[51,count_aux_PDB[51]] =  rmsd[i]
                    count_aux_PDB[51] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_potential_metal_ion() method
                if my_protein.read_potential_metal_ion() == None:
                    no_pdb_remark_info[52,i] = i
                    missing_pdb_remark_info[52] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[52,count_aux_PDB[52]] = my_protein.read_potential_metal_ion()
                    rmsd_array[52,count_aux_PDB[52]] =  rmsd[i]
                    count_aux_PDB[52] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_symmetry_vdw() method
                if my_protein.read_symmetry_vdw() == None:
                    no_pdb_remark_info[53,i] = i
                    missing_pdb_remark_info[53] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[53,count_aux_PDB[53]] = my_protein.read_symmetry_vdw()
                    rmsd_array[53,count_aux_PDB[53]] =  rmsd[i]
                    count_aux_PDB[53] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_symmetry_vdw_o() method
                if my_protein.read_symmetry_vdw_o() == None:
                    no_pdb_remark_info[54,i] = i
                    missing_pdb_remark_info[54] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[54,count_aux_PDB[54]] = my_protein.read_symmetry_vdw_o()
                    rmsd_array[54,count_aux_PDB[54]] =  rmsd[i]
                    count_aux_PDB[54] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_symmetry_h_bond() method
                if my_protein.read_symmetry_h_bond() == None:
                    no_pdb_remark_info[55,i] = i
                    missing_pdb_remark_info[55] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[55,count_aux_PDB[55]] = my_protein.read_symmetry_h_bond()
                    rmsd_array[55,count_aux_PDB[55]] =  rmsd[i]
                    count_aux_PDB[55] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_symmetry_metal_ion() method
                if my_protein.read_symmetry_metal_ion() == None:
                    no_pdb_remark_info[56,i] = i
                    missing_pdb_remark_info[56] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[56,count_aux_PDB[56]] = my_protein.read_symmetry_metal_ion()
                    rmsd_array[56,count_aux_PDB[56]] =  rmsd[i]
                    count_aux_PDB[56] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_xtal_temperature() method
                if my_protein.read_xtal_temperature() == None:
                    no_pdb_remark_info[57,i] = i
                    missing_pdb_remark_info[57] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[57,count_aux_PDB[57]] = my_protein.read_xtal_temperature()
                    rmsd_array[57,count_aux_PDB[57]] =  rmsd[i]
                    count_aux_PDB[57] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_xray_wavelength() method
                if my_protein.read_xray_wavelength() == None:
                    no_pdb_remark_info[58,i] = i
                    missing_pdb_remark_info[58] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[58,count_aux_PDB[58]] = my_protein.read_xray_wavelength()
                    rmsd_array[58,count_aux_PDB[58]] =  rmsd[i]
                    count_aux_PDB[58] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_unique() method
                if my_protein.read_unique() == None:
                    no_pdb_remark_info[59,i] = i
                    missing_pdb_remark_info[59] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[59,count_aux_PDB[59]] = my_protein.read_unique()
                    rmsd_array[59,count_aux_PDB[59]] =  rmsd[i]
                    count_aux_PDB[59] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_resolution_range_low() method
                if my_protein.read_resolution_range_low() == None:
                    no_pdb_remark_info[60,i] = i
                    missing_pdb_remark_info[60] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[60,count_aux_PDB[60]] = my_protein.read_resolution_range_low()
                    rmsd_array[60,count_aux_PDB[60]] =  rmsd[i]
                    count_aux_PDB[60] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                if my_protein.read_completeness_for_range_data() == None:
                    no_pdb_remark_info[61,i] = i
                    missing_pdb_remark_info[61] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[61,count_aux_PDB[61]] = my_protein.read_completeness_for_range_data()
                    rmsd_array[61,count_aux_PDB[61]] =  rmsd[i]
                    count_aux_PDB[61] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_i_sigma_i_data_set() method
                if my_protein.read_i_sigma_i_data_set() == None:
                    no_pdb_remark_info[62,i] = i
                    missing_pdb_remark_info[62] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[62,count_aux_PDB[62]] = my_protein.read_i_sigma_i_data_set()
                    rmsd_array[62,count_aux_PDB[62]] =  rmsd[i]
                    count_aux_PDB[62] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_highest_resolution_shell_data_set() method
                if my_protein.read_highest_resolution_shell_data_set() == None:
                    no_pdb_remark_info[63,i] = i
                    missing_pdb_remark_info[63] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[63,count_aux_PDB[63]] = my_protein.read_highest_resolution_shell_data_set()
                    rmsd_array[63,count_aux_PDB[63]] =  rmsd[i]
                    count_aux_PDB[63] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_highest_resolution_shell_low_data_set() method
                if my_protein.read_highest_resolution_shell_low_data_set() == None:
                    no_pdb_remark_info[64,i] = i
                    missing_pdb_remark_info[64] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[64,count_aux_PDB[64]] = my_protein.read_highest_resolution_shell_low_data_set()
                    rmsd_array[64,count_aux_PDB[64]] =  rmsd[i]
                    count_aux_PDB[64] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_completeness_for_shell() method
                if my_protein.read_completeness_for_shell() == None:
                    no_pdb_remark_info[65,i] = i
                    missing_pdb_remark_info[65] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[65,count_aux_PDB[65]] = my_protein.read_completeness_for_shell()
                    rmsd_array[65,count_aux_PDB[65]] =  rmsd[i]
                    count_aux_PDB[65] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_i_sigma_i_for_shell() method
                if my_protein.read_i_sigma_i_for_shell() == None:
                    no_pdb_remark_info[66,i] = i
                    missing_pdb_remark_info[66] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[66,count_aux_PDB[66]] = my_protein.read_i_sigma_i_for_shell()
                    rmsd_array[66,count_aux_PDB[66]] =  rmsd[i]
                    count_aux_PDB[66] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_solvent_content() method
                if my_protein.read_solvent_content() == None:
                    no_pdb_remark_info[67,i] = i
                    missing_pdb_remark_info[67] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[67,count_aux_PDB[67]] = my_protein.read_solvent_content()
                    rmsd_array[67,count_aux_PDB[67]] =  rmsd[i]
                    count_aux_PDB[67] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_matthews_coefficient() method
                if my_protein.read_matthews_coefficient() == None:
                    no_pdb_remark_info[68,i] = i
                    missing_pdb_remark_info[68] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[68,count_aux_PDB[68]] = my_protein.read_matthews_coefficient()
                    rmsd_array[68,count_aux_PDB[68]] =  rmsd[i]
                    count_aux_PDB[68] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array         
                
                # Calls read_missing_res() method
                if my_protein.read_missing_res() == 0:
                    no_pdb_remark_info[69,i] = i
                    missing_pdb_remark_info[69] = 1
                    print("No missing residues in the structure.")
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[69,count_aux_PDB[69]] = my_protein.read_missing_res()
                    rmsd_array[69,count_aux_PDB[69]] =  rmsd[i]
                    count_aux_PDB[69] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array 
                
                # For number_TOR
                if number_TOR[i] == None:
                    no_pdb_remark_info[70,i] = i
                    missing_pdb_remark_info[70] = 1
                else:                               
                    pdb_remark_info[70,count_aux_PDB[70]] = number_TOR[i]
                    rmsd_array[70,count_aux_PDB[70]] =  rmsd[i]
                    count_aux_PDB[70] += 1          
                       
                # For number_prot_atm_in
                if number_prot_atm_in == 0:
                    no_pdb_remark_info[71,i] = i
                    missing_pdb_remark_info[71] = 1
                else:                               
                    pdb_remark_info[71,count_aux_PDB[71]] = number_prot_atm_in
                    rmsd_array[71,count_aux_PDB[71]] =  rmsd[i]
                    count_aux_PDB[71] += 1          
                
                # For number_lig_atm_in
                if number_lig_atm_in == 0:
                    no_pdb_remark_info[72,i] = i
                    missing_pdb_remark_info[72] = 1
                else:                               
                    pdb_remark_info[72,count_aux_PDB[72]] = number_lig_atm_in
                    rmsd_array[72,count_aux_PDB[72]] =  rmsd[i]
                    count_aux_PDB[72] += 1 
                
                # For number_water_atm_in
                if number_water_atm_in == 0:
                    no_pdb_remark_info[73,i] = i
                    missing_pdb_remark_info[73] = 1
                else:                               
                    pdb_remark_info[73,count_aux_PDB[73]] = number_water_atm_in
                    rmsd_array[73,count_aux_PDB[73]] =  rmsd[i]
                    count_aux_PDB[73] += 1
                    
                # For number_all_atm_in
                if number_all_atm_in == 0:
                    no_pdb_remark_info[74,i] = i
                    missing_pdb_remark_info[74] = 1
                else:                               
                    pdb_remark_info[74,count_aux_PDB[74]] = number_all_atm_in
                    rmsd_array[74,count_aux_PDB[74]] =  rmsd[i]
                    count_aux_PDB[74] += 1  
                
                # For number_active_atm_in
                if number_active_atm_in == 0:
                    no_pdb_remark_info[75,i] = i
                    missing_pdb_remark_info[75] = 1
                else:                               
                    pdb_remark_info[75,count_aux_PDB[75]] = number_active_atm_in
                    rmsd_array[75,count_aux_PDB[75]] =  rmsd[i]
                    count_aux_PDB[75] += 1 
                    
                # Calls protein_MW("Protein") method
                if my_protein.protein_MW("Protein") == None:
                    no_pdb_remark_info[76,i] = i
                    missing_pdb_remark_info[76] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[76,count_aux_PDB[76]] = my_protein.protein_MW("Protein")
                    rmsd_array[76,count_aux_PDB[76]] =  rmsd[i]
                    count_aux_PDB[76] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array 
                                     
                # Calls make_sphere method 
                my_protein.make_sphere(count_spheres,radius)
                
                # Calls calculate_B_value_Occupancy() method for ligand and co-factor atoms
                b_value_ligand_in, occupancy_ligand_in = my_protein.calculate_B_value_Occupancy("Ligand")
                # For b_value_ligand_in, occupancy_ligand_in
                if b_value_ligand_in == 0.0 or occupancy_ligand_in == 0.0:
                    no_pdb_remark_info[77,i] = i
                    no_pdb_remark_info[78,i] = i
                    missing_pdb_remark_info[77] = 1
                    missing_pdb_remark_info[78] = 1
                else:                               
                    pdb_remark_info[77,count_aux_PDB[77]] = b_value_ligand_in
                    pdb_remark_info[78,count_aux_PDB[78]] = occupancy_ligand_in
                    rmsd_array[77,count_aux_PDB[77]] =  rmsd[i]
                    rmsd_array[78,count_aux_PDB[78]] =  rmsd[i]
                    count_aux_PDB[77] += 1 
                    count_aux_PDB[78] += 1 
            
                # Calls calculate_B_value_Occupancy() method for water atoms
                b_value_water_in, occupancy_water_in = my_protein.calculate_B_value_Occupancy("Water")
                # For b_value_water_in, occupancy_water_in
                if b_value_water_in == None or occupancy_water_in == None:
                    no_pdb_remark_info[79,i] = i
                    no_pdb_remark_info[80,i] = i
                    missing_pdb_remark_info[79] = 1
                    missing_pdb_remark_info[80] = 1
                else:                               
                    pdb_remark_info[79,count_aux_PDB[79]] = b_value_water_in
                    pdb_remark_info[80,count_aux_PDB[80]] = occupancy_water_in
                    rmsd_array[79,count_aux_PDB[79]] =  rmsd[i]
                    rmsd_array[80,count_aux_PDB[80]] =  rmsd[i]
                    count_aux_PDB[79] += 1 
                    count_aux_PDB[80] += 1 
            
                # Calls calculate_B_value_Occupancy() method for whole structure
                b_value_whole_in, occupancy_whole_in = my_protein.calculate_B_value_Occupancy("Whole")
                # For b_value_whole_in, occupancy_whole_in
                if b_value_whole_in == None or occupancy_whole_in == None:
                    no_pdb_remark_info[81,i] = i
                    no_pdb_remark_info[82,i] = i
                    missing_pdb_remark_info[81] = 1
                    missing_pdb_remark_info[82] = 1
                else:                               
                    pdb_remark_info[81,count_aux_PDB[81]] = b_value_whole_in
                    pdb_remark_info[82,count_aux_PDB[82]] = occupancy_whole_in
                    rmsd_array[81,count_aux_PDB[81]] =  rmsd[i]
                    rmsd_array[82,count_aux_PDB[82]] =  rmsd[i]
                    count_aux_PDB[81] += 1 
                    count_aux_PDB[82] += 1 
            
                # Calls calculate_B_value_Occupancy() method for main-chain protein atoms
                b_value_protein_MC_in, occupancy_protein_MC_in = my_protein.calculate_B_value_Occupancy("ProteinMC")
                # For b_value_protein_MC_in, occupancy_protein_MC_in
                if b_value_protein_MC_in == None or occupancy_protein_MC_in == None:
                    no_pdb_remark_info[83,i] = i
                    no_pdb_remark_info[84,i] = i
                    missing_pdb_remark_info[83] = 1
                    missing_pdb_remark_info[84] = 1
                else:                               
                    pdb_remark_info[83,count_aux_PDB[83]] = b_value_protein_MC_in
                    pdb_remark_info[84,count_aux_PDB[84]] = occupancy_protein_MC_in
                    rmsd_array[83,count_aux_PDB[83]] =  rmsd[i]
                    rmsd_array[84,count_aux_PDB[84]] =  rmsd[i]
                    count_aux_PDB[83] += 1 
                    count_aux_PDB[84] += 1 
                
                # Calls calculate_B_value_Occupancy() method for side-chain protein atoms
                b_value_protein_SC_in, occupancy_protein_SC_in = my_protein.calculate_B_value_Occupancy("ProteinSC")
                # For b_value_protein_SC_in, occupancy_protein_MC_in
                if b_value_protein_SC_in == None or occupancy_protein_SC_in == None:
                    no_pdb_remark_info[85,i] = i
                    no_pdb_remark_info[86,i] = i
                    missing_pdb_remark_info[85] = 1
                    missing_pdb_remark_info[86] = 1
                else:                               
                    pdb_remark_info[85,count_aux_PDB[85]] = b_value_protein_SC_in
                    pdb_remark_info[86,count_aux_PDB[86]] = occupancy_protein_SC_in
                    rmsd_array[85,count_aux_PDB[85]] =  rmsd[i]
                    rmsd_array[86,count_aux_PDB[86]] =  rmsd[i]
                    count_aux_PDB[85] += 1 
                    count_aux_PDB[86] += 1 
                
                # Calls calculate_B_value_Occupancy() method for active-ligand atoms
                b_value_active_in, occupancy_active_in = my_protein.calculate_B_value_Occupancy("Active")
                # For b_value_active_in, occupancy_active_in
                if b_value_active_in == None or occupancy_active_in == None:
                    no_pdb_remark_info[87,i] = i
                    no_pdb_remark_info[88,i] = i
                    missing_pdb_remark_info[87] = 1
                    missing_pdb_remark_info[88] = 1
                else:                               
                    pdb_remark_info[87,count_aux_PDB[87]] = b_value_active_in
                    pdb_remark_info[88,count_aux_PDB[88]] = occupancy_active_in
                    rmsd_array[87,count_aux_PDB[87]] =  rmsd[i]
                    rmsd_array[88,count_aux_PDB[88]] =  rmsd[i]
                    count_aux_PDB[87] += 1 
                    count_aux_PDB[88] += 1 
                
                # To be added to the next calls of methods (prevous [number] plus 1
                number_of_previous_methods = 89 # It was 133, 22 methods were removed since they have no values in a data set with 1300 structures
                                                # It was 111
                # Calls calculate_unit_cell_vol method
                my_vol_unit_cell, my_vol_unit_cell_star, my_max_num_ref = my_protein.calculate_unit_cell_vol()
                if my_max_num_ref == None:        # If None we don't have to read attribute from the object my_protein
                    no_pdb_remark_info[number_of_previous_methods,i] = i
                    no_pdb_remark_info[number_of_previous_methods+1,i] = i
                    no_pdb_remark_info[number_of_previous_methods+2,i] = i
                    
                    missing_pdb_remark_info[number_of_previous_methods] = 1
                    missing_pdb_remark_info[number_of_previous_methods+1] = 1
                    missing_pdb_remark_info[number_of_previous_methods+2] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] = my_vol_unit_cell
                    pdb_remark_info[number_of_previous_methods+1,count_aux_PDB[number_of_previous_methods+1]] = my_vol_unit_cell_star
                    pdb_remark_info[number_of_previous_methods+2,count_aux_PDB[number_of_previous_methods+2]] = my_max_num_ref
                    
                    rmsd_array[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] =  rmsd[i]
                    rmsd_array[number_of_previous_methods+1,count_aux_PDB[number_of_previous_methods+1]] =  rmsd[i]
                    rmsd_array[number_of_previous_methods+2,count_aux_PDB[number_of_previous_methods+2]] =  rmsd[i]
                    
                    count_aux_PDB[number_of_previous_methods] += 1
                    count_aux_PDB[number_of_previous_methods+1] += 1
                    count_aux_PDB[number_of_previous_methods+2] += 1 
                               
                # We used index count_aux_PDB because we may have the attribute missing from the object my_proteu
                # This also garantees that all attribute values will occupy the first positions of the array
                
                # Updated after calculate_unit_cell_vol method
                number_of_previous_methods += 3
                                
                # Calls radius_of_gyration method 
                if my_protein.radius_of_gyration() == None :
                    no_pdb_remark_info[number_of_previous_methods,i] = i
                    missing_pdb_remark_info[number_of_previous_methods] = 1
                else:                               # In this case we have to read attribute from the object my_protein
                    pdb_remark_info[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] = my_protein.radius_of_gyration()
                    rmsd_array[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] =  rmsd[i]
                    count_aux_PDB[number_of_previous_methods] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array 
                    # Adds line about radius of gyration to remark_output_info
                    line_4_remark_output_info =     "Radius of gyration for non-H atoms in protein "
                    remark_output_info.append(line_4_remark_output_info)
                    
                # Updated after radius_of_gyration method
                number_of_previous_methods += 1
                
                # Looping through spheres
                for index_of_sphere in range(count_spheres):
                    # Calls calculate_B_value_Occupancy() method for Sphere0 atoms
                    string_sphere = "Sphere"+str(index_of_sphere)[0:1]
                    string_sphere_MC = string_sphere+"MC"
                    string_sphere_SC = string_sphere+"SC"
                    
                    # Calls calculate_B_value_Occupancy(string_sphere) method
                    b_value_array_sphere_all[index_of_sphere,i], occupancy_array_sphere_all[index_of_sphere,i] = my_protein.calculate_B_value_Occupancy(string_sphere)
                    b_value_array_sphere_MC[index_of_sphere,i], occupancy_array_sphere_MC[index_of_sphere,i] = my_protein.calculate_B_value_Occupancy(string_sphere_MC)
                    b_value_array_sphere_SC[index_of_sphere,i], occupancy_array_sphere_SC[index_of_sphere,i] = my_protein.calculate_B_value_Occupancy(string_sphere_SC)
                    
                    # For B-value (all atoms)
                    if b_value_array_sphere_all[index_of_sphere,i] == None:
                        no_pdb_remark_info[number_of_previous_methods,i] = i
                        missing_pdb_remark_info[number_of_previous_methods] = 1
                        
                    else:                               # In this case we have to read attribute from the object my_protein
                        pdb_remark_info[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] = b_value_array_sphere_all[index_of_sphere,i]
                        rmsd_array[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] =  rmsd[i]
                        count_aux_PDB[number_of_previous_methods] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array 
                        line_4_remark_output_info = "Mean B-value (radius<="+str(radius[index_of_sphere])[0:5]+" A)             "
                        remark_output_info.append(line_4_remark_output_info)
                        
                    # Updated after sphere methods
                    number_of_previous_methods += 1
                    
                    # For occupancy (all atoms)
                    if occupancy_array_sphere_all[index_of_sphere,i] == None:
                        no_pdb_remark_info[number_of_previous_methods,i] = i
                        missing_pdb_remark_info[number_of_previous_methods] = 1
                        
                    else:                               # In this case we have to read attribute from the object my_protein
                        pdb_remark_info[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] = occupancy_array_sphere_all[index_of_sphere,i]
                        rmsd_array[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] =  rmsd[i]
                        count_aux_PDB[number_of_previous_methods] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array 
                        line_4_remark_output_info = "Mean occupancy (radius<="+str(radius[index_of_sphere])[0:5]+" A)          "
                        remark_output_info.append(line_4_remark_output_info)
                        
                    # Updated after sphere methods
                    number_of_previous_methods += 1
                    
                    # For B-value (main-chain atoms)
                    if b_value_array_sphere_MC[index_of_sphere,i] == None:
                        no_pdb_remark_info[number_of_previous_methods,i] = i
                        missing_pdb_remark_info[number_of_previous_methods] = 1
                        
                    else:                               # In this case we have to read attribute from the object my_protein
                        pdb_remark_info[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] = b_value_array_sphere_MC[index_of_sphere,i]
                        rmsd_array[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] =  rmsd[i]
                        count_aux_PDB[number_of_previous_methods] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array 
                        line_4_remark_output_info = "Mean B-value (radius<="+str(radius[index_of_sphere])[0:5]+" A MC atoms)       "
                        remark_output_info.append(line_4_remark_output_info)
                        
                    # Updated after sphere methods
                    number_of_previous_methods += 1
                    
                    # For occupancy (main-chain atoms)
                    if occupancy_array_sphere_MC[index_of_sphere,i] == None:
                        no_pdb_remark_info[number_of_previous_methods,i] = i
                        missing_pdb_remark_info[number_of_previous_methods] = 1
                        
                    else:                               # In this case we have to read attribute from the object my_protein
                        pdb_remark_info[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] = occupancy_array_sphere_MC[index_of_sphere,i]
                        rmsd_array[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] =  rmsd[i]
                        count_aux_PDB[number_of_previous_methods] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array 
                        line_4_remark_output_info = "Mean occupancy (radius<="+str(radius[index_of_sphere])[0:5]+"A MC atoms)       "
                        remark_output_info.append(line_4_remark_output_info)
                        
                    # Updated after sphere methods
                    number_of_previous_methods += 1
                    
                    # For B-value (side-chain atoms)
                    if b_value_array_sphere_SC[index_of_sphere,i] == None:
                        no_pdb_remark_info[number_of_previous_methods,i] = i
                        missing_pdb_remark_info[number_of_previous_methods] = 1
                        
                    else:                               # In this case we have to read attribute from the object my_protein
                        pdb_remark_info[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] = b_value_array_sphere_SC[index_of_sphere,i]
                        rmsd_array[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] =  rmsd[i]
                        count_aux_PDB[number_of_previous_methods] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array 
                        line_4_remark_output_info = "Mean B-value (radius<="+str(radius[index_of_sphere])[0:5]+"A SC atoms)       "
                        remark_output_info.append(line_4_remark_output_info)
                        
                    # Updated after sphere methods
                    number_of_previous_methods += 1
                    
                    # For occupancy (side-chain atoms)
                    if occupancy_array_sphere_SC[index_of_sphere,i] == None:
                        no_pdb_remark_info[number_of_previous_methods,i] = i
                        missing_pdb_remark_info[number_of_previous_methods] = 1
                        
                    else:                               # In this case we have to read attribute from the object my_protein
                        pdb_remark_info[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] = occupancy_array_sphere_SC[index_of_sphere,i]
                        rmsd_array[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] =  rmsd[i]
                        count_aux_PDB[number_of_previous_methods] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array 
                        line_4_remark_output_info = "Mean occupancy (radius<="+str(radius[index_of_sphere])[0:5]+" A SC atom)       "
                        remark_output_info.append(line_4_remark_output_info)
                        
                    # Updated after sphere methods
                    number_of_previous_methods += 1
                    
                    # For Matthews coefficient
                    if my_protein.protein_MW(string_sphere) == None : 
                        no_pdb_remark_info[number_of_previous_methods,i] = i
                        missing_pdb_remark_info[number_of_previous_methods] = 1
                        
                    else:                               # In this case we have to read attribute from the object my_protein
                        pdb_remark_info[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] = volume[index_of_sphere]/my_protein.protein_MW(string_sphere)
                        rmsd_array[number_of_previous_methods,count_aux_PDB[number_of_previous_methods]] =  rmsd[i]
                        count_aux_PDB[number_of_previous_methods] += 1          # We used index count_aux_PDB because we may have the attribute missing from the object my_protein
                                                    # This also garantees that all attribute values will occupy the first positions of the array 
                        line_4_remark_output_info = "Matthews coefficient (radius<="+str(radius[index_of_sphere])[0:5]+"A)       "
                        remark_output_info.append(line_4_remark_output_info)
                                
                    # Updated after sphere methods
                    number_of_previous_methods += 1
                                    
            # Test if there is any request for correlation coefficient
            if count_PDB > 0 and stdock: 
                print("\nCalculating Spearman's correlation coefficient...")
                sandres_log_file.write ("Calculating Spearman's correlation coefficient...\n")
            else:
                print("\nThere is no request for calculating Spearman's correlation coefficient.")
                sandres_log_file.write ("\nThere is no request for calculating Spearman's correlation coefficient.\n")
        
            # For STDOCK
            # I'll use lists instead of arrays since we have an iteration to recreate output$.csv that will be used to calculates stata
            print("\n\n######################################### Statistical Analysis ##########################################")
            sandres_log_file.write ("\n\n######################################### Statistical Analysis ##########################################\n")
            print("\nCorrelation between docking RMSD and the following parameters")
            sandres_log_file.write ("\nCorrelation between docking RMSD and the following parameters\n")
            print("Parameter      \t\t\t\t\t N\trho\t\tp-value1\t R2\tp-value2")
            sandres_log_file.write ("Parameter\t\t\t\t\t\t\t    N   rho\t   p-value1  \tR2\t\tp-value2\n")
            
            for j in range(number_of_previous_methods):  # -1 or None
                # Fix the number of characters in the output file name
                my_str = str(j)
                if len(my_str)< 4:
                    my_str = str((3-len(my_str) )*"0")+my_str
                    
                root_file_name = project_dir+"stdock"   # For STDOCK
                   
                # Instantiates a Spearman object
                # Final results for Spearman's Rank Correlation
                # Handles missing information
                if missing_pdb_remark_info[j]:
                    count_loop_lines = count_aux_PDB[j] 
                    stat_info = Spearman(  list(rmsd_array[j,0:count_aux_PDB[j]])  ,list(pdb_remark_info[j,0:count_aux_PDB[j]]))
                    stat_info.make_csv_file(2,root_file_name+my_str+".csv",list(rmsd_array[j,0:count_aux_PDB[j]]), list(pdb_remark_info[j,0:count_aux_PDB[j]]))
                else:
                    count_loop_lines = len(rmsd)
                    stat_info = Spearman(rmsd,list(pdb_remark_info[j,0:count_PDB]))
                    stat_info.make_csv_file(2,root_file_name+my_str+".csv",rmsd,list(pdb_remark_info[j,0:count_PDB ]))
                    
                # Prints statistical information (std_deviation,pearson_cc,pearson_p)
                if count_loop_lines > 2:
                    try:
                        ccR[j],ccP[j],my_pearson_in,my_pearson_p_in = stat_info.correlation_coefficient2()
                    except:
                        ccR[j] = 10.0
                        ccP[j] = None  
                        my_pearson_in = 10
                        my_pearson_p_in = None 
                    if ccR[j] == 10.0 : # To avoid error messages
                        # Fix the number of characters
                        my_str_info1 = str(remark_output_info[j])
                        if len(my_str_info1)< 60:
                            my_str_info2 = my_str_info1+str((59-len(my_str_info1) )*" ")
                        else:
                            my_str_info2 = my_str_info1[0:60]
                        
                        sandres_new_line1 = my_str_info2+str( "\t%3d\t    ND\t\t    ND\t    ND\t\t    ND"%(count_loop_lines ) )+"\n"
                        sandres_new_line2 = my_str_info1+str( ",\t%3d,\t ND,\t\tND,\t ND,\t\tND,"%(count_loop_lines ) )+"\t\t stdock"+str(my_str)+".csv \n"
                        print(remark_output_info[j],"\t%3d\t ND\t\t ND"%(count_loop_lines ),"\t\t","stdock"+str(my_str)+".csv" )
                        sandres_log_file.write (sandres_new_line1)
                        sandres_tab.write(sandres_new_line2)
                    else:
                        # Fix the number of characters
                        my_str_info1 = str(remark_output_info[j])
                        if len(my_str_info1)< 60:
                            my_str_info2 = my_str_info1+str((59-len(my_str_info1) )*" ")
                        else:
                            my_str_info2 = my_str_info1[0:60]
                        sandres_new_line1 = my_str_info2+str("%3d\t%6.3f\t\t%6.3e\t%6.3f\t%6.3e"%(count_loop_lines,ccR[j],ccP[j],my_pearson_in,my_pearson_p_in ))
                        sandres_new_line2 = my_str_info1+str( ",\t%3d,\t%6.3f,\t\t%6.3e,\t%6.3f,\t%6.3e"%(count_loop_lines,ccR[j],ccP[j],my_pearson_in,my_pearson_p_in ))+",\t\t stdock"+str(my_str)+".csv \n"
                        print(remark_output_info[j],"\t%3d\t%6.3f\t\t%6.3e\t%6.3f\t%6.3e"%(count_loop_lines,ccR[j],ccP[j],my_pearson_in,my_pearson_p_in ),"\t\t","stdock"+str(my_str)+".csv" )
                        sandres_log_file.write (sandres_new_line1+"\n")
                        sandres_tab.write(sandres_new_line2)
                else:
                    # Fix the number of characters
                    my_str_info1 = str(remark_output_info[j])
                    if len(my_str_info1)< 60:
                        my_str_info2 = my_str_info1+str((59-len(my_str_info1) )*" ")
                    else:
                        my_str_info2 = my_str_info1[0:60]
                    sandres_new_line1 = my_str_info2+str( "\t%3d\t    ND\t\t    ND\t    ND\t\t    ND"%(count_loop_lines ) )+"\n"
                    sandres_new_line2 = my_str_info2+str( ",\t%3d,\t ND,\t\tND,\t ND,\t\tND,"%(count_loop_lines ) )+"\t\t stdock"+str(my_str)+".csv \n"
                    print(remark_output_info[j],"\t%3d\t ND\t\t ND\t ND\t\t ND"%(count_loop_lines ),"\t\t","stdock"+str(my_str)+".csv" )
                    #sandres_log_file.write (bubble_line1)
                    sandres_tab.write(sandres_new_line2) 
            print("\n\n########################################################################################################")
            sandres_log_file.write ("\n\n#########################################################################################################\n")
            print("\nND: Not determined when the number of PDB files for which the information is available is less than 3! or all elements in the list are the same.")
            sandres_log_file.write ("\nND: Not determined if number of PDB files for which the information is available is less than 3!\n")
            
            sandres_line = "\nN is the number of structures used in the statistical analysis for each parameter"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            
            sandres_line = "rho is Spearman rank-order correlation coefficient"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
                
            sandres_line = "p-value1 is for rho"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
                
            sandres_line = "R2 is the squared Pearson correlation coefficient"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
                
            sandres_line = "p-value2 is for R2"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
                
            sandres_line = "\n\nAnalysis finished here for STDOCK request!"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            #Close files
            sandres_log_file.close()
            sandres_tab.close()
            #sys.exit()    
            ##################################################################################################
            # Ends looping to gather PDB information from REMARKs                                            #
            ##################################################################################################   
               
        # FNDWAT (FiND WATer):
        # This task searches for water molecules close to the active ligand and generated a PDB files with water molecules
        # found inside a sphere for which the radius has been given
        if fndwat:
            count_number_of_water_molecules_file = 0
            count_number_of_no_water_molecules_file = 0 
            sandres_line = "\nAnalysis of water molecules inside a sphere centered at ligand structure"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            # Looping to write PDB files with water sphere for FNDWAT
            for i in range(count_PDB_wat):
                # Shows header
                sandres_line = "\nParsing PDB file: "+name_PDB_wat[i]
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
                
                # Instantiates a protein object
                my_protein_wat = ProteinStructure(name_PDB_wat[i])
            
                # Calls make_list_4_prot_atoms() method
                number_prot_atm_in_wat,number_lig_atm_in_wat,number_water_atm_in_wat,number_all_atm_in_wat,number_active_atm_in_wat = my_protein_wat.make_list_of_atoms(name_LIG_wat[i],chain_LIG_wat[i],number_LIG_wat[i])
                number_prot_atm_wat.append(number_prot_atm_in_wat)
                number_lig_atm_wat.append(number_lig_atm_in_wat)
                number_water_atm_wat.append(number_water_atm_in_wat)
                number_all_atm_wat.append(number_all_atm_in_wat)
                number_active_atm_wat.append(number_active_atm_in_wat)
            
                number_of_water_molecules = my_protein_wat.make_sphere_wat(water_dir,name_PDB_wat_sphere[i],name_LIG_wat[i],radius_wat[i],max_number_wat[i])
                
                # Counts number of pDB for which water molecules have been found close to the ligand
                if number_of_water_molecules > 0:
                    my_list_of_pdb_with_water.append(name_PDB_wat_sphere[i])
                    count_number_of_water_molecules_file += 1
                else:
                    my_list_of_pdb_with_no_water.append(name_PDB_wat_sphere[i])
                    count_number_of_no_water_molecules_file +=1
            
            sandres_line = "\n\nOnly files for which water molecules have been found will written in the directory:"+water_dir
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            sandres_line = "\n\nList of PDB files for which water molecules have been found close to the ligand"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            for my_line in my_list_of_pdb_with_water:
                sandres_line = my_line
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")
            sandres_line = "\nList of PDB files for which water molecules have NOT been found close to the ligand"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            for my_line in my_list_of_pdb_with_no_water:
                sandres_line = my_line
                print(sandres_line)
                sandres_log_file.write (sandres_line+"\n")  
            
            sandres_line = "\n######################################################################"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            sandres_line = "Summary of results for FNDWAT:"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            sandres_line = "Water directory: "+water_dir
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            sandres_line = "Total number of PDB files: "+str(count_PDB_wat)
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            sandres_line = "Total number of files with water molecules: "+str(count_number_of_water_molecules_file)
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            sandres_line = "Total number of files with NO water molecules: "+str(count_number_of_no_water_molecules_file)
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")  
            sandres_line = "######################################################################"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            sandres_line = "\n\nAnalysis finished here for FNDWAT request!"
            print(sandres_line)
            sandres_log_file.write (sandres_line+"\n")
            sandres_log_file.close()
            #sys.exit()
        
        # ENDOF
        if eof_flag:
            eof_flag = False   
            
            # Reset lists that may be needed for other tasks
            name_PDB                        = []
            name_LIG                        = []
            chain_LIG                       = []
            number_LIG                      = []
            
            # Reset counts
            count_PDB = 0
            #count_aux_PDB = 0
            count_PDB_wat = 0
            
            # Beeps
            print("\a")
            my_input_csv_file.close()
            
        #input_name = "quit()" 
        my_input_csv_file.close()
        
        break
        
# Main program
main()
