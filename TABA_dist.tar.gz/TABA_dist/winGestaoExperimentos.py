#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import func_manipulaArquivos as manip
from datetime import datetime
from PyQt4 import QtGui, QtCore  # Import the PyQt4 module we'll need
from PyQt4.QtGui import QApplication, QDialog
from func_Gerais import grava
from func_RenomeiaArq import diretorio
import interfaceGestaoExperimentos
import os
from func_Gerais import pegaConfig, get_pastas, grava
from time import sleep

class gestaoExperimentos(QtGui.QMainWindow, interfaceGestaoExperimentos.Ui_MainWindow_manageFiles):
    def __init__(self, parent = None):
        QtGui.QWidget.__init__(self, parent)
        self.setupUi(self)
        self.window1 = None
        self.setFixedSize(800,680)
        nome = pegaConfig("descricaoDataset")
        nome = nome.strip()
        self.listaExperimentos = []
        now = str(datetime.now())
        now = now.replace(" ", "")
        now = now.replace("-", "")
        now = now.replace(":", "")
        d = "_"+now[0:14]
        self.atualizaNomes()
        self.lineEdit_experimento.setText(nome+d)
        self.label_experimento.setText(nome)
        self.recuperaInfos()

    def atualizaNomes(self):
        self.list1 = get_pastas("./conjuntoExperimentos/")
        self.comboBox_arquivos.clear()
        for text in self.list1:
            text = text.replace("./conjuntoExperimentos/","")
            self.listaExperimentos.append(text)
            self.comboBox_arquivos.addItem(text) # pega so arquivos de treino
            self.comboBox_arquivos.model().sort(0)
            self.comboBox_arquivos.setCurrentIndex(1) 
    def salvarExperimentos(self): 
        self.listaExperimentos = []
        self.list1 = get_pastas("./conjuntoExperimentos/")
        for text in self.list1:
            text = text.replace("./conjuntoExperimentos/","")
            self.listaExperimentos.append(text)

        # cria pasta para novo conjunto
        self.nomeConjunto = self.lineEdit_experimento.text()
        if self.nomeConjunto in self.listaExperimentos:
            reply = QtGui.QMessageBox.question(self, 'Message',"This set of experiments already exists. Do you want to replace?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
            if reply == QtGui.QMessageBox.Yes:
                self.salva()
                
        else:
            self.salva()
        pass
    def salva(self):
        reply = QtGui.QMessageBox.question(self, 'Message',"If you want, you can change the name of the experiment in the box next to it."+"\n"+"Do you really want to save this experiment?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
        if reply == QtGui.QMessageBox.Yes:        
            self.toolButton_salvar.setEnabled(False)
            nomePasta = "./conjuntoExperimentos/"+self.nomeConjunto
            manip.criaPasta(nomePasta)
            # copia pastas para o novo conjunto
            origem = "./arquivosSaida/"
            destino = nomePasta+origem.replace(".", "")
            manip.copiaPasta(origem, destino)
            origem = "./pdbs/"
            destino = nomePasta+origem.replace(".", "")
            manip.copiaPasta(origem, destino)
            origem = "./ki/"
            destino = nomePasta+origem.replace(".", "")
            manip.copiaPasta(origem, destino)
            origem = "./arquivosEntrada/"
            destino = nomePasta+origem.replace(".", "")
            manip.copiaPasta(origem, destino)
            self.atualizaNomes()
            QtGui.QMessageBox.information(self, "Message", "Operation completed")
        else:
            pass              
    def limpaPastas(self):
        # remove pastas existentes
        pasta = "./arquivosSaida/"
        manip.removePasta(pasta)
        pasta = "./pdbs/"
        manip.removePasta(pasta)
        pasta = "./ki/"
        manip.removePasta(pasta)
        pasta = "./arquivosEntrada/"
        manip.removePasta(pasta)
        # cria novas pastas
        nomePasta = "./arquivosSaida/"
        manip.criaPasta(nomePasta)
        nomePasta = "./pdbs/"
        manip.criaPasta(nomePasta)
        nomePasta = "./ki/"
        manip.criaPasta(nomePasta)
        nomePasta = "./arquivosEntrada/"
        manip.criaPasta(nomePasta)
        self.criaArquivoBase()
    def recuperarExperimentos(self):
        self.escondeBotoes()
        reply = QtGui.QMessageBox.question(self, 'Message',"Do you really want to recover this experiment?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
        if reply == QtGui.QMessageBox.Yes:     
                   
            self.limpaPastas()
            self.nomeConjunto = self.comboBox_arquivos.currentText()
            # copia pastas para o novo conjunto
            origem = "./conjuntoExperimentos/"+self.nomeConjunto+"/arquivosSaida/"
            destino = "./arquivosSaida/"
            manip.copiaPasta(origem, destino)
            origem = "./conjuntoExperimentos/"+self.nomeConjunto+"/pdbs/"
            destino = "./pdbs/"
            manip.copiaPasta(origem, destino)
            origem =  "./conjuntoExperimentos/"+self.nomeConjunto+"/ki/"
            destino = "./ki/"
            manip.copiaPasta(origem, destino)
            origem =  "./conjuntoExperimentos/"+self.nomeConjunto+"/arquivosEntrada/"
            destino = "./arquivosEntrada/"
            manip.copiaPasta(origem, destino)
            self.recuperaInfos()
            self.label_experimento.setText(pegaConfig("descricaoDataset").strip())
            now = str(datetime.now())
            now = now.replace(" ", "")
            now = now.replace("-", "")
            now = now.replace(":", "")
            d = "_"+now[0:14]
            self.lineEdit_experimento.setText(pegaConfig("descricaoDataset").strip()+d)
            QtGui.QMessageBox.information(self, "Message", "Operation completed")
            self.mostraBotoes()
        else:
            self.mostraBotoes()
            pass            
        

    def limpar(self):        
        reply = QtGui.QMessageBox.question(self, 'Message',"Are you sure you want to delete this set of experiments?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)
        if reply == QtGui.QMessageBox.Yes:
            self.limpaPastas()
            self.toolButton_limpar.setEnabled(False)
            self.lineEdit_experimento.clear()
            QtGui.QMessageBox.information(self, "Message", "Operation completed")
        else:
            pass
                
    def sair(self):        
        self.close()
        
                
    def escondeBotoes(self):
        self.toolButton_salvar.setEnabled(False)
        self.toolButton_recuperar.setEnabled(False)
        self.toolButton_limpar.setEnabled(False)
        self.toolButton_exit.setEnabled(False)
    def mostraBotoes(self):
        self.toolButton_salvar.setEnabled(True)
        self.toolButton_recuperar.setEnabled(True)
        self.toolButton_limpar.setEnabled(True)
        self.toolButton_exit.setEnabled(True)
        
    def criaArquivoBase(self):
        #regrava arquivo ml.in
        l1 = "LinearRegression,True,True,True"+"\n"
        l2 = "Lasso,0.1,True,True,False,True,1000,0.0001,True,False,random,1123581321"+"\n"
        l3 = "LassoCV,0.1,True,True,False,True,1000,0.0001,True,False,random,1123581321"+"\n"
        l4 = "Ridge,1.0,True,True,True,1000,0.001,auto"+"\n"
        l5 = "RidgeCV,0.05,2.0,0.001,True,True,True,1000,0.001,auto"+"\n"
        l6 = "ElasticNet,0.1,0.5,True,False,True,1000,True,0.0001,True,False,1123581321,random"+"\n"
        l7 = "ElasticNetCV,0.1,0.15,15,0.5,True,False,True,1000,True,0.0001,True,False,1123581321,random"
        texto1 = l1+l2+l3+l4+l5+l6+l7
        texto2 = "null"
        texto3 = "<descricaoDataset>,null"+"\n"+"<tipoAfinidade>,Ki"

        arquivoSaida = "./arquivosEntrada/ml.in"
        grava(texto1, arquivoSaida)
        arquivoSaida = "./arquivosEntrada/pdbsProteina.txt"
        grava(texto2, arquivoSaida)
        arquivoSaida = "./arquivosEntrada/config.csv"
        grava(texto3, arquivoSaida)
    def recuperaInfos(self):
        self.label_descricao.setText(pegaConfig("descricaoDataset").strip())
        if not(pegaConfig("sperman") is None):
            self.label_comentarios.setText(pegaConfig("comentarios"))
            self.label_spearman.setText(pegaConfig("sperman").strip())
            self.label_melhorEquacao.setText(pegaConfig("melhorEquacao").strip())
            self.label_quantia.setText(pegaConfig("quantidadeProteinas").strip())
        else:
            self.label_comentarios.setText("null")
            self.label_spearman.setText("null")
            self.label_melhorEquacao.setText("null")
            self.label_quantia.setText("null")
