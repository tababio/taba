#setup.py
# no terminal digitar 'python setup.py bdist_msi'
from cx_Freeze import setup, Executable
import os
os.environ['TCL_LIBRARY'] = r'C:\Users\amaur\Anaconda3\tcl\tcl8.6'
os.environ['TK_LIBRARY'] = r'C:\Users\amaur\Anaconda3\tcl\tk8.6'
additional_mods = ['matplotlib','numpy']
setup(
    name = "taba",
    version = "1.0.0",
    options = {"build_exe": {
        'packages': ["os","idna","sys","ctypes","win32con"],
        'includes': additional_mods,   
        'include_msvcr': True,
    }},
    executables = [Executable("taba.py",base="Win32GUI")]
    )
