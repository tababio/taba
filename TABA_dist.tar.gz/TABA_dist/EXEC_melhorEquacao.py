from func_MelhorEquacao import melhor
from func_Gerais import grava
def main():
    diretorio = "./arquivosSaida/"
    num_col = 5 
    arquivo = "saidaKiTodos4.5_TE_Tre.csv"
    arquivo = arquivo.replace(".csv", "")
    metodos = ["LinearRegression","Ridge","RidgeCV","Lasso","LassoCV","ElasticNet","ElasticNetCV"]
    maior = 0
    for metodo in metodos:
        arq = "SF_"+arquivo+"_"+metodo+"_"+str(num_col)+"cols.csv"
        sperman, melhorEq = melhor(diretorio, arq)
        print(sperman, "___", melhorEq)
        if sperman > maior:
            maior = sperman
            melhorEquacao = melhorEq
            melhorArquivo = arq
    maior = str(maior)
    print("Melhor Sperman:",maior)
    print("Melhor Equacao:",melhorEquacao)
    print( "Melhor Arauivo", melhorArquivo)
    texto = "[melhor Sperman]"+","+maior+"\n"+"[melhor Equacao]"+","+melhorEquacao+"\n"+"[melhor Arquivo]"+","+melhorArquivo
    grava(texto, diretorio+"melhorEquacao.csv")

main()