#Usa arquivos separados para teste e aplica melhor formula
import sys
from func_Gerais import grava

def posicaoVariaveis(listaVariaveis,diretorio,arquivo): # recebe o diretorio e o arquivo SF
    arq = diretorio+arquivo
    posicao = []
    
    try:
        fo = open(arq, 'r')
    except IOError:
        sys.exit ("\n O arquivo "+arq+" nao foi encontrado")

    try:
        for line in fo:
            linha = line.split(",")
            for indice,x in enumerate(linha):
                if x in listaVariaveis:
                    posicao.append(indice)               
    except:
        pass
    fo.close()
    return posicao
def calcula(listaVariaveis,diretorio,arquivo,formula,tipo):#calcula usando os termoo de energia e gera arquivo com resultados para comparar
    arquivo = arquivo.replace("Tre", tipo)#o arquivo que vem é o de treino por isto substitui pelo tipo de arquivo
    arq = diretorio+arquivo
    pos = posicaoVariaveis(listaVariaveis, diretorio, arquivo) # pega posiccao dos valores das colunas das variaveis
    listaValores = []
    listaResultados = 'PDB, Predicted, Experimental'+"\n"
    try:
        fo = open(arq, 'r')
    except IOError:
        sys.exit ("\n O arquivo "+arq+" nao foi encontrado")
    
    try:
        fo.readline() # para pular primeira linha
        for line in fo: # percorre arquivo de teste
            
            linha = line.split(",")
            for x in pos:  # percorre lista de posicao e pega valores no arquivo de teste               
                listaValores.append(linha[x])
            n = 0
            equacao = formula
            for lin2 in listaVariaveis:  #substitui valores na equacao          
                equacao = equacao.replace(listaVariaveis[n], listaValores[n]) #substitui variavel pelo valor
                n = n+1
            #equacao = limpaEquacao(equacao)  # nao esta sendo utilizada
  
            valor = resolveEquacao(equacao)
            equacao = formula   
            listaValores = [] 
            listaResultados = listaResultados+linha[1]+","+str(valor)+","+linha[36]          
              
    except:
        pass
    fo.close()
    if tipo == "Tes":        
        arquivoParaSalvar = "resultadoTeste.csv"
    elif tipo == "Tre":
        arquivoParaSalvar = "resultadoTreino.csv"
    grava(listaResultados,diretorio+arquivoParaSalvar)
    return listaResultados
    
def resolveEquacao(equacao):
    result = eval(equacao)
    return result

def criaListaVariaveis(formula):
    # cria lista de variaveis da formula
    listaVariaveis = []
    usa = False # define se faz parte da vairável 
    var = ""
    for x in formula:
        if x == "(":
            usa = True            
        if x == ")":
            usa = False 
            listaVariaveis.append(var)
            var = ""      
        if usa:
            if x !="(": #desconsidera o parentese
                var = var+x
    return listaVariaveis
def geraCalculoPelaFormula(diretorio,arquivo,formula,tipo):
    listaVariaveis = criaListaVariaveis(formula)        
    return calcula(listaVariaveis,diretorio, arquivo, formula,tipo) #calcula usando os termoo de energia e gera arquivo com resultados para comparar
def limpaEquacao(equacao):
    '''
    * esta funcao nao sera utilizada pois nao e necessaria e causa erros
    equacao = equacao.replace("(","") #retira parentes a esquerda
    equacao = equacao.replace("-","-(")
    equacao = equacao.replace("+","+(")
    equacao = equacao.replace("(","",1) # ao final retira o primeiro parentese
    return equacao 
    '''
