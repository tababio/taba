#!/usr/bin/python
import time
import shutil
from distutils.dir_util import copy_tree
import os
from glob import glob
from datetime import datetime

now = datetime.now()
'''
diret = glob("./*/")
print(diret[2])
'''
#copia pasta
def copiaPasta(origem,destino):
    if  not os.path.exists(origem):
        #print("origem nao existe1")
        print("ID_func_manipulaArquivos_01")
    else:
        copy_tree(origem,destino)
#criar arquivo
def criaArquivo(arquivo):
    open(arquivo, 'a').close()

#remover pasta
def removePasta(pasta):
    if os.path.exists(pasta):
        shutil.rmtree(pasta)
#verifica se existe arquivo
def existeArquivo(arquivo):
    if os.path.exists(arquivo):
        return True
    else:
        return False
#criar pasta
def criaPasta(pasta):
    if not os.path.exists(pasta):
        os.makedirs(pasta)
    else:
        #print("pasta ja existe!!!")
        print('ID_func_manipulaArquvios_02')
#copia arquivo sobrescrevendo
def copiaArquivo(arquivo, diret):
    if os.path.exists(diret):
        shutil.copy(arquivo, diret)
    else:
        #print("destino nao existe3")
        print('ID_func_manipulaArquvios_03')
'''
deve ter opcao de apagar conjuntos
o nome deve ter mais a data e horario
'''
'''        
def main():
    # cria pasta para novo conjunto
    nomeConjunto = "teste"
    nomePasta = "./conjuntoExperimentos/"+nomeConjunto
    criaPasta(nomePasta)
    # copia pastas para o novo conjunto
    origem = "./outputFiles/"
    destino = nomePasta+origem.replace(".", "")
    copiaPasta(origem, destino)
    origem = "./pdbs/"
    destino = nomePasta+origem.replace(".", "")
    copiaPasta(origem, destino)
    origem = "./ki/"
    destino = nomePasta+origem.replace(".", "")
    copiaPasta(origem, destino)
   
    # remove pastas existentes
    pasta = "./arquivosSaida2/"
    removePasta(pasta)
    pasta = "./pdbs2/"
    removePasta(pasta)
    pasta = "./ki2/"
    removePasta(pasta)
    # cria novas pastas
    nomePasta = "./arquivosSaida2/"
    criaPasta(nomePasta)
    nomePasta = "./pdbs2/"
    criaPasta(nomePasta)
    nomePasta = "./ki2/"
    criaPasta(nomePasta)
main()
'''