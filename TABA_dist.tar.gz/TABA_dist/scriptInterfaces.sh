echo "Gerando arquivos Python das interfaces"

pyuic4 -x interfacePrincipal.ui -o interfacePrincipal.py
echo "interfacePrincipal.py"
pyuic4 -x interfaceExperimentoUsuario.ui -o interfaceExperimentoUsuario.py
echo "interfaceExperimentoUsuario.py"
pyuic4 -x interfaceGeraArquivosRegressao.ui -o interfaceGeraArquivosRegressao.py
echo "interfaceGeraArquivosRegressao.py"
pyuic4 -x interfaceBaixaPdbs.ui -o interfaceBaixaPdbs.py
echo "interfaceBaixaPdbs.py"
pyuic4 -x interfaceRegressao.ui -o interfaceRegressao.py
echo "interfaceRegressao.py"
pyuic4 -x interfaceCorrelacao.ui -o interfaceCorrelacao.py
echo "interfaceCorrelacao.py"
pyuic4 -x interfaceInformacoes.ui -o interfaceInformacoes.py
echo "interfaceInformacoes.py"
pyuic4 -x interfaceGestaoExperimentos.ui -o interfaceGestaoExperimentos.py
echo "interfaceGestaoExperimentos.py"

echo "interfaceAjuda.py"
pyuic4 -x interfaceAjuda.ui -o interfaceAjuda.py
echo "interfaceAjuda.py"


echo "fim"

