import sys

def melhor(arq, coeficiente, peloMenor): # recebe o diretorio e o arquivo SF
    # posiçoes R [3] R2 [4] speraman = 7
    val = 0
    melhorEquacao = ""
    pv1 = 0
    if peloMenor: # se procura o menor valor
            retorno = 9999999
    else:
        retorno = 0
    # define com qual coeficiente deve comparar
    if coeficiente == "r1": # coeficiente R
        coef = 4
    elif coeficiente == "r2": # coeficiente R
        coef = 3      
    elif coeficiente == "pvs": # confirmado que é spearman
        coef = 8 
    elif coeficiente == "pvp": # verificar  
        coef = 5  
    elif coeficiente == "sd": # coeficiente R
        coef = 2  
    elif coeficiente == "rmse": # coeficiente R
        coef = 13       
    elif coeficiente == "sp":
        coef = 7 # coeficiente spearman     
    try:
        fo = open(arq, 'r')
    except IOError:
        sys.exit ("\n O arquivo "+arq+" nao foi encontrado!!!")
        
    try:
        fo.readline()
        for line in fo:
            linhalimpa = line.replace(" ", "") #retira brancos
            linha = linhalimpa.split(",")
            lin = linha[coef]                    
            val = float(lin)

            if peloMenor:           
                if val < retorno:
                    retorno = val
                    melhorEquacao = linha[0]
                    pv2 = linha[8] 
            else:                   
                if val > retorno:
                    retorno = val
                    melhorEquacao = linha[0]
                    pv2 = linha[8] 
    except:
        pass
    return retorno,pv2,melhorEquacao

