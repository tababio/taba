from func_Gerais import leCsv


def pre_download(my_dir_in,my_file_in):
    """Function to check if the file is already in the structure directory"""
    file_present = False
    
    # Try to open file
    try:
        my_fo = open(my_dir_in+my_file_in,"r")
        file_present  = True
        my_fo.close()
        print(my_dir_in+my_file_in)
    except:
        file_present  = False
    
    # Return boolean variable
    return file_present 
def getBind(my_dir_in,structureId,binding_info):
    """Function to download CSV file with binding affinty"""
    import urllib.request, urllib.parse, urllib.error
    import time
    #import csv
    #import sys
    
    # String for local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Sets up initial values for variable and list
    check_if_code_in = False
    my_structureId_string = structureId.lower()
    my_binding_list = ["Ki","Kd","EC50","IC50","deltaG","deltaH","Ka"]
    
    # Looping through my_binding_list
    for bind_in in my_binding_list:
        if binding_info.upper() == bind_in.upper():
            binding_info1 = bind_in
                
    # Specify file
    file_2_download =my_structureId_string+".csv"
    
    # Check if file is already in the structure directory
    flag_4_file_present = pre_download(my_dir_in,file_2_download)
    if flag_4_file_present:
        check_if_code_in = True
        return check_if_code_in
    
    # Specify url
    #my_url = 'http://www.rcsb.org/pdb/rest/customReport?pdbids='+my_structureId_string+'&customReportColumns=structureId,chainId,ligandId,'+binding_info+',&service=wsfile&format=csv&ssa=n'
    my_url = 'http://www.rcsb.org/pdb/rest/customReport?pdbids='+my_structureId_string+'&customReportColumns=structureId,chainId,ligandId,'+binding_info1+'&service=wsfile&format=csv&ssa=n'

    # Try to download file    
    try: 
        file_object = urllib.request.urlopen(my_url)
        structure = file_object.read()
        file_object.close()
        
        file_object = urllib.request.urlopen(my_url)
        #structure_line = file_object.readline()
        file_object.close()
    except:
        check_if_code_in = False
        my_iteraction = 1
        print("RCSB is complaining about 'High User Activity'.")
        print("I will try to wait longer for each file...")
        my_time_to_wait = my_iteraction*20
        print("Waiting for",my_time_to_wait," seconds...")
        time.sleep(my_time_to_wait)
        print("\n "+file_2_download+" file downloaded from http://www.rcsb.org/")
        loop_flag = True
        
        # while loop to keep trying to download
        while loop_flag:
            try: 
                file_object = urllib.request.urlopen(my_url)
                structure = file_object.read()
                file_object.close()
        
                file_object = urllib.request.urlopen(my_url)
                #structure_line = file_object.readline()
                file_object.close()
                loop_flag = False
                check_if_code_in = True
            except:
                my_iteraction += 1
                loop_flag = True
                check_if_code_in = False
    
            if my_time_to_wait > 359:
                print("It is taking too long!")
                print("Try to split in different inputs getbind.in, with a smaller number of structures per input.\n")
                return check_if_code_in
                break
            
    time.sleep(1)
    
    with open(my_dir_in+file_2_download,"wb") as my_file_4_download:
        my_file_4_download.write(structure)
        my_file_4_download.close()
        check_if_code_in = True
def main():
        
    my_dir_in ="./ki/"
    binding_info = "Ki"

    # Set up PDB url
    url_in = 'http://files.rcsb.org/download/'
    
    # Set up PDB access code
    nomePdbs=leCsv("./arquivosEntrada/pdbsProteina.txt")
    totalArquivos=nomePdbs.__len__()
    count=0
    print ("iniciando download de arquivos PDB no site:",url_in)
    for linha in nomePdbs:
        structureId = linha.strip()
        # Call download_PDB_file()
        getBind(my_dir_in,structureId,binding_info)
        count=count+1
        print ("progresso", count," de ",totalArquivos)
    print (count,' arquiv(os) foram baixados com sucesso')
    
main()        