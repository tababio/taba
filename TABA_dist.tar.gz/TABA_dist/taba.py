#!/usr/bin/env python3.5
# -*- coding: utf-8 -*-
from PyQt4 import QtGui  # Import the PyQt4 module we'll need
import sys  # We need sys so that we can pass argv to QApplication
from func_Gerais import limpaPastas

# it also keeps events etc that we defined in Qt Designer


import interfacePrincipal
import winInformacoes
import winBaixaPdbs
import winExperimentoUsuario
import winGeraArquivosRegressao
import winRegressao
import winCorrelacao
import winGestaoExperimentos
import winAjuda
from func_Gerais import limpa_arquivosSf, pegaConfig

class principal(QtGui.QMainWindow, interfacePrincipal.Ui_MainWindowPrincipal):
    def __init__(self):
        # Explaining super is out of the scope of this article
        # So please google it if you're not familar with it
        # Simple reason why we use it here is that it allows us to
        # access variables, methods etc in the design.py file
        super(self.__class__, self).__init__()
        self.setupUi(self)  # This is defined in design.py file automatically
        # It sets up layout and widgets that are defined
        #self.toolButton_regressao.clicked.connect(self.fazRegressao())  # When the button is pressed
        # Execute browse_folder function
        self.move(80,50)
        self.setFixedSize(900,650)
        self.window2 = None
        self.window3 = None
        self.window4 = None
        self.window5 = None
        self.window6 = None
        self.window7 = None
        self.window8 = None
        self.window9 = None
        diret = "./arquivosSaida/"
        limpa_arquivosSf(diret)
        self.limparExperimento()
        
        
    # chama interface informacoes
    def informacoes(self):
        if self.window2 is None:
            self.window2 = winInformacoes.informacoes(self)
        self.window2.show()
        self.window2 = None
    def baixaPdbsProteinas(self):
        if self.window3 is None:
            self.window3 = winBaixaPdbs.baixaPdbss(self)
        QtGui.QApplication.processEvents() # para não travar
        self.window3.show()
        self.window3 = None
    def fazExperimento(self):
        if self.window4 is None:
            self.window4 = winExperimentoUsuario.experimentoUsuario(self)
        QtGui.QApplication.processEvents() # para não travar        
        self.window4.lineEdit_estrutura.clear()# apaga dados anteriores
        self.window4.lineEdit_Ligante.clear()# apaga dados anteriores
        self.window4.show()
        self.window4 = None
    def geraArquivoParaRegressao(self):
        if self.window5 is None:
            self.window5 = winGeraArquivosRegressao.geraArquivosRegressao(self)
        QtGui.QApplication.processEvents() # para não travar
        self.window5.show()
        self.window5 = None
    def fazRegressao(self):
        if self.window6 is None:
            self.window6 = winRegressao.fazRegressao(self)
        QtGui.QApplication.processEvents() # para não travar
        self.window6.show()
        self.window6 = None
    def fazCorrelacao(self):
        if self.window7 is None:
            self.window7 = winCorrelacao.fazCorrelacao(self)
        QtGui.QApplication.processEvents() # para não travar
        self.window7.show()
        self.window7 = None 
    def gerenciarExperimentos(self):
        if self.window8 is None:
            self.window8 = winGestaoExperimentos.gestaoExperimentos(self)
        QtGui.QApplication.processEvents() # para não travar
        self.window8.show()
        self.window8 = None 
    def sair(self):        
        self.close()   
    def ajuda(self):
     
        if self.window9 is None:
            self.window9 = winAjuda.ajuda(self)
        self.window9.show()
        self.window9 = None   
    
    def limparExperimento(self):
        if (pegaConfig("descricaoDataset").strip() == 'novaVersao') and (pegaConfig("comentarios").strip() == 'novaVersao'):
            QtGui.QMessageBox.information(self, "Message", "You have installed a new version of Taba." +"\n"+"The files in the current experiment will be cleaned now." +"\n"+"You can recover them if you saved them earlier.")
            limpaPastas()
            QtGui.QMessageBox.information(self, "Message", "Operation completed")
        else:
            pass


def main():
    app = QtGui.QApplication(sys.argv)  # A new instance of QApplication
    form = principal()  # We set the form to be our ExampleApp (design)
    form.show()  # Show the form
    app.exec_()  # and execute the app
    

if __name__ == '__main__':  # if we're running file directly and not importing it
    main()  # run the main function


