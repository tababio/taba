#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from PyQt4 import QtGui  # Import the PyQt4 module we'll need
from PyQt4.QtGui import QApplication, QDialog
from func_Gerais import grava, pegaConfig, get_listaDistancias, pastaVazia
from func_RenomeiaArq import diretorio
import interfaceGeraArquivosRegressao
from func_ContaInterMolCalcTermo import inter_mol_term, calc_average_distance
from func_CriaDicionario import cria_dicionario
from func_Gerais import leCsv, gravaConfig
from func_TrataKi import calculaKi
from func_GeraArqProteinaComKi import geraArquivoProteinaFinal
from func_SeparaLiganteProteina import separaLiganteProteina
from datetime import datetime
from func_GeraArqProteinaTreinoTeste import geraArquivoTesteTreino
from asyncio.tasks import wait
from time import sleep

class geraArquivosRegressao(QtGui.QMainWindow, interfaceGeraArquivosRegressao.Ui_MainWindowGeraArquivos):
    def __init__(self, parent = None):
        QtGui.QWidget.__init__(self, parent)
        self.setupUi(self)
        self.window1 = None
        self.setFixedSize(900,550)
        self.radioButton_45.setChecked(True)
        self.label_cabecalho.setText("")
        self.label_textoProgresso.setText("")
        nome = pegaConfig("descricaoDataset").strip()
        quantia = pegaConfig("quantidadeProteinas").strip()
        afinidade = pegaConfig("tipoAfinidade").strip() 
        self.label_experimento.setText(nome)
        self.label_afinidade.setText(afinidade)
        self.label_quantia.setText(quantia)
        self.label_relogio.hide()
        self.label_distanciasUsadas.setText(self.get_distanciasUsadas())
        self.label_tipoMedia.setText(pegaConfig("tipoMedia").strip())
        self.label_outliers.setText(pegaConfig("outlier").strip())
        self.label_estruturaInicial.setText(pegaConfig("quantidadeInicialProteinas").strip())  
        self.setWindowTitle(self.windowTitle()+" to "+pegaConfig("descricaoDataset").strip())

    def geraArquivosTermoEnergia(self): 
        path ="./pdbs"

        if pastaVazia(path) == True:
            reply = QtGui.QMessageBox.warning(self, 'Attention !!',"Pdbs files have not been downloaded yet", QtGui.QMessageBox.Ok)
        else:
            reply = QtGui.QMessageBox.question(self, 'Message',"This operation may take several minutes. Do you want to proceed?", QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, QtGui.QMessageBox.No)

            if reply == QtGui.QMessageBox.Yes:            
                self.geraArquivos()
            else:
                pass
 
    def sair(self):        
        self.close()
        
    def geraArquivos(self):
        self.escondeBotoes()
        diretorio = "./inputFiles/" # define diretorio para salvar o download
        self.chamaRotinasPreparacao(diretorio) # chama runcoes para preparar arquivos para processamento
        arquivosParaLerTes = leCsv(diretorio+"pdbsProteinaFinalTes.txt") # le arquivo com os pdbs a serem processados como proteinas. Este arquvivo so contem pdbs que tem arquivo de KI correspondente
        arquivosParaLerTre = leCsv(diretorio+"pdbsProteinaFinalTre.txt")    
        # entra o valor da distância
        # entra o valor da distância
        distancia = 4.5 # padrao
        seedNum = self.comboBox_seed.currentText()
        seed = 'seed45' # semente que sera gravada no arquivo config.csv para usar no SF
        
        if self.radioButton_35.isChecked():
            distancia = 3.5
            seed = 'seed35'
        elif self.radioButton_45.isChecked():
            distancia = 4.5
            seed = 'seed45'
        elif self.radioButton_60.isChecked():
            distancia = 6.0
            seed = 'seed60'
        elif self.radioButton_75.isChecked():
            distancia = 7.5
            seed = 'seed75'
        elif self.radioButton_90.isChecked():
            distancia = 9.0 
            seed = 'seed90'
        quantidadeArquivos = len(arquivosParaLerTes)+len(arquivosParaLerTre)
        if quantidadeArquivos <20:
            QtGui.QMessageBox.information(self, "Message", "The number of structures is very small. Use another set!")
            self.mostraBotoes()   
        else:
            self.geraArquivoComTermoDeEnergia(arquivosParaLerTre,distancia,"Tre") #gera arquivo de treino
            self.geraArquivoComTermoDeEnergia(arquivosParaLerTes,distancia,"Tes") #gera arquivo de teste             
            self.mostraBotoes() 
            self.progressBar.setValue(0)
            self.label_cabecalho.setText('')    
            self.label_textoProgresso.setText('')     
            QtGui.QMessageBox.information(self, "Message", "Operation completed")
            self.label_distanciasUsadas.setText(self.get_distanciasUsadas())
        gravaConfig(seed, seedNum) # salva valores de see no arquivo config para usar no SF e substituir no Mml.in
    
    def geraArquivoComTermoDeEnergia(self,arquivosParaLer,distancia,tipo):
        if tipo == "Tre":
            tipoCheio = "Training"
        elif tipo == "Tes":
            tipoCheio = "Test" 
        
        self.label_cabecalho.setText("Generating average distance for "+tipoCheio+". Please wait!!!")
        QtGui.QApplication.processEvents() # para não travar       
        if tipo == 'Tre':
            self.progressBar.setValue(0) 
            calc_average_distance(arquivosParaLer,distancia,"TRE", self.progressBar) # gera arquivo com medias do conjunto treino
        elif tipo == 'Tes':
            self.progressBar.setValue(0) 
            calc_average_distance(arquivosParaLer,distancia,"TES", self.progressBar)     
        QtGui.QApplication.processEvents() # para não travar  
        now = datetime.now()
        progresso = 0
        self.label_cabecalho.setText("Generating "+tipoCheio+" Files")       
        # CC CN  CO  CS  CP  CF  CBR CCL CI  CAT
            # NN  NO  NS  NP  NF  NBR NCL NI  NAT
                # OO  OS  OP  OF  OBR OCL OI  OAT
                    # SS  SP  SF  SBR SCL SI  SAT

        #foram retiradas as colunas de HOH pois vieram poucos resultados
        #texto = "liganteAtivo"+","+"arquivo"+","+"CC"+","+"CN"+","+"CO"+","+"CS"+","+"CP"+","+"CF"+","+"CBr"+","+"CCl"+","+"CI"+","+"CAt"+","+"NN"+","+"NO"+","+"NS"+","+"NP"+","+"NF"+","+"NBr"+","+"NCl"+","+"NI"+","+"NAt"+","+"OO"+","+"OS"+","+"OP"+","+"OF"+","+"OBr"+","+"OCl"+","+"OI"+","+"OAt"+","+"SS"+","+"SP"+","+"SF"+","+"SBr"+","+"SCl"+","+"SI"+","+"SAt"+","+"NHOHN"+","+"NHOHO"+","+"NHOHS"+","+"NHOHP"+","+"NHOHF"+","+"NHOHBR"+","+"NHOHCL"+","+"NHOHI"+","+"NHOHAT"+","+"OHOHO"+","+"OHOHS"+","+"OHOHP"+","+"OHOHF"+","+"OHOHBR"+","+"OHOHCL"+","+"OHOHI"+","+"OHOHAT"+","+"Log(Ki)"+"\n"
        texto = "liganteAtivo"+","+"arquivo"+","+"CC"+","+"CN"+","+"CO"+","+"CS"+","+"CP"+","+"CF"+","+"CBr"+","+"CCl"+","+"CI"+","+"CAt"+","+"NN"+","+"NO"+","+"NS"+","+"NP"+","+"NF"+","+"NBr"+","+"NCl"+","+"NI"+","+"NAt"+","+"OO"+","+"OS"+","+"OP"+","+"OF"+","+"OBr"+","+"OCl"+","+"OI"+","+"OAt"+","+"SS"+","+"SP"+","+"SF"+","+"SBr"+","+"SCl"+","+"SI"+","+"SAt"+","+"Log(Ki)"+"\n"
        textoKiBDB = texto
        textoKiPDBbind = texto 
        textoKiBMOAD = texto 
        textoKiTodos = texto
        #foram retiradas as colunas de HOH pois vieram poucos resultados
        #my_list = ['CC','CN','CO','CS','CP','CF','CBr','CCl','CI','CAt','NN','NO','NS','NP','NF','NBr','NCl','NI','NAt','OO','OS','OP','OF','OBr','OCl','OI','OAt','SS','SP','SF','SBr','SCl','SI','SAt','NHOHN','NHOHO','NHOHS','NHOHP','NHOHF','NHOHBR','NHOHCL','NHOHI','NHOHAT','OHOHO','OHOHS','OHOHP','OHOHF','OHOHBR','OHOHCL','OHOHI','OHOHAT']
        my_list = ['CC','CN','CO','CS','CP','CF','CBr','CCl','CI','CAt','NN','NO','NS','NP','NF','NBr','NCl','NI','NAt','OO','OS','OP','OF','OBr','OCl','OI','OAt','SS','SP','SF','SBr','SCl','SI','SAt']
        quantidadeArquivos = len(arquivosParaLer)
        cont = 0 # contador de arquivos processados
        for prot in arquivosParaLer:
            
            cont = cont +1 #quantidade arquivos processados
            varia = 100/quantidadeArquivos
            progresso = progresso+varia
            self.progressBar.setValue(progresso)
            
            diretorio = "./pdbs/"
            arquivo = prot.strip() # nome do arquivo pdb que est'em pdbsProteinas
            arquivo = arquivo.lower()
            protArq=diretorio+arquivo+"_soAtom.pdb" # coloca a terminacao para ler o arquivo so de proteinas que foram separados
            ligArq=diretorio+arquivo+"_soHetatm.pdb" # coloca a terminacao para ler o arquivo so de ligantes que foram separados
            mensagem = "Processing file:"+ tipoCheio + "-" + str(cont) + "/" + str(quantidadeArquivos) + "--->"+protArq.replace("_soAtom.pdb",".pdb")
            self.label_textoProgresso.setText(mensagem)

            if pegaConfig("tipoMedia").strip() == "training":
                tipoMedia = 'TRE'

            else:
                tipoMedia = 'ALL'
            countLigante = inter_mol_term(protArq,ligArq,distancia,tipo,tipoMedia)    
            vetLigante1=countLigante[0]
            vetLigante2=countLigante[1]
            conteudoLigante = cria_dicionario(vetLigante1, vetLigante2) 
            lin = protArq.replace("_soAtom.pdb","")+',' # retira .pdb do arquivo
            lin = lin.replace(diretorio,"") # retira caminho do arquivo)
            for aa in my_list:
                QtGui.QApplication.processEvents() # para não travar
                lin= lin+str(conteudoLigante[aa])+','
                liganteAtivo,logKiBDB,logKiPDBbind,logKiBMOAD,logKiTodos = calculaKi(arquivo+".csv")
            if logKiBDB!=0:
                textoKiBDB= textoKiBDB+liganteAtivo+","+lin+str(logKiBDB)+"\n" # so cria linha se logki for difeerente de zero
            if logKiPDBbind!=0:
                textoKiPDBbind= textoKiPDBbind+liganteAtivo+","+lin+str(logKiPDBbind)+"\n"
            if logKiBMOAD!=0:
                textoKiBMOAD= textoKiBMOAD+liganteAtivo+","+lin+str(logKiBMOAD)+"\n"
            if logKiTodos!=0:
                textoKiTodos= textoKiTodos+liganteAtivo+","+lin+str(logKiTodos)+"\n"
            self.tempoEstatistica(now, cont, quantidadeArquivos)
            QtGui.QApplication.processEvents() # para não travar
        diret = "./outputFiles/"
        strDist = str(distancia)
        #    ATENCAO NAO PODE GERAR LINHA ANTES E APOS O TEXTO 
        # retirei Ki do nome em 29/04/2017
        grava(textoKiBDB,diret+'saidaBDB'+strDist+'_TE_'+tipo+'.csv')
        grava(textoKiPDBbind,diret+'saidaPDBbind'+strDist+'_TE_'+tipo+'.csv')
        grava(textoKiBMOAD,diret+'saidaBMOAD'+strDist+'_TE_'+tipo+'.csv')
        grava(textoKiTodos,diret+'saidaTodos'+strDist+'_TE_'+tipo+'.csv') 

     
    def chamaRotinasPreparacao(self,diretorio):
        seed = int(self.comboBox_seed.currentText())
        geraArquivoTesteTreino(diretorio,"pdbsProteina.txt", seed)
        geraArquivoProteinaFinal(diretorio,"pdbsProteinaTreino.txt","Tre") # gera arquivo so com proteinas que tem arquivo de ki correspondente
        separaLiganteProteina(diretorio,"pdbsProteinaTreino.txt","Tre","") # separa PDB em 2 arquivos: proteina(Atom), ligante(Hetatm)
        geraArquivoProteinaFinal(diretorio,"pdbsProteinaTeste.txt","Tes") # gera arquivo so com proteinas que tem arquivo de ki correspondente
        separaLiganteProteina(diretorio,"pdbsProteinaTeste.txt","Tes","")            
     
    def tempoEstatistica(self,now,cont,quant): # mostra estimativas de duracao do processamento
        now2 = datetime.now()
        tempo = now2-now
        mediaAtual = tempo/cont
        total = tempo+(mediaAtual*(quant-cont))
        tempoRestante = total-tempo
    def escondeBotoes(self):
        self.toolButton_iniciar.setEnabled(False)
        self.toolButton_exit.setEnabled(False)
        self.label_relogio.show()
    def mostraBotoes(self):
        self.toolButton_iniciar.setEnabled(True)
        self.toolButton_exit.setEnabled(True) 
        self.label_relogio.hide()
    def get_distanciasUsadas(self):
        diret = "./outputFiles/"
        list = get_listaDistancias(diret)
        list = sorted(list)
        texto = ""
        for x in list:
            texto = texto+" - "+x+str(chr(197))
        return texto[3:]