import sys

from func_AplicaEquacaoUsuario import gera, chamaRotinasPreparacao, geraArquivoComTermoDeEnergia, melhorEquacao
from func_Gerais import leCsv


def main():
    diretorio = "./arquivosEntrada/" # define diretorio para salvar o download
    chamaRotinasPreparacao(diretorio) # chama runcoes para preparar arquivos para processamento
    continua = input("Deseja continuar e gerar arquivos para Regressao Linear s/n?")
    continua = continua.upper()
    if continua == "S":
        print(".....Em processamento!(4)")   
        arquivosParaLerUsu = leCsv(diretorio+"pdbsProteinaUsu.txt") # le arquivo com os pdbs a serem processados como proteinas. Este arquvivo so contem pdbs que tem arquivo de KI correspondente

        # entra o valor da distância
        distancia = 0   
        dist = input("Defina o valor de corte da distância (1 = 3.5A, 2 = 4.5A, 3 = 6.0 A, 4 = 7.5A, 5 = 9.0A)")   
        if dist not in ["1","2","3","4","5"]:
            print("valor invalido")
            sys.exit(0)
        elif dist == '1':
            distancia = 3.5
        elif dist == '2':
            distancia = 4.5
        elif dist == '3':
            distancia = 6.0
        elif dist == '4':
            distancia = 7.5
        elif dist == '5':
            distancia = 9.0        
        diretorio, arquivo = geraArquivoComTermoDeEnergia(arquivosParaLerUsu,distancia,"Usu") #gera arquivo de treino
        print(arquivo)
        formula = melhorEquacao()
        print(formula)
        pdbNome,result = gera("", arquivo, formula) 
        # vamos pegar só um valor calculado de ki pois a funcçao e utilizada tambem para conjunto teste
  
        print("Log10Ki-9 teorico:",pdbNome,result)
    else:
        print("")
        print(".....Concluido!")
        exit
main()