# Program to download PDB file
from time import sleep

from func_Gerais import download_PDB_file  
from func_Gerais import leCsv   


def main():
    # Set up PDB url
    url_in = 'https://files.rcsb.org/download/'
    
    # Set up PDB access code
    nomePdbs=leCsv("./arquivosEntrada/pdbsProteina.txt")
    totalArquivos=nomePdbs.__len__()
    count=0
    contaPausa = 0
    print ("iniciando download de arquivos PDB no site:",url_in)
    for linha in nomePdbs:
        pdb_access = linha.strip()
        print ("url",url_in,pdb_access)
        # Call download_PDB_file()
        download_PDB_file(url_in,pdb_access)
        count=count+1
        print ("progresso", count," de ",totalArquivos)
        contaPausa = contaPausa+1
        if contaPausa > 100:
            contaPausa = 0
            print ("---> pausa tecnica. Aguarde que o programa continuara a rodar automaticamente...")
            sleep(30) # pausa para por exigencia do site se nao nao baixa todos
            

    print (count,' arquiv(os) foram baixados com sucesso')

main()
# exemplo https://files.rcsb.org/download/1a4l.pdb