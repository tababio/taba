# Program to calculate intermolecular interactions
from datetime import datetime
import sys

from func_ContaInterMolCalcTermo import inter_mol_term
from func_CriaDicionario import cria_dicionario
from func_GeraArqProteinaComKi import geraArquivoProteinaFinal
from func_GeraArqProteinaTreinoTeste import geraArquivoTesteTreino
from func_Gerais import grava, tempoEstatistica, leCsv
from func_SeparaLiganteProteina import separaLiganteProteina
from func_TrataKi import calculaKi


def geraArquivoComTermoDeEnergia(arquivosParaLer,distancia,tipo):
    now = datetime.now()
# CC CN  CO  CS  CP  CF  CBR CCL CI  CAT
    # NN  NO  NS  NP  NF  NBR NCL NI  NAT
        # OO  OS  OP  OF  OBR OCL OI  OAT
            # SS  SP  SF  SBR SCL SI  SAT

    #foram retiradas as colunas de HOH pois vieram poucos resultados
    #texto = "liganteAtivo"+","+"arquivo"+","+"CC"+","+"CN"+","+"CO"+","+"CS"+","+"CP"+","+"CF"+","+"CBr"+","+"CCl"+","+"CI"+","+"CAt"+","+"NN"+","+"NO"+","+"NS"+","+"NP"+","+"NF"+","+"NBr"+","+"NCl"+","+"NI"+","+"NAt"+","+"OO"+","+"OS"+","+"OP"+","+"OF"+","+"OBr"+","+"OCl"+","+"OI"+","+"OAt"+","+"SS"+","+"SP"+","+"SF"+","+"SBr"+","+"SCl"+","+"SI"+","+"SAt"+","+"NHOHN"+","+"NHOHO"+","+"NHOHS"+","+"NHOHP"+","+"NHOHF"+","+"NHOHBR"+","+"NHOHCL"+","+"NHOHI"+","+"NHOHAT"+","+"OHOHO"+","+"OHOHS"+","+"OHOHP"+","+"OHOHF"+","+"OHOHBR"+","+"OHOHCL"+","+"OHOHI"+","+"OHOHAT"+","+"Log(Ki)"+"\n"
    texto = "liganteAtivo"+","+"arquivo"+","+"CC"+","+"CN"+","+"CO"+","+"CS"+","+"CP"+","+"CF"+","+"CBr"+","+"CCl"+","+"CI"+","+"CAt"+","+"NN"+","+"NO"+","+"NS"+","+"NP"+","+"NF"+","+"NBr"+","+"NCl"+","+"NI"+","+"NAt"+","+"OO"+","+"OS"+","+"OP"+","+"OF"+","+"OBr"+","+"OCl"+","+"OI"+","+"OAt"+","+"SS"+","+"SP"+","+"SF"+","+"SBr"+","+"SCl"+","+"SI"+","+"SAt"+","+"Log(Ki)"+"\n"
    textoKiBDB = texto
    textoKiPDBbind = texto 
    textoKiBMOAD = texto 
    textoKiTodos = texto
    #foram retiradas as colunas de HOH pois vieram poucos resultados
    #my_list = ['CC','CN','CO','CS','CP','CF','CBr','CCl','CI','CAt','NN','NO','NS','NP','NF','NBr','NCl','NI','NAt','OO','OS','OP','OF','OBr','OCl','OI','OAt','SS','SP','SF','SBr','SCl','SI','SAt','NHOHN','NHOHO','NHOHS','NHOHP','NHOHF','NHOHBR','NHOHCL','NHOHI','NHOHAT','OHOHO','OHOHS','OHOHP','OHOHF','OHOHBR','OHOHCL','OHOHI','OHOHAT']
    my_list = ['CC','CN','CO','CS','CP','CF','CBr','CCl','CI','CAt','NN','NO','NS','NP','NF','NBr','NCl','NI','NAt','OO','OS','OP','OF','OBr','OCl','OI','OAt','SS','SP','SF','SBr','SCl','SI','SAt']
    quantidadeArquivos = len(arquivosParaLer)
    cont = 0 # contador de arquivos processados
    if tipo == "Tre":
        tipoCheio = "Treino"
    elif tipo == "Tes":
        tipoCheio = "Teste"
    for prot in arquivosParaLer:
        cont = cont +1 #quantidade arquivos processados
        
        diretorio = "./pdbs/"
        arquivo = prot.strip() # nome do arquivo pdb que est'em pdbsProteinas
        arquivo = arquivo.lower()
        protArq=diretorio+arquivo+"_soAtom.pdb" # coloca a terminacao para ler o arquivo so de proteinas que foram separados
        ligArq=diretorio+arquivo+"_soHetatm.pdb" # coloca a terminacao para ler o arquivo so de ligantes que foram separados
        print ("Tratando arquivo:",tipoCheio,"-",cont,"/",quantidadeArquivos,"--->",protArq.replace("_soAtom.pdb",".pdb"))
        countLigante = inter_mol_term(protArq,ligArq,distancia)
        #print("teste----------------------",countLigante)
        vetLigante1=countLigante[0]
        vetLigante2=countLigante[1]
        #print("v1 e v2",vetLigante1,vetLigante2)
        #listaDicionario= cria_dicionario(vet1,vet2)
        #prIt listaDicionario
        conteudoLigante = cria_dicionario(vetLigante1, vetLigante2) 
        lin = protArq.replace("_soAtom.pdb","")+',' # retira .pdb do arquivo
        lin = lin.replace(diretorio,"") # retira caminho do arquivo)
        for aa in my_list:
            lin= lin+str(conteudoLigante[aa])+','
        liganteAtivo,logKiBDB,logKiPDBbind,logKiBMOAD,logKiTodos = calculaKi(arquivo+".csv")
        if logKiBDB!=0:
            textoKiBDB= textoKiBDB+liganteAtivo+","+lin+str(logKiBDB)+"\n" # so cria linha se logki for difeerente de zero
        if logKiPDBbind!=0:
            textoKiPDBbind= textoKiPDBbind+liganteAtivo+","+lin+str(logKiPDBbind)+"\n"
        if logKiBMOAD!=0:
            textoKiBMOAD= textoKiBMOAD+liganteAtivo+","+lin+str(logKiBMOAD)+"\n"
        if logKiTodos!=0:
            textoKiTodos= textoKiTodos+liganteAtivo+","+lin+str(logKiTodos)+"\n"
        tempoEstatistica(now, cont, quantidadeArquivos)

    diret = "./arquivosSaida/"
    strDist = str(distancia)
    #    ATENCAO NAO PODE GERAR LINHA ANTES E APOS O TEXTO 

    grava(textoKiBDB,diret+'saidaKiBDB'+strDist+'_TE_'+tipo+'.csv')
    grava(textoKiPDBbind,diret+'saidaKiPDBbind'+strDist+'_TE_'+tipo+'.csv')
    grava(textoKiBMOAD,diret+'saidaKiBMOAD'+strDist+'_TE_'+tipo+'.csv')
    grava(textoKiTodos,diret+'saidaKiTodos'+strDist+'_TE_'+tipo+'.csv') 

    print("|--------------------------------------------|") 
    print("| Gerado arquivo:",diret+'saidaKiBDB'+strDist+'_TE_'+tipo+'.csv',"  |")
    print("| Gerado arquivo:",diret+'saidaKiPDBbind'+strDist+'_TE_'+tipo+'.csv',"  |")
    print("| Gerado arquivo:",diret+'saidaKiBMOAD'+strDist+'_TE_'+tipo+'.csv',"  |")
    print("| Gerado arquivo:",diret+'saidaKiTodos'+strDist+'_TE_'+tipo+'.csv',"  |")
    print("|--------------------------------------------|") 
    
     
def chamaRotinasPreparacao(diretorio):
    print(".....Em processamento!(1)")
    geraArquivoTesteTreino(diretorio,"pdbsProteina.txt")
    print(".....Em processamento!(2)")
    geraArquivoProteinaFinal(diretorio,"pdbsProteinaTreino.txt","Tre") # gera arquivo so com proteinas que tem arquivo de ki correspondente
    print(".....Em processamento! (3)")
    separaLiganteProteina(diretorio,"pdbsProteinaTreino.txt","Tre") # separa PDB em 2 arquivos: proteina(Atom), ligante(Hetatm)
    print(".....Em processamento! (4)")
    geraArquivoProteinaFinal(diretorio,"pdbsProteinaTeste.txt","Tes") # gera arquivo so com proteinas que tem arquivo de ki correspondente
    print(".....Em processamento! (5)")
    separaLiganteProteina(diretorio,"pdbsProteinaTeste.txt","Tes")

def main():
    diretorio = "./arquivosEntrada/" # define diretorio para salvar o download
    chamaRotinasPreparacao(diretorio) # chama runcoes para preparar arquivos para processamento
    continua = input("Deseja continuar e gerar arquivos para Regressao Linear s/n?")
    continua = continua.upper()
    if continua == "S":
        print(".....Em processamento!(4)")   
        arquivosParaLerTes = leCsv(diretorio+"pdbsProteinaFinalTes.txt") # le arquivo com os pdbs a serem processados como proteinas. Este arquvivo so contem pdbs que tem arquivo de KI correspondente
        arquivosParaLerTre = leCsv(diretorio+"pdbsProteinaFinalTre.txt")    
        # entra o valor da distância
        distancia = 0   
        dist = input("Defina o valor de corte da distância (1 = 3.5A, 2 = 4.5A, 3 = 6.0 A, 4 = 7.5A, 5 = 9.0A)")   
        if dist not in ["1","2","3","4","5"]:
            print("valor invalido")
            sys.exit(0)
        elif dist == '1':
            distancia = 3.5
        elif dist == '2':
            distancia = 4.5
        elif dist == '3':
            distancia = 6.0
        elif dist == '4':
            distancia = 7.5
        elif dist == '5':
            distancia = 9.0
        geraArquivoComTermoDeEnergia(arquivosParaLerTre,distancia,"Tre") #gera arquivo de treino
        geraArquivoComTermoDeEnergia(arquivosParaLerTes,distancia,"Tes") #gera arquivo de teste             
    else:
        print("")
        print(".....Concluido!")
        exit
main()