#setup.py
#18_03_2018 - falta incluir pastas, ver permissoes diretorio
# no terminal digitar 'python setup_taba.py bdist_msi'
#'packages': ["os","idna","sys","ctypes","win32con","encodings","asyncio"]
# retirei 'include_files': [''],
#pip install -U scikit-learn[alldeps] -> necessario para atualizar
#then the cKDTree.*.pyd will not be copied but the ckdtree.*.pyd is kept in the lib\scipy\spatial of the build folder


from cx_Freeze import setup, Executable
#import os, numpy, scipy
import os
import shutil
shutil.rmtree('dist')
shutil.rmtree('build')
os.environ['TCL_LIBRARY'] = r'C:\Users\amaur\Anaconda3\tcl\tcl8.6'
os.environ['TK_LIBRARY'] = r'C:\Users\amaur\Anaconda3\tcl\tk8.6'
#additional_mods = ['numpy.core._methods', 'numpy.lib.format', 'scipy.sparse.csgraph._validation','matplotlib.backends.backend_qt4agg','csv','pandas','matplotlib','numpy',]
additional_mods = ['numpy.core._methods', 'numpy.lib.format', 'scipy.sparse.csgraph._validation','matplotlib.backends.backend_qt4agg','csv]

setup(
    name = "taba",
    version = "1.0.0",
    options = {"build_exe": {
        'packages': ["encodings","asyncio","os","idna","sys","ctypes","win32con"],   
	'includes': additional_mods,   
	'include_files':['outputFiles/','inputFiles/','adjustmentFunctions/','ki/','logs/','pdbs/','setsExperiments/','img/'], 
        'include_msvcr': True,
    }},
    executables = [Executable("taba.py",base="Win32GUI")]
    )